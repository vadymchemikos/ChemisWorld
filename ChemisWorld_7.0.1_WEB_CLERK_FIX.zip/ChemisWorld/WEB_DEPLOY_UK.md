# ChemisWorld 7.0.0 WEB — Render deployment

1. Завантаж вміст папки `ChemisWorld` до свого GitHub-репозиторію, зберігши структуру папок.
2. Переконайся, що Render використовує кореневу директорію `backend` (якщо сервіс налаштований на Root Directory).
3. У Render → Environment залиш чинні `JWT_SECRET` і `DB_PATH`.
4. Додай `CLERK_PUBLISHABLE_KEY` і `CLERK_SECRET_KEY` із Clerk Dashboard.
5. За потреби додай `CLERK_ISSUER`; якщо не вказувати, він визначається з Publishable Key.
6. Встанови `APP_ORIGIN=https://chemisworld.onrender.com` та `ALLOWED_ORIGINS=https://chemisworld.onrender.com`.
7. У Clerk Dashboard увімкни Google як єдиний спосіб sign-up/sign-in. Для production налаштуй власні Google OAuth credentials і redirect URI Clerk.
8. Збережи Environment і дочекайся автоматичного Render deploy.

Firebase Authentication для браузерної версії 7.0.0 не використовується. Старі Firebase identity записи зберігаються лише для зіставлення підтвердженої Google-пошти та перенесення ігрового профілю.

APK не оновлюється цим WEB-релізом.
