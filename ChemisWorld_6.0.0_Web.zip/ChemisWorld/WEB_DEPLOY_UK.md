# Chemis World 6.0.0 — браузерна версія

## Як це працює
Браузерна версія використовує той самий клієнт `index.html`, `app.js`, `style.css` і той самий API/сервер, що й Android. Файли вебклієнта розміщені в `backend/public`, а Express віддає їх на `/`. У браузері API автоматично використовує поточний HTTPS-домен.

## Публікація на наявному Render Web Service
1. Завантажити оновлений проєкт у той самий GitHub-репозиторій.
2. У Render відкрити **наявний** Web Service `chemisworld` — не створювати новий сервіс.
3. Переконатися, що Root Directory = `backend`, Build Command = `npm install`, Start Command = `npm start`.
4. Зберегти наявні Environment Variables, особливо `JWT_SECRET` і `DB_PATH`.
5. Не видаляти та не форматувати Persistent Disk і не змінювати шлях до чинної SQLite-бази.
6. Запустити Manual Deploy / Deploy latest commit.
7. Після успішного деплою відкрити `https://chemisworld.onrender.com/` у браузері.

## Важливо
- Якщо Render налаштований на іншу папку/команди, не змінювати їх навмання — спочатку перевірити поточні налаштування.
- Не створювати нову базу даних замість чинної.
- Android APK продовжує відкривати локальні assets, а API за замовчуванням лишається `https://chemisworld.onrender.com`.
- Для карти потрібне підключення до інтернету (Leaflet та геодані завантажуються з зовнішніх джерел).
