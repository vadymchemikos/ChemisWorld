import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import Database from 'better-sqlite3';
import { randomBytes, timingSafeEqual, createHmac, scryptSync } from 'node:crypto';
const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
const DB_PATH = process.env.DB_PATH || './data/chemis-world.sqlite';
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('Set JWT_SECRET to a random value of at least 32 characters in backend/.env');
  process.exit(1);
}
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x=>x.trim()).filter(Boolean);
app.use(helmet());
app.use(cors({origin(origin,cb){ if(!origin || allowedOrigins.length===0 || allowedOrigins.includes(origin)) return cb(null,true); cb(new Error('Origin not allowed')); }}));
app.use(express.json({limit:'8mb'}));
const fs = await import('node:fs');
fs.mkdirSync(new URL('../data/', import.meta.url), {recursive:true});
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS players(
 id TEXT PRIMARY KEY, nickname TEXT NOT NULL COLLATE NOCASE UNIQUE,
 password_hash TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '',
 home_region TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_players_nickname ON players(nickname);
CREATE TABLE IF NOT EXISTS google_identities(
 google_sub TEXT PRIMARY KEY, player_id TEXT NOT NULL UNIQUE REFERENCES players(id) ON DELETE CASCADE,
 email TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS google_oauth_states(
 state TEXT PRIMARY KEY, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS game_states(
 id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES players(id),
 name TEXT NOT NULL, capital TEXT NOT NULL, color TEXT NOT NULL,
 symbol TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS political_parties(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 creator_id TEXT NOT NULL REFERENCES players(id), name TEXT NOT NULL,
 ideology TEXT NOT NULL DEFAULT '', platform TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL, UNIQUE(state_id,name)
);
CREATE TABLE IF NOT EXISTS state_elections(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 created_by TEXT NOT NULL REFERENCES players(id), status TEXT NOT NULL DEFAULT 'open',
 created_at TEXT NOT NULL, closes_at TEXT
);
CREATE TABLE IF NOT EXISTS election_candidates(
 election_id TEXT NOT NULL REFERENCES state_elections(id) ON DELETE CASCADE,
 party_id TEXT NOT NULL REFERENCES political_parties(id), candidate_name TEXT NOT NULL,
 PRIMARY KEY(election_id,party_id)
);
CREATE TABLE IF NOT EXISTS election_votes(
 election_id TEXT NOT NULL REFERENCES state_elections(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), party_id TEXT NOT NULL REFERENCES political_parties(id),
 created_at TEXT NOT NULL, PRIMARY KEY(election_id,voter_id)
);
CREATE TABLE IF NOT EXISTS state_laws(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 author_id TEXT NOT NULL REFERENCES players(id), title TEXT NOT NULL,
 description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'proposed',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS parliament_seats(
 election_id TEXT NOT NULL REFERENCES state_elections(id) ON DELETE CASCADE,
 party_id TEXT NOT NULL REFERENCES political_parties(id), seats INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(election_id,party_id)
);
CREATE TABLE IF NOT EXISTS law_votes(
 law_id TEXT NOT NULL REFERENCES state_laws(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), decision TEXT NOT NULL CHECK(decision IN ('yes','no')),
 created_at TEXT NOT NULL, PRIMARY KEY(law_id,voter_id)
);
CREATE TABLE IF NOT EXISTS state_governments(
 state_id TEXT PRIMARY KEY REFERENCES game_states(id) ON DELETE CASCADE,
 election_id TEXT REFERENCES state_elections(id), prime_minister TEXT NOT NULL,
 formed_by TEXT NOT NULL REFERENCES players(id), formed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS government_ministers(
 state_id TEXT NOT NULL REFERENCES state_governments(state_id) ON DELETE CASCADE,
 portfolio TEXT NOT NULL, minister_name TEXT NOT NULL,
 PRIMARY KEY(state_id,portfolio)
);
CREATE TABLE IF NOT EXISTS regional_administrations(
 state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 territory_key TEXT NOT NULL, governor_id TEXT NOT NULL REFERENCES players(id),
 appointed_by TEXT NOT NULL REFERENCES players(id), updated_at TEXT NOT NULL,
 PRIMARY KEY(state_id,territory_key),
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS regional_elections(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 created_by TEXT NOT NULL REFERENCES players(id), status TEXT NOT NULL DEFAULT 'open',
 created_at TEXT NOT NULL,
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS regional_candidates(
 election_id TEXT NOT NULL REFERENCES regional_elections(id) ON DELETE CASCADE,
 candidate_name TEXT NOT NULL, PRIMARY KEY(election_id,candidate_name)
);
CREATE TABLE IF NOT EXISTS regional_votes(
 election_id TEXT NOT NULL REFERENCES regional_elections(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), candidate_name TEXT NOT NULL,
 created_at TEXT NOT NULL, PRIMARY KEY(election_id,voter_id)
);
CREATE TABLE IF NOT EXISTS regional_councils(
 election_id TEXT NOT NULL REFERENCES regional_elections(id) ON DELETE CASCADE,
 candidate_name TEXT NOT NULL, votes INTEGER NOT NULL, seats INTEGER NOT NULL,
 PRIMARY KEY(election_id,candidate_name)
);
CREATE TABLE IF NOT EXISTS regional_economies(
 state_id TEXT NOT NULL, territory_key TEXT NOT NULL, treasury INTEGER NOT NULL DEFAULT 1000,
 tax_rate INTEGER NOT NULL DEFAULT 10, infrastructure_level INTEGER NOT NULL DEFAULT 1,
 turn_number INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL,
 PRIMARY KEY(state_id,territory_key),
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS regional_buildings(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 building_type TEXT NOT NULL, level INTEGER NOT NULL DEFAULT 1,
 created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL,
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS regional_local_laws(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 title TEXT NOT NULL, description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'proposed',
 created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL,
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS regional_local_law_votes(
 law_id TEXT NOT NULL REFERENCES regional_local_laws(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), decision TEXT NOT NULL CHECK(decision IN ('yes','no')),
 created_at TEXT NOT NULL, PRIMARY KEY(law_id,voter_id)
);
CREATE TABLE IF NOT EXISTS mayor_elections(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open', winner TEXT, created_by TEXT NOT NULL REFERENCES players(id),
 created_at TEXT NOT NULL,
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS mayor_candidates(
 election_id TEXT NOT NULL REFERENCES mayor_elections(id) ON DELETE CASCADE,
 candidate_name TEXT NOT NULL, PRIMARY KEY(election_id,candidate_name)
);
CREATE TABLE IF NOT EXISTS mayor_votes(
 election_id TEXT NOT NULL REFERENCES mayor_elections(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), candidate_name TEXT NOT NULL,
 created_at TEXT NOT NULL, PRIMARY KEY(election_id,voter_id)
);
CREATE TABLE IF NOT EXISTS regional_mayors(
 state_id TEXT NOT NULL, territory_key TEXT NOT NULL, mayor_name TEXT NOT NULL,
 election_id TEXT NOT NULL REFERENCES mayor_elections(id), updated_at TEXT NOT NULL,
 PRIMARY KEY(state_id,territory_key),
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS cities(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 name TEXT NOT NULL, population INTEGER NOT NULL DEFAULT 10000,
 urban_level INTEGER NOT NULL DEFAULT 1, mayor_id TEXT REFERENCES players(id),
 created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(state_id,territory_key,name),
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS city_economies(
 city_id TEXT PRIMARY KEY REFERENCES cities(id) ON DELETE CASCADE,
 treasury INTEGER NOT NULL DEFAULT 500, tax_rate INTEGER NOT NULL DEFAULT 5,
 turn_number INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS city_elections(
 id TEXT PRIMARY KEY, city_id TEXT NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
 election_type TEXT NOT NULL CHECK(election_type IN ('mayor','council')),
 status TEXT NOT NULL DEFAULT 'open', winner_id TEXT REFERENCES players(id),
 winner_nickname TEXT, created_by TEXT NOT NULL REFERENCES players(id),
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS city_candidates(
 election_id TEXT NOT NULL REFERENCES city_elections(id) ON DELETE CASCADE,
 player_id TEXT NOT NULL REFERENCES players(id), nickname TEXT NOT NULL,
 PRIMARY KEY(election_id,player_id)
);
CREATE TABLE IF NOT EXISTS city_votes(
 election_id TEXT NOT NULL REFERENCES city_elections(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), candidate_id TEXT NOT NULL REFERENCES players(id),
 created_at TEXT NOT NULL, PRIMARY KEY(election_id,voter_id)
);
CREATE TABLE IF NOT EXISTS city_council_seats(
 city_id TEXT NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
 player_id TEXT NOT NULL REFERENCES players(id), nickname TEXT NOT NULL,
 votes INTEGER NOT NULL, seats INTEGER NOT NULL,
 PRIMARY KEY(city_id,player_id)
);
CREATE TABLE IF NOT EXISTS city_proposals(
 id TEXT PRIMARY KEY, city_id TEXT NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
 title TEXT NOT NULL, description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'proposed',
 created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS city_proposal_votes(
 proposal_id TEXT NOT NULL REFERENCES city_proposals(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), decision TEXT NOT NULL CHECK(decision IN ('yes','no')),
 created_at TEXT NOT NULL, PRIMARY KEY(proposal_id,voter_id)
);
CREATE TABLE IF NOT EXISTS city_projects(
 id TEXT PRIMARY KEY, city_id TEXT NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
 project_type TEXT NOT NULL, level INTEGER NOT NULL DEFAULT 1,
 created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS state_territories(
 state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 territory_key TEXT NOT NULL UNIQUE, added_at TEXT NOT NULL,
 PRIMARY KEY(state_id,territory_key)
);
CREATE TABLE IF NOT EXISTS player_game_stats(
 player_id TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
 xp INTEGER NOT NULL DEFAULT 0, energy INTEGER NOT NULL DEFAULT 500,
 avatar TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS player_region_wallets(
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL,
 gold INTEGER NOT NULL DEFAULT 0, last_refill_at INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(player_id,region_key)
);
CREATE TABLE IF NOT EXISTS game_articles(
 id TEXT PRIMARY KEY, author_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 title TEXT NOT NULL, body TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'general',
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_articles_updated ON game_articles(updated_at DESC);

CREATE TABLE IF NOT EXISTS guest_articles(
 id TEXT PRIMARY KEY, author_name TEXT NOT NULL DEFAULT 'Гість',
 title TEXT NOT NULL, body TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'general',
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_guest_articles_created ON guest_articles(created_at DESC);
CREATE TABLE IF NOT EXISTS world_chat_messages(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 player_id TEXT REFERENCES players(id) ON DELETE SET NULL,
 author_name TEXT NOT NULL,
 body TEXT NOT NULL, image_data TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_world_chat_created ON world_chat_messages(created_at DESC);
CREATE TABLE IF NOT EXISTS regional_party_members(
 party_id TEXT NOT NULL REFERENCES regional_parties(id) ON DELETE CASCADE,
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 role TEXT NOT NULL DEFAULT 'member', joined_at INTEGER NOT NULL,
 PRIMARY KEY(party_id,player_id)
);
CREATE TABLE IF NOT EXISTS guest_article_votes(
 article_id TEXT NOT NULL REFERENCES guest_articles(id) ON DELETE CASCADE, voter_key TEXT NOT NULL,
 value INTEGER NOT NULL CHECK(value IN (-1,1)), created_at TEXT NOT NULL, PRIMARY KEY(article_id,voter_key)
);
CREATE TABLE IF NOT EXISTS guest_article_comments(
 id TEXT PRIMARY KEY, article_id TEXT NOT NULL REFERENCES guest_articles(id) ON DELETE CASCADE,
 author_name TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL
);


CREATE TABLE IF NOT EXISTS regional_game_profiles(
 region_key TEXT PRIMARY KEY, region_name TEXT NOT NULL, country TEXT NOT NULL DEFAULT '',
 budget INTEGER NOT NULL DEFAULT 100000,
 health_index INTEGER NOT NULL DEFAULT 5, defense_index INTEGER NOT NULL DEFAULT 5,
 education_index INTEGER NOT NULL DEFAULT 5, development_index INTEGER NOT NULL DEFAULT 5,
 governor_nickname TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS regional_presidential_decrees(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, governor_id TEXT NOT NULL REFERENCES players(id),
 president_id TEXT NOT NULL REFERENCES players(id), decree_text TEXT NOT NULL,
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_region_decrees ON regional_presidential_decrees(region_key,created_at DESC);
CREATE TABLE IF NOT EXISTS regional_residencies(
 player_id TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL, registered_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_residencies_region ON regional_residencies(region_key);
CREATE TABLE IF NOT EXISTS academy_build_history(
 id INTEGER PRIMARY KEY AUTOINCREMENT, player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL, built_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_academy_history_player ON academy_build_history(player_id,built_at DESC);
CREATE TABLE IF NOT EXISTS player_medals(
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 medal_key TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(player_id,medal_key)
);
CREATE TABLE IF NOT EXISTS regional_academies(
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL,
 last_built_at INTEGER NOT NULL,
 PRIMARY KEY(player_id,region_key)
);
CREATE TABLE IF NOT EXISTS regional_parties(
 id TEXT PRIMARY KEY, player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL,
 name TEXT NOT NULL, ideology TEXT NOT NULL, program TEXT NOT NULL DEFAULT '',
 created_at INTEGER NOT NULL,
 UNIQUE(region_key,name)
);
CREATE INDEX IF NOT EXISTS idx_regional_parties_region ON regional_parties(region_key,created_at);
CREATE TABLE IF NOT EXISTS regional_elections(
 id TEXT PRIMARY KEY, region_key TEXT NOT NULL, region_name TEXT NOT NULL,
 created_at INTEGER NOT NULL, eligible_at INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'scheduled', result_json TEXT
);
CREATE TABLE IF NOT EXISTS player_region_presence(
 player_id TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS schema_migrations(
 name TEXT PRIMARY KEY, applied_at TEXT NOT NULL
);
`);
db.exec(`CREATE TABLE IF NOT EXISTS guest_sessions(guest_key TEXT PRIMARY KEY, player_id TEXT NOT NULL UNIQUE REFERENCES players(id) ON DELETE CASCADE, created_at TEXT NOT NULL, last_seen_at TEXT NOT NULL);`);
// Add per-article edit keys without breaking existing SQLite installations.
const guestArticleColumns=db.prepare('PRAGMA table_info(guest_articles)').all().map(x=>x.name);
const chatColumns=db.prepare('PRAGMA table_info(world_chat_messages)').all().map(x=>x.name);
if(!chatColumns.includes('image_data'))db.exec("ALTER TABLE world_chat_messages ADD COLUMN image_data TEXT NOT NULL DEFAULT ''");
if(!guestArticleColumns.includes('edit_key'))db.exec("ALTER TABLE guest_articles ADD COLUMN edit_key TEXT NOT NULL DEFAULT ''");
db.prepare("INSERT OR IGNORE INTO regional_party_members(party_id,player_id,role,joined_at) SELECT id,player_id,'leader',created_at FROM regional_parties").run();
function articleEditHash(key){return createHmac('sha256',JWT_SECRET).update('article-edit:'+key).digest('hex');}

const registerAttempts = new Map();
function rateLimit(key, max=8, windowMs=60000){
 const now=Date.now(), recent=(registerAttempts.get(key)||[]).filter(t=>now-t<windowMs);
 if(recent.length>=max) return false;
 recent.push(now); registerAttempts.set(key,recent); return true;
}
function fail(res,status,message){return res.status(status).json({error:message});}
function validNick(n){return typeof n==='string' && /^[\p{L}\p{N}_ -]{3,24}$/u.test(n.trim());}
function signToken(playerId){
 const header=Buffer.from(JSON.stringify({alg:'HS256',typ:'JWT'})).toString('base64url');
 const payload=Buffer.from(JSON.stringify({sub:playerId,iat:Math.floor(Date.now()/1000),exp:Math.floor(Date.now()/1000)+60*60*24*7})).toString('base64url');
 const input=header+'.'+payload;
 return input+'.'+createHmac('sha256',JWT_SECRET).update(input).digest('base64url');
}
// Anonymous guest sessions: no email, password, Google account, or registration screen.
app.post('/api/auth/guest',(req,res)=>{
 const guestKey=String(req.body?.guestKey||'');
 if(!/^[a-f0-9-]{32,64}$/i.test(guestKey))return fail(res,400,'Некоректний ідентифікатор гостьового профілю.');
 if(!rateLimit('guest:'+req.ip,20,60000))return fail(res,429,'Забагато запитів. Спробуй трохи пізніше.');
 const now=new Date().toISOString();
 let session=db.prepare('SELECT player_id FROM guest_sessions WHERE guest_key=?').get(guestKey);
 let playerId=session?.player_id;
 if(!playerId){
  playerId=randomBytes(16).toString('hex');
  const suffix=randomBytes(3).toString('hex').toUpperCase();
  const nickname='Гість-'+suffix;
  const fakeHash='guest$'+randomBytes(32).toString('hex');
  const tx=db.transaction(()=>{
   db.prepare('INSERT INTO players(id,nickname,password_hash,bio,home_region,created_at) VALUES(?,?,?,?,?,?)').run(playerId,nickname,fakeHash,'','',now);
   db.prepare('INSERT INTO guest_sessions(guest_key,player_id,created_at,last_seen_at) VALUES(?,?,?,?)').run(guestKey,playerId,now,now);
   db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) VALUES(?,?)').run(playerId,now);
  });
  tx();
 }else db.prepare('UPDATE guest_sessions SET last_seen_at=? WHERE guest_key=?').run(now,guestKey);
 const player=db.prepare('SELECT id,nickname,bio,home_region,created_at FROM players WHERE id=?').get(playerId);
 res.json({ok:true,token:signToken(playerId),player,guest:true});
});

// Password-only accounts: nickname + password, no email or Google required.
function passwordRecord(password){
 const salt=randomBytes(16).toString('hex');
 const hash=scryptSync(password,salt,64).toString('hex');
 return `scrypt$${salt}$${hash}`;
}
function passwordMatches(password,record){
 const parts=String(record||'').split('$');
 if(parts.length!==3||parts[0]!=='scrypt')return false;
 const expected=Buffer.from(parts[2],'hex');
 const actual=scryptSync(password,parts[1],64);
 return expected.length===actual.length&&timingSafeEqual(expected,actual);
}
function validPassword(p){return typeof p==='string'&&p.length>=8&&p.length<=72;}
app.post('/api/auth/register',(req,res)=>{
 const nickname=String(req.body?.nickname||'').trim(),password=req.body?.password;
 if(!validNick(nickname)||!validPassword(password))return fail(res,400,'Нікнейм: 3–24 символи. Пароль: 8–72 символи.');
 if(!rateLimit('register:'+req.ip,5,60*60*1000))return fail(res,429,'Забагато спроб. Спробуй пізніше.');
 const id=randomBytes(16).toString('hex'),now=new Date().toISOString();
 try{db.prepare('INSERT INTO players(id,nickname,password_hash,bio,home_region,created_at) VALUES(?,?,?,?,?,?)').run(id,nickname,passwordRecord(password),'','',now);}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Такий нікнейм уже зайнятий.');throw e;}
 db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) VALUES(?,?)').run(id,now);
 res.status(201).json({ok:true,token:signToken(id),player:db.prepare('SELECT id,nickname,bio,home_region,created_at FROM players WHERE id=?').get(id)});
});
app.post('/api/auth/login',(req,res)=>{
 const nickname=String(req.body?.nickname||'').trim(),password=req.body?.password;
 if(!validNick(nickname)||typeof password!=='string')return fail(res,400,'Введи нікнейм і пароль.');
 if(!rateLimit('login:'+req.ip,10,15*60*1000))return fail(res,429,'Забагато спроб входу. Спробуй пізніше.');
 const player=db.prepare('SELECT id,nickname,password_hash,bio,home_region,created_at FROM players WHERE nickname=? COLLATE NOCASE').get(nickname);
 if(!player||!passwordMatches(password,player.password_hash))return fail(res,401,'Неправильний нікнейм або пароль.');
 db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) VALUES(?,?)').run(player.id,new Date().toISOString());
 const {password_hash,...publicPlayer}=player;
 res.json({ok:true,token:signToken(player.id),player:publicPlayer});
});
app.post('/api/auth/upgrade', (req,res)=>{
 const token=(req.headers.authorization||'').replace(/^Bearer\\s+/i,'');
 const parts=token.split('.'); if(parts.length!==3)return fail(res,401,'Гостьова сесія не знайдена.');
 const input=parts[0]+'.'+parts[1],expected=createHmac('sha256',JWT_SECRET).update(input).digest();
 let actual;try{actual=Buffer.from(parts[2],'base64url');}catch{return fail(res,401,'Недійсна сесія.');}
 if(actual.length!==expected.length||!timingSafeEqual(actual,expected))return fail(res,401,'Недійсна сесія.');
 let payload;try{payload=JSON.parse(Buffer.from(parts[1],'base64url').toString());}catch{return fail(res,401,'Недійсна сесія.');}
 if(!payload.sub||payload.exp<Date.now()/1000)return fail(res,401,'Гостьова сесія завершилася.');
 const guest=db.prepare('SELECT id FROM players WHERE id=?').get(payload.sub);
 if(!guest)return fail(res,404,'Гостьовий профіль не знайдено.');
 const nickname=String(req.body?.nickname||'').trim(),password=req.body?.password;
 if(!validNick(nickname)||!validPassword(password))return fail(res,400,'Нікнейм: 3–24 символи. Пароль: 8–72 символи.');
 try{db.prepare('UPDATE players SET nickname=?,password_hash=? WHERE id=?').run(nickname,passwordRecord(password),guest.id);}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Такий нікнейм уже зайнятий.');throw e;}
 db.prepare('DELETE FROM guest_sessions WHERE player_id=?').run(guest.id);
 res.json({ok:true,token:signToken(guest.id),player:db.prepare('SELECT id,nickname,bio,home_region,created_at FROM players WHERE id=?').get(guest.id)});
});

function auth(req,res,next){
 const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
 const parts=token.split('.');
 if(parts.length!==3) return fail(res,401,'Не вдалося відкрити гостьову сесію.');
 const input=parts[0]+'.'+parts[1];
 const expected=createHmac('sha256',JWT_SECRET).update(input).digest();
 let actual; try{actual=Buffer.from(parts[2],'base64url');}catch{return fail(res,401,'Недійсний токен.');}
 if(actual.length!==expected.length || !timingSafeEqual(actual,expected)) return fail(res,401,'Недійсний токен.');
 let payload; try{payload=JSON.parse(Buffer.from(parts[1],'base64url').toString());}catch{return fail(res,401,'Недійсний токен.');}
 if(!payload.sub || payload.exp<Date.now()/1000) return fail(res,401,'Сесія завершилася. Увійди знову.');
 const player=db.prepare('SELECT id,nickname,bio,home_region,created_at FROM players WHERE id=?').get(payload.sub);
 if(!player) return fail(res,401,'Акаунт не знайдено.');
 req.player=player; next();
}

// Player progression, regional gold mines and community articles.
// One-time starting reserve migration for existing players.
const startingGoldMigration=db.prepare("SELECT name FROM schema_migrations WHERE name='regional_starting_gold_500'").get();
if(!startingGoldMigration){
 const migrationTx=db.transaction(()=>{
  db.prepare('UPDATE player_region_wallets SET gold=500 WHERE gold<500').run();
  db.prepare("INSERT INTO schema_migrations(name,applied_at) VALUES('regional_starting_gold_500',?)").run(new Date().toISOString());
 });
 migrationTx();
}
function ensurePlayerGame(playerId){
 db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) VALUES(?,?)').run(playerId,new Date().toISOString());
 return db.prepare('SELECT * FROM player_game_stats WHERE player_id=?').get(playerId);
}
function ensureRegionWallet(playerId,regionKey,regionName){
 const now=Date.now();
 db.prepare('INSERT OR IGNORE INTO player_region_wallets(player_id,region_key,region_name,gold,last_refill_at) VALUES(?,?,?,500,?)').run(playerId,regionKey,regionName,now);
 let wallet=db.prepare('SELECT * FROM player_region_wallets WHERE player_id=? AND region_key=?').get(playerId,regionKey);
 const intervals=Math.floor((now-wallet.last_refill_at)/(12*60*60*1000));
 if(intervals>0){
  const refill=Math.min(intervals*100,5000);
  db.prepare('UPDATE player_region_wallets SET gold=gold+?,last_refill_at=? WHERE player_id=? AND region_key=?').run(refill,wallet.last_refill_at+intervals*12*60*60*1000,playerId,regionKey);
  wallet=db.prepare('SELECT * FROM player_region_wallets WHERE player_id=? AND region_key=?').get(playerId,regionKey);
 }
 return wallet;
}
// Automatic 12-hour gold income for every region wallet. If the free host sleeps,
// elapsed periods are credited on the next region request by ensureRegionWallet().
function refillAllRegionalWallets(){
 const now=Date.now();
 const due=db.prepare('SELECT player_id,region_key,last_refill_at FROM player_region_wallets WHERE last_refill_at <= ?').all(now-12*60*60*1000);
 if(!due.length)return;
 const update=db.prepare('UPDATE player_region_wallets SET gold=gold+?,last_refill_at=? WHERE player_id=? AND region_key=?');
 const tx=db.transaction(rows=>{for(const row of rows){const intervals=Math.floor((now-row.last_refill_at)/(12*60*60*1000));if(intervals>0){const credited=Math.min(intervals*100,5000);update.run(credited,row.last_refill_at+intervals*12*60*60*1000,row.player_id,row.region_key);}}});
 tx(due);
}
setInterval(refillAllRegionalWallets,60*1000).unref?.();
function gameProfile(playerId){
 const stats=ensurePlayerGame(playerId);
 return {xp:stats.xp,level:Number((stats.xp/1000).toFixed(1)),energy:stats.energy,avatar:stats.avatar};
}
app.get('/api/public/stats',(req,res)=>{
 const players=db.prepare('SELECT COUNT(*) AS n FROM players').get().n;
 const regions=db.prepare('SELECT COUNT(DISTINCT region_key) AS n FROM regional_game_profiles').get().n;
 const memberArticles=db.prepare('SELECT COUNT(*) AS n FROM game_articles').get().n;
 const guestArticles=db.prepare('SELECT COUNT(*) AS n FROM guest_articles').get().n;
 res.json({players,regions,articles:memberArticles+guestArticles});
});
app.get('/api/game/profile',auth,(req,res)=>{
 const profile=gameProfile(req.player.id);
 const rank=db.prepare('SELECT COUNT(*)+1 AS rank FROM player_game_stats WHERE xp>(SELECT xp FROM player_game_stats WHERE player_id=?)').get(req.player.id)?.rank||1;
 const total=db.prepare('SELECT COUNT(*) AS n FROM players').get().n;
 res.json({profile,rank,totalPlayers:total});
});
app.get('/api/game/region/:key',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.query.name||key).slice(0,100);
 if(!key||!/[A-Za-z0-9:_-]/.test(key))return fail(res,400,'Некоректний регіон.');
 const wallet=ensureRegionWallet(req.player.id,key,name),profile=gameProfile(req.player.id);
 res.json({region:{key,name:wallet.region_name,gold:wallet.gold,nextRefillAt:wallet.last_refill_at+12*60*60*1000},profile});
});
app.post('/api/game/region/:key/mine',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.body?.name||key).slice(0,100),energy=Number(req.body?.energy);
 if(![10,50,100,200,300,400,500].includes(energy))return fail(res,400,'Обери доступний обсяг енергії.');
 const wallet=ensureRegionWallet(req.player.id,key,name),stats=ensurePlayerGame(req.player.id);
 if(stats.energy<energy)return fail(res,409,'Недостатньо енергії. Придбай енергетики за золото.');
 const now=new Date().toISOString();
 const tx=db.transaction(()=>{
  db.prepare('UPDATE player_game_stats SET energy=energy-?,xp=xp+? WHERE player_id=?').run(energy,energy*5,req.player.id);
  db.prepare('UPDATE player_region_wallets SET gold=gold+? WHERE player_id=? AND region_key=?').run(energy,req.player.id,key);
 });
 tx();
 const updated=ensureRegionWallet(req.player.id,key,name);
 res.json({ok:true,earnedGold:energy,earnedXp:energy*5,wallet:updated,profile:gameProfile(req.player.id)});
});
app.post('/api/game/energy/buy',auth,(req,res)=>{
 const amount=Number(req.body?.amount);
 if(!Number.isInteger(amount)||amount<1||amount>500)return fail(res,400,'Кількість енергії має бути від 1 до 500.');
 const key=String(req.body?.regionKey||'').slice(0,120),name=String(req.body?.regionName||key).slice(0,100);
 if(!key)return fail(res,400,'Спочатку обери регіон.');
 const wallet=ensureRegionWallet(req.player.id,key,name),stats=ensurePlayerGame(req.player.id);
 const actual=Math.min(amount,500-stats.energy);
 if(actual<1)return fail(res,409,'Енергія вже заповнена до максимуму 500.');
 if(wallet.gold<actual)return fail(res,409,'Недостатньо золота.');
 const tx=db.transaction(()=>{
  db.prepare('UPDATE player_region_wallets SET gold=gold-? WHERE player_id=? AND region_key=?').run(actual,req.player.id,key);
  db.prepare('UPDATE player_game_stats SET energy=energy+? WHERE player_id=?').run(actual,req.player.id);
 });
 tx();res.json({ok:true,bought:actual,wallet:ensureRegionWallet(req.player.id,key,name),profile:gameProfile(req.player.id)});
});
app.post('/api/game/avatar/buy',auth,(req,res)=>{
 const avatar=String(req.body?.avatar||'').slice(0,8),key=String(req.body?.regionKey||'').slice(0,120),name=String(req.body?.regionName||key).slice(0,100);
 if(!avatar||!key)return fail(res,400,'Обери аватар і регіон.');
 const wallet=ensureRegionWallet(req.player.id,key,name);
 if(wallet.gold<50)return fail(res,409,'Для створення аватара потрібно 50 золота.');
 const tx=db.transaction(()=>{
  db.prepare('UPDATE player_region_wallets SET gold=gold-50 WHERE player_id=? AND region_key=?').run(req.player.id,key);
  db.prepare('UPDATE player_game_stats SET avatar=? WHERE player_id=?').run(avatar,req.player.id);
 });
 tx();res.json({ok:true,wallet:ensureRegionWallet(req.player.id,key,name),profile:gameProfile(req.player.id)});
});
app.get('/api/game/leaderboard',auth,(req,res)=>{
 db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) SELECT id,created_at FROM players').run();
 const rows=db.prepare(`SELECT p.id,p.nickname,p.home_region,s.xp,ROUND(s.xp/1000,1) AS level FROM players p JOIN player_game_stats s ON s.player_id=p.id ORDER BY s.xp DESC,p.created_at ASC LIMIT 100`).all();
 res.json({players:rows.map((p,i)=>({...p,rank:i+1})),totalPlayers:db.prepare('SELECT COUNT(*) n FROM players').get().n});
});

// Regional game mechanics: academies, parties, travel and scheduled elections.
app.get('/api/game/region/:key/politics',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120);
 const parties=db.prepare(`SELECT p.id,p.name,p.ideology,p.program,p.created_at,
 (SELECT COUNT(*) FROM regional_party_members m WHERE m.party_id=p.id) AS members,
 (SELECT nickname FROM players u WHERE u.id=p.player_id) AS leader,
 EXISTS(SELECT 1 FROM regional_party_members m WHERE m.party_id=p.id AND m.player_id=?) AS isMember
 FROM regional_parties p WHERE p.region_key=? ORDER BY p.created_at`).all(req.player.id,key);
 const election=db.prepare("SELECT id,created_at,eligible_at,status,result_json FROM regional_elections WHERE region_key=? ORDER BY created_at DESC LIMIT 1").get(key)||null;
 const presence=db.prepare('SELECT region_key,region_name FROM player_region_presence WHERE player_id=?').get(req.player.id)||null;
 res.json({parties,election,presence});
});
app.get('/api/game/party/:id',auth,(req,res)=>{
 const p=db.prepare(`SELECT p.id,p.name,p.ideology,p.program,p.region_name,p.created_at,u.nickname AS leader,
 (SELECT COUNT(*) FROM regional_party_members m WHERE m.party_id=p.id) AS members,
 (SELECT COUNT(*) FROM regional_party_members m WHERE m.party_id=p.id AND m.role<>'member') AS leadership,
 EXISTS(SELECT 1 FROM regional_party_members m WHERE m.party_id=p.id AND m.player_id=?) AS isMember
 FROM regional_parties p JOIN players u ON u.id=p.player_id WHERE p.id=?`).get(req.player.id,req.params.id);
 if(!p)return fail(res,404,'Партію не знайдено.');res.json({party:p,activeSalary:0,leadershipSalary:0});
});
app.post('/api/game/party/:id/join',auth,(req,res)=>{
 const p=db.prepare('SELECT id FROM regional_parties WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Партію не знайдено.');
 db.prepare("INSERT OR IGNORE INTO regional_party_members(party_id,player_id,role,joined_at) VALUES(?,?,'member',?)").run(p.id,req.player.id,Date.now());res.json({ok:true});
});
app.post('/api/game/party/:id/leave',auth,(req,res)=>{
 const p=db.prepare('SELECT player_id FROM regional_parties WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Партію не знайдено.');
 if(p.player_id===req.player.id)return fail(res,409,'Лідер партії не може вийти. Спочатку передай керівництво.');
 db.prepare('DELETE FROM regional_party_members WHERE party_id=? AND player_id=?').run(req.params.id,req.player.id);res.json({ok:true});
});

app.post('/api/game/region/:key/academy',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.body?.name||key).slice(0,100),now=Date.now();
 if(!key)return fail(res,400,'Спочатку обери регіон.');
 const previous=db.prepare('SELECT last_built_at FROM regional_academies WHERE player_id=? AND region_key=?').get(req.player.id,key);
 if(previous&&now-previous.last_built_at<6*60*60*1000){
  const next=previous.last_built_at+6*60*60*1000;
  return fail(res,409,'Наступну академію можна побудувати через '+Math.ceil((next-now)/60000)+' хв.');
 }
 const tx=db.transaction(()=>{
  db.prepare('INSERT INTO regional_academies(player_id,region_key,region_name,last_built_at) VALUES(?,?,?,?) ON CONFLICT(player_id,region_key) DO UPDATE SET region_name=excluded.region_name,last_built_at=excluded.last_built_at').run(req.player.id,key,name,now);
  ensureRegionWallet(req.player.id,key,name);
  db.prepare('UPDATE player_region_wallets SET gold=gold+100 WHERE player_id=? AND region_key=?').run(req.player.id,key);
  db.prepare('INSERT INTO academy_build_history(player_id,region_key,region_name,built_at) VALUES(?,?,?,?)').run(req.player.id,key,name,now);
  db.prepare(`INSERT INTO player_medals(player_id,medal_key,quantity) VALUES(?,'academy_builder',1)
    ON CONFLICT(player_id,medal_key) DO UPDATE SET quantity=quantity+1`).run(req.player.id);
  db.prepare(`INSERT INTO regional_game_profiles(region_key,region_name,updated_at,defense_index)
    VALUES(?,?,?,MIN(10,6))
    ON CONFLICT(region_key) DO UPDATE SET defense_index=MIN(10,regional_game_profiles.defense_index+1),updated_at=excluded.updated_at`).run(key,name,new Date().toISOString());
 });
 tx();
 res.json({ok:true,rewardGold:100,medal:{key:'academy_builder',quantity:db.prepare("SELECT quantity FROM player_medals WHERE player_id=? AND medal_key='academy_builder'").get(req.player.id).quantity},nextAvailableAt:now+6*60*60*1000,wallet:ensureRegionWallet(req.player.id,key,name)});
});
app.get('/api/game/region/:key/profile',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.query.name||key).slice(0,100),country=String(req.query.country||'').slice(0,80);
 if(!key)return fail(res,400,'Не вказано регіон.');
 db.prepare(`INSERT OR IGNORE INTO regional_game_profiles(region_key,region_name,country,updated_at)
 VALUES(?,?,?,?)`).run(key,name,country,new Date().toISOString());
 const profile=db.prepare('SELECT * FROM regional_game_profiles WHERE region_key=?').get(key);
 const residents=db.prepare('SELECT COUNT(*) n FROM regional_residencies WHERE region_key=?').get(key).n;
 const parties=db.prepare('SELECT COUNT(*) n FROM regional_parties WHERE region_key=?').get(key).n;
 const academies=db.prepare('SELECT COUNT(*) n FROM academy_build_history WHERE region_key=?').get(key).n;
 const governor=profile.governor_nickname||'Не призначений';
 const presidentStates=db.prepare(`SELECT s.id,s.name FROM game_states s JOIN state_territories t ON t.state_id=s.id
  WHERE s.owner_id=? AND t.territory_key=? ORDER BY s.created_at`).all(req.player.id,key);
 const latestDecree=db.prepare(`SELECT d.id,d.decree_text,d.created_at,p.nickname AS governor,s.name AS state_name
  FROM regional_presidential_decrees d JOIN players p ON p.id=d.governor_id JOIN game_states s ON s.id=d.state_id
  WHERE d.region_key=? ORDER BY d.created_at DESC LIMIT 1`).get(key)||null;
 res.json({profile,residents,parties,academies,governor,presidentStates,latestDecree});
});
app.post('/api/game/region/:key/decree',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120);
 const stateId=String(req.body?.stateId||'').slice(0,80);
 const nickname=String(req.body?.nickname||'').trim().slice(0,24);
 const decreeText=String(req.body?.decreeText||'Указ Президента про призначення губернатора').trim().slice(0,240);
 if(!key||!stateId||nickname.length<3)return fail(res,400,'Вкажи державу та нікнейм кандидата.');
 const state=db.prepare('SELECT id,name,owner_id FROM game_states WHERE id=?').get(stateId);
 if(!state)return fail(res,404,'Державу не знайдено.');
 if(state.owner_id!==req.player.id)return fail(res,403,'Указ може видати лише Президент — власник цієї держави.');
 const territory=db.prepare('SELECT territory_key FROM state_territories WHERE state_id=? AND territory_key=?').get(stateId,key);
 if(!territory)return fail(res,403,'Цей регіон не входить до складу держави, від імені якої видається указ.');
 const governor=db.prepare('SELECT id,nickname FROM players WHERE nickname=? COLLATE NOCASE').get(nickname);
 if(!governor)return fail(res,404,'Гравця з таким нікнеймом не знайдено.');
 const now=new Date().toISOString(),id=randomBytes(12).toString('hex');
 const tx=db.transaction(()=>{
  db.prepare(`INSERT INTO regional_administrations(state_id,territory_key,governor_id,appointed_by,updated_at)
   VALUES(?,?,?,?,?) ON CONFLICT(state_id,territory_key) DO UPDATE SET governor_id=excluded.governor_id,appointed_by=excluded.appointed_by,updated_at=excluded.updated_at`)
   .run(stateId,key,governor.id,req.player.id,now);
  db.prepare(`UPDATE regional_game_profiles SET governor_nickname=?,updated_at=? WHERE region_key=?`).run(governor.nickname,now,key);
  db.prepare(`INSERT INTO regional_presidential_decrees(id,state_id,region_key,governor_id,president_id,decree_text,created_at)
   VALUES(?,?,?,?,?,?,?)`).run(id,stateId,key,governor.id,req.player.id,decreeText,now);
 });
 tx();
 res.status(201).json({ok:true,decree:{id,state:state.name,region:key,governor:governor.nickname,text:decreeText,createdAt:now}});
});
app.post('/api/game/region/:key/residency',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.body?.name||key).slice(0,100),country=String(req.body?.country||'').slice(0,80);
 if(!key)return fail(res,400,'Спочатку обери регіон.');
 const existing=db.prepare('SELECT region_key,region_name FROM regional_residencies WHERE player_id=?').get(req.player.id);
 if(existing&&existing.region_key===key)return res.json({ok:true,alreadyRegistered:true,region:existing});
 const now=new Date().toISOString();
 const tx=db.transaction(()=>{
  db.prepare('INSERT INTO regional_residencies(player_id,region_key,region_name,registered_at) VALUES(?,?,?,?) ON CONFLICT(player_id) DO UPDATE SET region_key=excluded.region_key,region_name=excluded.region_name,registered_at=excluded.registered_at').run(req.player.id,key,name,now);
  db.prepare('UPDATE players SET home_region=? WHERE id=?').run(name,req.player.id);
  db.prepare('INSERT INTO player_region_presence(player_id,region_key,region_name,updated_at) VALUES(?,?,?,?) ON CONFLICT(player_id) DO UPDATE SET region_key=excluded.region_key,region_name=excluded.region_name,updated_at=excluded.updated_at').run(req.player.id,key,name,Date.now());
  db.prepare(`INSERT OR IGNORE INTO regional_game_profiles(region_key,region_name,country,updated_at) VALUES(?,?,?,?)`).run(key,name,country,now);
 });
 tx();
 res.json({ok:true,region:{key,name},registeredAt:now});
});
app.get('/api/game/medals',auth,(req,res)=>{
 const medals=db.prepare('SELECT medal_key,quantity FROM player_medals WHERE player_id=?').all(req.player.id);
 const academies=db.prepare('SELECT COUNT(*) n FROM academy_build_history WHERE player_id=?').get(req.player.id).n;
 res.json({medals,academyBuilds:academies});
});

app.post('/api/game/region/:key/party',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),regionName=String(req.body?.regionName||key).slice(0,100);
 const name=String(req.body?.name||'').trim(),ideology=String(req.body?.ideology||'').slice(0,60),program=String(req.body?.program||'').slice(0,1000);
 if(!key||name.length<3||name.length>60)return fail(res,400,'Назва партії має містити від 3 до 60 символів.');
 const wallet=ensureRegionWallet(req.player.id,key,regionName);
 if(wallet.gold<25)return fail(res,409,'Для створення партії потрібно 25 золота.');
 const id=randomBytes(12).toString('hex'),now=Date.now();
 try{
  const tx=db.transaction(()=>{
   db.prepare('UPDATE player_region_wallets SET gold=gold-25 WHERE player_id=? AND region_key=?').run(req.player.id,key);
   db.prepare('INSERT INTO regional_parties(id,player_id,region_key,region_name,name,ideology,program,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id,req.player.id,key,regionName,name,ideology,program,now);
   db.prepare("INSERT INTO regional_party_members(party_id,player_id,role,joined_at) VALUES(?,?,'leader',?)").run(id,req.player.id,now);
  });tx();
 }catch(e){return fail(res,409,'Партія з такою назвою вже існує в цьому регіоні.');}
 res.status(201).json({ok:true,id,costGold:25,party:{id,name,ideology,program,created_at:now},wallet:ensureRegionWallet(req.player.id,key,regionName)});
});
app.post('/api/game/travel',auth,(req,res)=>{
 const key=String(req.body?.regionKey||'').slice(0,120),name=String(req.body?.regionName||key).slice(0,100);
 if(!key)return fail(res,400,'Обери регіон для перельоту.');
 const wallet=ensureRegionWallet(req.player.id,key,name);
 if(wallet.gold<50)return fail(res,409,'Для перельоту потрібно 50 золота.');
 const now=Date.now();
 const tx=db.transaction(()=>{
  db.prepare('UPDATE player_region_wallets SET gold=gold-50 WHERE player_id=? AND region_key=?').run(req.player.id,key);
  db.prepare('INSERT INTO player_region_presence(player_id,region_key,region_name,updated_at) VALUES(?,?,?,?) ON CONFLICT(player_id) DO UPDATE SET region_key=excluded.region_key,region_name=excluded.region_name,updated_at=excluded.updated_at').run(req.player.id,key,name,now);
 });tx();
 res.json({ok:true,costGold:50,presence:{regionKey:key,regionName:name},wallet:ensureRegionWallet(req.player.id,key,name)});
});
app.post('/api/game/region/:key/election',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.body?.name||key).slice(0,100),now=Date.now();
 const parties=db.prepare('SELECT id,name FROM regional_parties WHERE region_key=? ORDER BY created_at').all(key);
 if(!key||!parties.length)return fail(res,409,'Спочатку створи хоча б одну партію в цьому регіоні.');
 const first=db.prepare('SELECT MIN(created_at) AS first_at FROM regional_parties WHERE region_key=?').get(key).first_at;
 const eligibleAt=first+3*60*60*1000;
 if(now<eligibleAt)return fail(res,409,'Вибори можна провести через '+Math.ceil((eligibleAt-now)/60000)+' хвилин після створення першої партії.');
 const existing=db.prepare("SELECT id FROM regional_elections WHERE region_key=? AND status='scheduled'").get(key);
 if(existing)return fail(res,409,'Вибори для цього регіону вже заплановані.');
 const id=randomBytes(12).toString('hex');
 db.prepare("INSERT INTO regional_elections(id,region_key,region_name,created_at,eligible_at,status) VALUES(?,?,?,?,?,'scheduled')").run(id,key,name,now,now);
 res.status(201).json({ok:true,id,eligibleAt,parties});
});
app.get('/api/game/region/:key/election',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120);
 const election=db.prepare('SELECT * FROM regional_elections WHERE region_key=? ORDER BY created_at DESC LIMIT 1').get(key)||null;
 const parties=db.prepare('SELECT id,name,ideology,created_at FROM regional_parties WHERE region_key=? ORDER BY created_at').all(key);
 res.json({election,parties});
});

// Shared online world chat. Messages are stored centrally and clients poll for updates.
app.get('/api/public/chat',(req,res)=>{
 const after=Math.max(0,Number(req.query.after)||0);
 const messages=db.prepare('SELECT id,author_name AS author,body,image_data AS imageData,created_at FROM world_chat_messages WHERE id>? ORDER BY id ASC LIMIT 100').all(after);
 const latest=db.prepare('SELECT COALESCE(MAX(id),0) AS id FROM world_chat_messages').get().id;
 res.json({messages,latest});
});
app.post('/api/public/chat',(req,res)=>{
 const ip=String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim();
 if(!rateLimit('world-chat:'+ip,20,60000))return fail(res,429,'Зачекай перед наступним повідомленням.');
 const {author='Гість',body='',imageData=''}=req.body||{};
 if(typeof body!=='string'||body.length>500||typeof imageData!=='string'||imageData.length>5_000_000||(!body.trim()&&!imageData))return fail(res,400,'Додай текст або зображення (до 3,5 МБ).');
 if(imageData&&!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(imageData))return fail(res,400,'Підтримуються JPG, PNG або WEBP.');
 const authorName=typeof author==='string'&&author.trim()?author.trim().slice(0,24):'Гість';
 const info=db.prepare('INSERT INTO world_chat_messages(author_name,body,image_data,created_at) VALUES(?,?,?,?)').run(authorName,body.trim(),imageData,new Date().toISOString());
 res.status(201).json({ok:true,id:Number(info.lastInsertRowid)});
});

// Public community articles: reading and publishing do not require an account.
app.get('/api/public/articles',(req,res)=>{
 const rows=db.prepare(`SELECT a.id,a.author_name AS author,a.title,a.body,a.category,a.created_at,
 (SELECT COALESCE(SUM(value),0) FROM guest_article_votes v WHERE v.article_id=a.id) AS score,
 (SELECT COUNT(*) FROM guest_article_comments c WHERE c.article_id=a.id) AS comments FROM guest_articles a ORDER BY a.created_at DESC LIMIT 100`).all();
 res.json({articles:rows});
});
app.post('/api/public/articles',(req,res)=>{
 const ip=String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim();
 if(!rateLimit('guest-article:'+ip,5,60*60*1000))return fail(res,429,'Забагато публікацій. Спробуй пізніше.');
 const {title,body,category='general',author='Гість',editKey=''}=req.body||{};
 if(typeof title!=='string'||title.trim().length<3||title.length>100||typeof body!=='string'||body.trim().length<20||body.length>5000000||typeof category!=='string'||category.length>24)return fail(res,400,'Перевір назву, текст і категорію статті.');
 const authorName=typeof author==='string'&&author.trim()?author.trim().slice(0,24):'Гість';
 const safeBody=body.replace(/<(?!\/?(?:p|br|strong|b|em|i|u|s|blockquote|ul|ol|li|h2|h3|a|img)\b)[^>]*>/gi,'').replace(/\s(on\w+|style|srcdoc)=("[^"]*"|'[^']*'|[^\s>]+)/gi,'').replace(/javascript:/gi,'').replace(/<img\b([^>]*)>/gi,(m,a)=>{const src=(a.match(/src=(?:"([^"]*)"|'([^']*)')/i)||[]).slice(1).find(Boolean)||'';return (/^https?:\/\//i.test(src)||/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/i.test(src))&&src.length<4500000?`<img src="${src.replace(/"/g,'&quot;')}" alt="">`:'';});
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 if(typeof editKey!=='string'||editKey.length<24||editKey.length>128)return fail(res,400,'Ключ редагування некоректний.');
 db.prepare('INSERT INTO guest_articles(id,author_name,title,body,category,created_at,edit_key) VALUES(?,?,?,?,?,?,?)').run(id,authorName,title.trim(),safeBody,category,now,articleEditHash(editKey));
 res.status(201).json({id,ok:true});
});
app.put('/api/public/articles/:id',(req,res)=>{
 const {title,body,category='general',editKey}=req.body||{};
 if(typeof editKey!=='string'||editKey.length<24||editKey.length>128)return fail(res,400,'Немає ключа редагування цієї статті.');
 const article=db.prepare('SELECT id,edit_key FROM guest_articles WHERE id=?').get(req.params.id);
 if(!article)return fail(res,404,'Статтю не знайдено.');
 const expected=Buffer.from(article.edit_key||''),actual=Buffer.from(articleEditHash(editKey));
 if(expected.length!==actual.length||!timingSafeEqual(expected,actual))return fail(res,403,'Немає дозволу редагувати цю статтю.');
 if(typeof title!=='string'||title.trim().length<3||title.length>100||typeof body!=='string'||body.trim().length<20||body.length>5000000||typeof category!=='string'||category.length>24)return fail(res,400,'Перевір назву, текст і категорію.');
 const safeBody=body.replace(/<(?!\/?(?:p|br|strong|b|em|i|u|s|blockquote|ul|ol|li|h2|h3|a|img)\b)[^>]*>/gi,'').replace(/\s(on\w+|style|srcdoc)=("[^"]*"|'[^']*'|[^\s>]+)/gi,'').replace(/javascript:/gi,'').replace(/<img\b([^>]*)>/gi,(m,a)=>{const src=(a.match(/src=(?:"([^"]*)"|'([^']*)')/i)||[]).slice(1).find(Boolean)||'';return (/^https?:\/\//i.test(src)||/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/i.test(src))&&src.length<4500000?`<img src="${src.replace(/"/g,'&quot;')}" alt="">`:'';});
 db.prepare('UPDATE guest_articles SET title=?,body=?,category=? WHERE id=?').run(title.trim(),safeBody,category,article.id);
 res.json({ok:true,id:article.id});
});
app.post('/api/public/articles/:id/vote',(req,res)=>{
 const id=String(req.params.id||'');const {voterKey,value}=req.body||{};
 if(typeof voterKey!=='string'||voterKey.length<12||voterKey.length>100||![1,-1].includes(Number(value)))return fail(res,400,'Голос некоректний.');
 if(!db.prepare('SELECT id FROM guest_articles WHERE id=?').get(id))return fail(res,404,'Статтю не знайдено.');
 const previous=db.prepare('SELECT value FROM guest_article_votes WHERE article_id=? AND voter_key=?').get(id,voterKey);
 if(previous&&previous.value===Number(value))db.prepare('DELETE FROM guest_article_votes WHERE article_id=? AND voter_key=?').run(id,voterKey);
 else db.prepare('INSERT INTO guest_article_votes(article_id,voter_key,value,created_at) VALUES(?,?,?,?) ON CONFLICT(article_id,voter_key) DO UPDATE SET value=excluded.value,created_at=excluded.created_at').run(id,voterKey,Number(value),new Date().toISOString());
 const score=db.prepare('SELECT COALESCE(SUM(value),0) n FROM guest_article_votes WHERE article_id=?').get(id).n;
 res.json({ok:true,score,selected:previous&&previous.value===Number(value)?0:Number(value)});
});
app.get('/api/public/articles/:id/comments',(req,res)=>{
 const rows=db.prepare('SELECT id,author_name AS author,body,created_at FROM guest_article_comments WHERE article_id=? ORDER BY created_at ASC LIMIT 200').all(req.params.id);res.json({comments:rows});
});
app.post('/api/public/articles/:id/comments',(req,res)=>{
 const {author='Гість',body=''}=req.body||{};if(typeof body!=='string'||body.trim().length<1||body.length>1000)return fail(res,400,'Коментар має містити 1–1000 символів.');
 if(!db.prepare('SELECT id FROM guest_articles WHERE id=?').get(req.params.id))return fail(res,404,'Статтю не знайдено.');
 const id=randomBytes(12).toString('hex');db.prepare('INSERT INTO guest_article_comments(id,article_id,author_name,body,created_at) VALUES(?,?,?,?,?)').run(id,req.params.id,String(author||'Гість').slice(0,24),body.trim(),new Date().toISOString());res.status(201).json({ok:true,id});
});

app.get('/api/articles',auth,(req,res)=>{
 const rows=db.prepare(`SELECT a.id,a.title,a.body,a.category,a.created_at,a.updated_at,p.nickname AS author,(a.author_id=? ) AS is_owner FROM game_articles a JOIN players p ON p.id=a.author_id ORDER BY a.updated_at DESC LIMIT 100`).all(req.player.id);
 res.json({articles:rows});
});
app.post('/api/articles',auth,(req,res)=>{
 const {title,body,category='general'}=req.body||{};
 if(typeof title!=='string'||title.trim().length<3||title.length>100||typeof body!=='string'||body.trim().length<20||body.length>12000||typeof category!=='string'||category.length>24)return fail(res,400,'Перевір назву, текст і категорію статті.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 db.prepare('INSERT INTO game_articles(id,author_id,title,body,category,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(id,req.player.id,title.trim(),body.trim(),category,now,now);
 res.status(201).json({id});
});
app.patch('/api/articles/:id',auth,(req,res)=>{
 const article=db.prepare('SELECT * FROM game_articles WHERE id=?').get(req.params.id);
 if(!article)return fail(res,404,'Статтю не знайдено.');
 if(article.author_id!==req.player.id)return fail(res,403,'Редагувати можна лише власні статті.');
 const {title,body,category=article.category}=req.body||{};
 if(typeof title!=='string'||title.trim().length<3||title.length>100||typeof body!=='string'||body.trim().length<20||body.length>12000||typeof category!=='string'||category.length>24)return fail(res,400,'Перевір назву, текст і категорію.');
 db.prepare('UPDATE game_articles SET title=?,body=?,category=?,updated_at=? WHERE id=?').run(title.trim(),body.trim(),category,new Date().toISOString(),article.id);
 res.json({ok:true});
});
app.delete('/api/articles/:id',auth,(req,res)=>{
 const article=db.prepare('SELECT author_id FROM game_articles WHERE id=?').get(req.params.id);
 if(!article)return fail(res,404,'Статтю не знайдено.');
 if(article.author_id!==req.player.id)return fail(res,403,'Видаляти можна лише власні статті.');
 db.prepare('DELETE FROM game_articles WHERE id=?').run(req.params.id);res.json({ok:true});
});

app.get('/api/health',(req,res)=>res.json({ok:true,service:'Chemis World API',version:'2.6.0'}));

app.get('/api/me',auth,(req,res)=>res.json({player:req.player}));
app.patch('/api/me',auth,(req,res)=>{
 const {bio,homeRegion,nickname}=req.body||{};
 if(typeof bio!=='string'||bio.length>120||typeof homeRegion!=='string'||homeRegion.length>60||!validNick(nickname))return fail(res,400,'Перевір нікнейм, опис і назву регіону.');
 try{db.prepare('UPDATE players SET nickname=?,bio=?,home_region=? WHERE id=?').run(nickname.trim(),bio.trim(),homeRegion.trim(),req.player.id);}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Такий нікнейм уже зайнятий.');throw e;}
 res.json({player:db.prepare('SELECT id,nickname,bio,home_region,created_at FROM players WHERE id=?').get(req.player.id)});
});
app.get('/api/players',auth,(req,res)=>{
 const q=String(req.query.q||'').trim().slice(0,24);
 db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) SELECT id,created_at FROM players').run();
 const players=db.prepare(`SELECT p.id,p.nickname,p.bio,p.home_region,p.created_at,COALESCE(s.xp,0) AS xp,ROUND(COALESCE(s.xp,0)/1000,1) AS level FROM players p LEFT JOIN player_game_stats s ON s.player_id=p.id WHERE p.nickname LIKE ? ORDER BY xp DESC,p.nickname LIMIT 100`).all('%'+q+'%');
 res.json({players,total:db.prepare('SELECT COUNT(*) n FROM players').get().n});
});

// Shared state registry. All ownership checks are enforced on the server.
function stateView(id){
 const state=db.prepare('SELECT s.id,s.owner_id,s.name,s.capital,s.color,s.symbol,s.created_at,p.nickname AS owner_nickname FROM game_states s JOIN players p ON p.id=s.owner_id WHERE s.id=?').get(id);
 if(!state)return null;
 state.territories=db.prepare('SELECT territory_key FROM state_territories WHERE state_id=? ORDER BY added_at').all(id).map(x=>x.territory_key);
 return state;
}
app.get('/api/states',auth,(req,res)=>{
 const rows=db.prepare('SELECT id FROM game_states ORDER BY created_at DESC LIMIT 100').all();
 res.json({states:rows.map(x=>stateView(x.id))});
});
app.post('/api/states',auth,(req,res)=>{
 const {name,capital,color,symbol,territories}=req.body||{};
 if(typeof name!=='string'||name.trim().length<3||name.trim().length>40)return fail(res,400,'Назва держави має містити 3–40 символів.');
 if(typeof capital!=='string'||capital.trim().length<2||capital.trim().length>40)return fail(res,400,'Перевір назву столиці.');
 if(typeof color!=='string'||!/^#[0-9a-fA-F]{6}$/.test(color))return fail(res,400,'Некоректний колір прапора.');
 if(typeof symbol!=='string'||symbol.length>3)return fail(res,400,'Некоректний символ.');
 if(!Array.isArray(territories)||territories.length<1||territories.length>100)return fail(res,400,'Держава повинна мати від 1 до 100 територій.');
 const clean=[...new Set(territories.map(x=>typeof x==='string'?x.trim():'').filter(x=>x.length>0&&x.length<=180))];
 if(clean.length!==territories.length)return fail(res,400,'Перевір список територій: є повтори або некоректні значення.');
 const id=randomBytes(16).toString('hex'), now=new Date().toISOString();
 const insertState=db.prepare('INSERT INTO game_states(id,owner_id,name,capital,color,symbol,created_at) VALUES(?,?,?,?,?,?,?)');
 const insertTerritory=db.prepare('INSERT INTO state_territories(state_id,territory_key,added_at) VALUES(?,?,?)');
 try{
  const transaction=db.transaction(()=>{insertState.run(id,req.player.id,name.trim(),capital.trim(),color,symbol||'★',now);for(const key of clean)insertTerritory.run(id,key,now);});
  transaction();
 }catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Одна з територій уже належить іншій державі.');throw e;}
 res.status(201).json({state:stateView(id)});
});
app.post('/api/states/:id/territories',auth,(req,res)=>{
 const {territoryKey}=req.body||{};
 if(typeof territoryKey!=='string'||territoryKey.trim().length<1||territoryKey.trim().length>180)return fail(res,400,'Некоректна територія.');
 const state=db.prepare('SELECT id,owner_id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 if(state.owner_id!==req.player.id)return fail(res,403,'Лише власник може змінювати території цієї держави.');
 try{db.prepare('INSERT INTO state_territories(state_id,territory_key,added_at) VALUES(?,?,?)').run(state.id,territoryKey.trim(),new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Ця територія вже належить державі.');throw e;}
 res.status(201).json({state:stateView(state.id)});
});


// Server-authoritative political system: parties, one-person-one-vote elections and law proposals.
function ownedState(stateId,playerId){return db.prepare('SELECT * FROM game_states WHERE id=? AND owner_id=?').get(stateId,playerId);}
app.get('/api/states/:id/politics',auth,(req,res)=>{
 const state=db.prepare('SELECT id,name,owner_id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 const parties=db.prepare(`SELECT pp.id,pp.name,pp.ideology,pp.platform,pp.creator_id,p.nickname AS creator FROM political_parties pp JOIN players p ON p.id=pp.creator_id WHERE pp.state_id=? ORDER BY pp.created_at`).all(state.id);
 const elections=db.prepare('SELECT id,status,created_at,closes_at FROM state_elections WHERE state_id=? ORDER BY created_at DESC LIMIT 20').all(state.id).map(e=>{
  const results=db.prepare(`SELECT c.party_id,c.candidate_name,pp.name AS party_name,COUNT(v.voter_id) AS votes,COALESCE(ps.seats,0) AS seats FROM election_candidates c JOIN political_parties pp ON pp.id=c.party_id LEFT JOIN election_votes v ON v.election_id=c.election_id AND v.party_id=c.party_id LEFT JOIN parliament_seats ps ON ps.election_id=c.election_id AND ps.party_id=c.party_id WHERE c.election_id=? GROUP BY c.party_id`).all(e.id);
  return {...e,results};
 });
 const laws=db.prepare('SELECT id,title,description,status,created_at FROM state_laws WHERE state_id=? ORDER BY created_at DESC LIMIT 50').all(state.id).map(l=>{
  const tally=db.prepare("SELECT decision,COUNT(*) AS votes FROM law_votes WHERE law_id=? GROUP BY decision").all(l.id);
  return {...l,tally};
 });
 const government=db.prepare('SELECT * FROM state_governments WHERE state_id=?').get(state.id);
 const ministers=government?db.prepare('SELECT portfolio,minister_name FROM government_ministers WHERE state_id=? ORDER BY portfolio').all(state.id):[];
 const parliament=elections.filter(e=>e.status==='closed').slice(0,1).map(e=>({election_id:e.id,seats:db.prepare('SELECT ps.party_id,pp.name AS party_name,ps.seats FROM parliament_seats ps JOIN political_parties pp ON pp.id=ps.party_id WHERE ps.election_id=? ORDER BY ps.seats DESC').all(e.id)}))[0]||null;
 res.json({state,parties,elections,laws,government, ministers, parliament});
});
app.post('/api/states/:id/parties',auth,(req,res)=>{
 const state=db.prepare('SELECT id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 const {name,ideology='',platform=''}=req.body||{};
 if(typeof name!=='string'||name.trim().length<3||name.trim().length>50)return fail(res,400,'Назва партії має містити 3–50 символів.');
 if(typeof ideology!=='string'||ideology.length>60||typeof platform!=='string'||platform.length>300)return fail(res,400,'Перевір ідеологію та програму.');
 const id=randomBytes(12).toString('hex');
 try{db.prepare('INSERT INTO political_parties(id,state_id,creator_id,name,ideology,platform,created_at) VALUES(?,?,?,?,?,?,?)').run(id,state.id,req.player.id,name.trim(),ideology.trim(),platform.trim(),new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'У цій державі вже є партія з такою назвою.');throw e;}
 res.status(201).json({party:db.prepare('SELECT id,name,ideology,platform FROM political_parties WHERE id=?').get(id)});
});
app.post('/api/states/:id/elections',auth,(req,res)=>{
 if(!ownedState(req.params.id,req.player.id))return fail(res,403,'Вибори може оголосити лише власник держави.');
 const parties=db.prepare('SELECT id,name FROM political_parties WHERE state_id=?').all(req.params.id);
 if(parties.length<2)return fail(res,400,'Для виборів потрібно щонайменше дві партії.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{
  db.prepare('INSERT INTO state_elections(id,state_id,created_by,status,created_at) VALUES(?,?,?,"open",?)').run(id,req.params.id,req.player.id,now);
  const candidate=db.prepare('INSERT INTO election_candidates(election_id,party_id,candidate_name) VALUES(?,?,?)');
  for(const p of parties)candidate.run(id,p.id,p.name);
 });
 tx();res.status(201).json({electionId:id,status:'open'});
});
app.post('/api/elections/:id/vote',auth,(req,res)=>{
 const election=db.prepare('SELECT * FROM state_elections WHERE id=?').get(req.params.id);
 if(!election)return fail(res,404,'Вибори не знайдено.');
 if(election.status!=='open')return fail(res,409,'Голосування вже завершено.');
 const {partyId}=req.body||{};
 const candidate=db.prepare('SELECT 1 FROM election_candidates WHERE election_id=? AND party_id=?').get(election.id,partyId);
 if(!candidate)return fail(res,400,'Обрана партія не бере участі в цих виборах.');
 try{db.prepare('INSERT INTO election_votes(election_id,voter_id,party_id,created_at) VALUES(?,?,?,?)').run(election.id,req.player.id,partyId,new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Ти вже проголосував у цих виборах.');throw e;}
 res.status(201).json({ok:true,message:'Голос зараховано.'});
});
app.post('/api/elections/:id/close',auth,(req,res)=>{
 const election=db.prepare('SELECT * FROM state_elections WHERE id=?').get(req.params.id);
 if(!election)return fail(res,404,'Вибори не знайдено.');
 if(!ownedState(election.state_id,req.player.id))return fail(res,403,'Завершити вибори може лише власник держави.');
 const results=db.prepare(`SELECT c.party_id,c.candidate_name,pp.name AS party_name,COUNT(v.voter_id) AS votes FROM election_candidates c JOIN political_parties pp ON pp.id=c.party_id LEFT JOIN election_votes v ON v.election_id=c.election_id AND v.party_id=c.party_id WHERE c.election_id=? GROUP BY c.party_id ORDER BY votes DESC`).all(election.id);
 const total=results.reduce((n,r)=>n+r.votes,0);
 if(total===0)return fail(res,409,'Немає жодного голосу: вибори не можна завершити без учасників.');
 const seatsTotal=100;
 const allocations=results.map(r=>({...r,seats:total?Math.floor(r.votes/total*seatsTotal):0}));
 let remainder=seatsTotal-allocations.reduce((n,r)=>n+r.seats,0);
 allocations.sort((a,b)=>((total?b.votes/total*seatsTotal-Math.floor(b.votes/total*seatsTotal):0)-(total?a.votes/total*seatsTotal-Math.floor(a.votes/total*seatsTotal):0)));
 for(let i=0;i<remainder;i++)allocations[i%allocations.length].seats++;
 const tx=db.transaction(()=>{
  db.prepare('UPDATE state_elections SET status="closed" WHERE id=?').run(election.id);
  const put=db.prepare('INSERT OR REPLACE INTO parliament_seats(election_id,party_id,seats) VALUES(?,?,?)');
  for(const a of allocations)put.run(election.id,a.party_id,a.seats);
 });
 tx();
 res.json({status:'closed',results:allocations,seatsTotal});
});
app.post('/api/states/:id/laws',auth,(req,res)=>{
 const state=db.prepare('SELECT id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 const {title,description}=req.body||{};
 if(typeof title!=='string'||title.trim().length<4||title.length>80||typeof description!=='string'||description.length>1000)return fail(res,400,'Перевір назву та опис законопроєкту.');
 const id=randomBytes(12).toString('hex');
 db.prepare('INSERT INTO state_laws(id,state_id,author_id,title,description,created_at) VALUES(?,?,?,?,?,?)').run(id,state.id,req.player.id,title.trim(),description.trim(),new Date().toISOString());
 res.status(201).json({law:{id,title:title.trim(),status:'proposed'}});
});
app.post('/api/laws/:id/vote',auth,(req,res)=>{
 const law=db.prepare('SELECT * FROM state_laws WHERE id=?').get(req.params.id);
 if(!law)return fail(res,404,'Законопроєкт не знайдено.');
 if(law.status!=='proposed')return fail(res,409,'Голосування за цей законопроєкт уже завершено.');
 const {decision}=req.body||{};
 if(!['yes','no'].includes(decision))return fail(res,400,'Вкажи yes або no.');
 const latest=db.prepare("SELECT id FROM state_elections WHERE state_id=? AND status='closed' ORDER BY created_at DESC LIMIT 1").get(law.state_id);
 if(!latest)return fail(res,409,'Спочатку мають відбутися вибори до парламенту.');
 const membership=db.prepare('SELECT 1 FROM parliament_seats WHERE election_id=? AND seats>0 LIMIT 1').get(latest.id);
 if(!membership)return fail(res,409,'Парламент ще не сформовано.');
 try{db.prepare('INSERT INTO law_votes(law_id,voter_id,decision,created_at) VALUES(?,?,?,?)').run(law.id,req.player.id,decision,new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Твій голос за цей законопроєкт уже враховано.');throw e;}
 const tally=db.prepare('SELECT decision,COUNT(*) AS votes FROM law_votes WHERE law_id=? GROUP BY decision').all(law.id);
 const yes=tally.find(x=>x.decision==='yes')?.votes||0,no=tally.find(x=>x.decision==='no')?.votes||0;
 // The simple public prototype closes when the state owner reviews the result, not automatically.
 res.status(201).json({ok:true,tally:{yes,no},message:'Голос депутата/учасника зараховано.'});
});


app.post('/api/states/:id/government',auth,(req,res)=>{
 if(!ownedState(req.params.id,req.player.id))return fail(res,403,'Уряд може сформувати лише власник держави.');
 const latest=db.prepare("SELECT id FROM state_elections WHERE state_id=? AND status='closed' ORDER BY created_at DESC LIMIT 1").get(req.params.id);
 if(!latest)return fail(res,409,'Спочатку заверши вибори та сформуй парламент.');
 const {primeMinister,ministers}=req.body||{};
 if(typeof primeMinister!=='string'||primeMinister.trim().length<2||primeMinister.length>60||!Array.isArray(ministers)||ministers.length>12)return fail(res,400,'Перевір кандидатуру прем’єр-міністра та склад уряду.');
 const valid=['Фінанси','Освіта','Інфраструктура','Охорона здоров’я','Зовнішні справи','Культура','Екологія','Цифровізація'];
 for(const m of ministers)if(!m||!valid.includes(m.portfolio)||typeof m.name!=='string'||m.name.trim().length<2||m.name.length>60)return fail(res,400,'Некоректні дані міністра.');
 const tx=db.transaction(()=>{
  db.prepare('INSERT OR REPLACE INTO state_governments(state_id,election_id,prime_minister,formed_by,formed_at) VALUES(?,?,?,?,?)').run(req.params.id,latest.id,primeMinister.trim(),req.player.id,new Date().toISOString());
  db.prepare('DELETE FROM government_ministers WHERE state_id=?').run(req.params.id);
  const put=db.prepare('INSERT INTO government_ministers(state_id,portfolio,minister_name) VALUES(?,?,?)');
  for(const m of ministers)put.run(req.params.id,m.portfolio,m.name.trim());
 });
 tx();res.status(201).json({ok:true,primeMinister:primeMinister.trim(),ministers:ministers.length});
});
app.post('/api/laws/:id/finalize',auth,(req,res)=>{
 const law=db.prepare('SELECT * FROM state_laws WHERE id=?').get(req.params.id);
 if(!law)return fail(res,404,'Законопроєкт не знайдено.');
 if(!ownedState(law.state_id,req.player.id))return fail(res,403,'Підсумкове рішення може підтвердити власник держави.');
 if(law.status!=='proposed')return fail(res,409,'Закон уже має остаточний статус.');
 const yes=db.prepare("SELECT COUNT(*) AS n FROM law_votes WHERE law_id=? AND decision='yes'").get(law.id).n;
 const no=db.prepare("SELECT COUNT(*) AS n FROM law_votes WHERE law_id=? AND decision='no'").get(law.id).n;
 if(yes===no)return fail(res,409,'Немає більшості: голоси порівну або їх ще немає.');
 const status=yes>no?'adopted':'rejected';
 db.prepare('UPDATE state_laws SET status=? WHERE id=?').run(status,law.id);
 res.json({status,yes,no});
});


// Regional administration and local council elections.
app.get('/api/states/:id/regions',auth,(req,res)=>{
 const state=db.prepare('SELECT id,name,owner_id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 const regions=db.prepare(`SELECT t.territory_key,ra.governor_id,p.nickname AS governor
 FROM state_territories t LEFT JOIN regional_administrations ra ON ra.state_id=t.state_id AND ra.territory_key=t.territory_key
 LEFT JOIN players p ON p.id=ra.governor_id WHERE t.state_id=? ORDER BY t.territory_key`).all(state.id);
 const elections=db.prepare(`SELECT e.id,e.territory_key,e.status,e.created_at,
 (SELECT COUNT(*) FROM regional_votes v WHERE v.election_id=e.id) AS turnout
 FROM regional_elections e WHERE e.state_id=? ORDER BY e.created_at DESC LIMIT 30`).all(state.id);
 const councils=db.prepare(`SELECT e.id,e.territory_key,c.candidate_name,c.votes,c.seats
 FROM regional_elections e JOIN regional_councils c ON c.election_id=e.id
 WHERE e.state_id=? ORDER BY e.created_at DESC,c.seats DESC`).all(state.id);
 res.json({state,regions,elections,councils});
});
app.post('/api/states/:id/regions/governor',auth,(req,res)=>{
 if(!ownedState(req.params.id,req.player.id))return fail(res,403,'Керівників регіонів призначає власник держави.');
 const {territoryKey,nickname}=req.body||{};
 if(typeof territoryKey!=='string'||typeof nickname!=='string'||!territoryKey.trim()||!nickname.trim())return fail(res,400,'Вкажи територію та нікнейм гравця.');
 const territory=db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,territoryKey.trim());
 if(!territory)return fail(res,404,'Ця територія не входить до складу держави.');
 const player=db.prepare('SELECT id FROM players WHERE nickname=? COLLATE NOCASE').get(nickname.trim());
 if(!player)return fail(res,404,'Гравця з таким нікнеймом не знайдено.');
 db.prepare(`INSERT INTO regional_administrations(state_id,territory_key,governor_id,appointed_by,updated_at)
 VALUES(?,?,?,?,?) ON CONFLICT(state_id,territory_key) DO UPDATE SET governor_id=excluded.governor_id,appointed_by=excluded.appointed_by,updated_at=excluded.updated_at`)
 .run(req.params.id,territoryKey.trim(),player.id,req.player.id,new Date().toISOString());
 res.json({ok:true,governor:nickname.trim()});
});
app.post('/api/states/:id/regions/elections',auth,(req,res)=>{
 if(!ownedState(req.params.id,req.player.id))return fail(res,403,'Місцеві вибори оголошує власник держави.');
 const {territoryKey,candidates}=req.body||{};
 if(typeof territoryKey!=='string'||!Array.isArray(candidates)||candidates.length<2||candidates.length>20)return fail(res,400,'Потрібно вказати територію та 2–20 кандидатів.');
 const key=territoryKey.trim();
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територія не належить цій державі.');
 const clean=[...new Set(candidates.map(x=>typeof x==='string'?x.trim():'').filter(x=>x.length>=2&&x.length<=60))];
 if(clean.length!==candidates.length)return fail(res,400,'Перевір імена кандидатів: повтори або некоректні значення.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{db.prepare('INSERT INTO regional_elections(id,state_id,territory_key,created_by,status,created_at) VALUES(?,?,?,?,"open",?)').run(id,req.params.id,key,req.player.id,now);const put=db.prepare('INSERT INTO regional_candidates(election_id,candidate_name) VALUES(?,?)');for(const c of clean)put.run(id,c);});
 tx();res.status(201).json({electionId:id,status:'open'});
});
app.get('/api/regions/elections/:id',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM regional_elections WHERE id=?').get(req.params.id);
 if(!e)return fail(res,404,'Місцеві вибори не знайдено.');
 const candidates=db.prepare(`SELECT c.candidate_name,COUNT(v.voter_id) AS votes,COALESCE(rc.seats,0) AS seats
 FROM regional_candidates c LEFT JOIN regional_votes v ON v.election_id=c.election_id AND v.candidate_name=c.candidate_name
 LEFT JOIN regional_councils rc ON rc.election_id=c.election_id AND rc.candidate_name=c.candidate_name
 WHERE c.election_id=? GROUP BY c.candidate_name ORDER BY votes DESC`).all(e.id);
 res.json({election:e,candidates});
});
app.post('/api/regions/elections/:id/vote',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM regional_elections WHERE id=?').get(req.params.id);
 if(!e)return fail(res,404,'Місцеві вибори не знайдено.');
 if(e.status!=='open')return fail(res,409,'Місцеве голосування завершено.');
 const {candidateName}=req.body||{};
 if(!db.prepare('SELECT 1 FROM regional_candidates WHERE election_id=? AND candidate_name=?').get(e.id,candidateName))return fail(res,400,'Такого кандидата немає у бюлетені.');
 try{db.prepare('INSERT INTO regional_votes(election_id,voter_id,candidate_name,created_at) VALUES(?,?,?,?)').run(e.id,req.player.id,candidateName,new Date().toISOString());}
 catch(err){if(String(err).includes('UNIQUE'))return fail(res,409,'Ти вже голосував на цих місцевих виборах.');throw err;}
 res.status(201).json({ok:true});
});
app.post('/api/regions/elections/:id/close',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM regional_elections WHERE id=?').get(req.params.id);
 if(!e)return fail(res,404,'Місцеві вибори не знайдено.');
 if(!ownedState(e.state_id,req.player.id))return fail(res,403,'Завершити місцеві вибори може лише власник держави.');
 if(e.status!=='open')return fail(res,409,'Вибори вже завершені.');
 const results=db.prepare(`SELECT c.candidate_name,COUNT(v.voter_id) AS votes FROM regional_candidates c LEFT JOIN regional_votes v ON v.election_id=c.election_id AND v.candidate_name=c.candidate_name WHERE c.election_id=? GROUP BY c.candidate_name`).all(e.id);
 const total=results.reduce((n,r)=>n+r.votes,0);
 if(!total)return fail(res,409,'Немає голосів: вибори не можна завершити.');
 const seats=15,alloc=results.map(r=>({...r,seats:Math.floor(r.votes/total*seats)}));
 let remaining=seats-alloc.reduce((n,r)=>n+r.seats,0);
 alloc.sort((a,b)=>(b.votes/total*seats-Math.floor(b.votes/total*seats))-(a.votes/total*seats-Math.floor(a.votes/total*seats)));
 for(let i=0;i<remaining;i++)alloc[i%alloc.length].seats++;
 const tx=db.transaction(()=>{db.prepare('UPDATE regional_elections SET status="closed" WHERE id=?').run(e.id);const put=db.prepare('INSERT INTO regional_councils(election_id,candidate_name,votes,seats) VALUES(?,?,?,?)');for(const r of alloc)put.run(e.id,r.candidate_name,r.votes,r.seats);});
 tx();res.json({status:'closed',council:alloc,seatsTotal:seats});
});


// Regional economy, public works, local laws and mayoral elections.
const REGION_BUILDINGS={
 'Школа':{cost:300,income:15},'Лікарня':{cost:450,income:20},
 'Дорога':{cost:250,income:25},'Культурний центр':{cost:220,income:12},
 'Водопостачання':{cost:350,income:18}
};
function ensureRegionalEconomy(stateId,key){
 db.prepare(`INSERT OR IGNORE INTO regional_economies(state_id,territory_key,updated_at) VALUES(?,?,?)`)
 .run(stateId,key,new Date().toISOString());
 return db.prepare('SELECT * FROM regional_economies WHERE state_id=? AND territory_key=?').get(stateId,key);
}
function canManageRegion(stateId,key,playerId){
 if(ownedState(stateId,playerId))return true;
 return !!db.prepare('SELECT 1 FROM regional_administrations WHERE state_id=? AND territory_key=? AND governor_id=?').get(stateId,key,playerId);
}
app.get('/api/states/:id/regions/:key/economy',auth,(req,res)=>{
 const key=req.params.key;
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 const economy=ensureRegionalEconomy(req.params.id,key);
 const buildings=db.prepare('SELECT id,building_type,level,created_at FROM regional_buildings WHERE state_id=? AND territory_key=? ORDER BY created_at').all(req.params.id,key);
 const mayor=db.prepare('SELECT mayor_name FROM regional_mayors WHERE state_id=? AND territory_key=?').get(req.params.id,key);
 const laws=db.prepare(`SELECT l.id,l.title,l.description,l.status,
 (SELECT COUNT(*) FROM regional_local_law_votes v WHERE v.law_id=l.id AND v.decision='yes') AS yes,
 (SELECT COUNT(*) FROM regional_local_law_votes v WHERE v.law_id=l.id AND v.decision='no') AS no
 FROM regional_local_laws l WHERE l.state_id=? AND l.territory_key=? ORDER BY l.created_at DESC LIMIT 30`).all(req.params.id,key);
 const elections=db.prepare(`SELECT e.id,e.status,e.winner,e.created_at,
 (SELECT COUNT(*) FROM mayor_votes v WHERE v.election_id=e.id) AS turnout
 FROM mayor_elections e WHERE e.state_id=? AND e.territory_key=? ORDER BY e.created_at DESC LIMIT 10`).all(req.params.id,key);
 res.json({economy,buildings,mayor:mayor?.mayor_name||null,laws,elections,buildingCatalog:REGION_BUILDINGS});
});
app.post('/api/states/:id/regions/:key/economy/tax',auth,(req,res)=>{
 const key=req.params.key,{taxRate}=req.body||{};
 if(!canManageRegion(req.params.id,key,req.player.id))return fail(res,403,'Змінювати місцеві податки може керівник регіону або власник держави.');
 if(!Number.isInteger(taxRate)||taxRate<0||taxRate>25)return fail(res,400,'Податкова ставка має бути від 0 до 25%.');
 ensureRegionalEconomy(req.params.id,key);
 db.prepare('UPDATE regional_economies SET tax_rate=?,updated_at=? WHERE state_id=? AND territory_key=?').run(taxRate,new Date().toISOString(),req.params.id,key);
 res.json({ok:true,taxRate});
});
app.post('/api/states/:id/regions/:key/economy/collect',auth,(req,res)=>{
 const key=req.params.key;
 if(!canManageRegion(req.params.id,key,req.player.id))return fail(res,403,'Збирати дохід може керівник регіону або власник держави.');
 const territory=db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key);
 if(!territory)return fail(res,404,'Територію не знайдено.');
 const e=ensureRegionalEconomy(req.params.id,key);
 const buildings=db.prepare('SELECT building_type,level FROM regional_buildings WHERE state_id=? AND territory_key=?').all(req.params.id,key);
 const buildingIncome=buildings.reduce((sum,b)=>sum+(REGION_BUILDINGS[b.building_type]?.income||0)*b.level,0);
 const income=Math.max(0,Math.floor((100+e.infrastructure_level*35+buildingIncome)*(1+e.tax_rate/100)));
 db.prepare('UPDATE regional_economies SET treasury=treasury+?,turn_number=turn_number+1,updated_at=? WHERE state_id=? AND territory_key=?').run(income,new Date().toISOString(),req.params.id,key);
 res.json({ok:true,income,turn:e.turn_number+1,treasury:e.treasury+income});
});
app.post('/api/states/:id/regions/:key/buildings',auth,(req,res)=>{
 const key=req.params.key,{buildingType}=req.body||{};
 if(!canManageRegion(req.params.id,key,req.player.id))return fail(res,403,'Будувати може керівник регіону або власник держави.');
 const spec=REGION_BUILDINGS[buildingType];if(!spec)return fail(res,400,'Невідомий тип будівлі.');
 const e=ensureRegionalEconomy(req.params.id,key);if(e.treasury<spec.cost)return fail(res,409,'Недостатньо коштів у бюджеті регіону.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{db.prepare('UPDATE regional_economies SET treasury=treasury-?,infrastructure_level=infrastructure_level+1,updated_at=? WHERE state_id=? AND territory_key=?').run(spec.cost,now,req.params.id,key);db.prepare('INSERT INTO regional_buildings(id,state_id,territory_key,building_type,level,created_by,created_at) VALUES(?,?,?,?,1,?,?)').run(id,req.params.id,key,buildingType,req.player.id,now);});
 tx();res.status(201).json({ok:true,id,cost:spec.cost,treasury:e.treasury-spec.cost});
});
app.post('/api/states/:id/regions/:key/laws',auth,(req,res)=>{
 const key=req.params.key,{title,description}=req.body||{};
 if(!canManageRegion(req.params.id,key,req.player.id))return fail(res,403,'Місцевий законопроєкт може подати керівник регіону або власник держави.');
 if(typeof title!=='string'||title.trim().length<3||title.length>80||typeof description!=='string'||description.trim().length<5||description.length>700)return fail(res,400,'Перевір назву та опис законопроєкту.');
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 const id=randomBytes(12).toString('hex');
 db.prepare('INSERT INTO regional_local_laws(id,state_id,territory_key,title,description,created_by,created_at) VALUES(?,?,?,?,?,?,?)').run(id,req.params.id,key,title.trim(),description.trim(),req.player.id,new Date().toISOString());
 res.status(201).json({id,status:'proposed'});
});
app.post('/api/regions/local-laws/:id/vote',auth,(req,res)=>{
 const law=db.prepare('SELECT * FROM regional_local_laws WHERE id=?').get(req.params.id);
 if(!law)return fail(res,404,'Місцевий законопроєкт не знайдено.');
 if(law.status!=='proposed')return fail(res,409,'Голосування завершено.');
 const {decision}=req.body||{};if(!['yes','no'].includes(decision))return fail(res,400,'Вкажи yes або no.');
 try{db.prepare('INSERT INTO regional_local_law_votes(law_id,voter_id,decision,created_at) VALUES(?,?,?,?)').run(law.id,req.player.id,decision,new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Ти вже голосував за цей законопроєкт.');throw e;}
 const yes=db.prepare("SELECT COUNT(*) n FROM regional_local_law_votes WHERE law_id=? AND decision='yes'").get(law.id).n;
 const no=db.prepare("SELECT COUNT(*) n FROM regional_local_law_votes WHERE law_id=? AND decision='no'").get(law.id).n;
 res.status(201).json({ok:true,yes,no});
});
app.post('/api/regions/local-laws/:id/finalize',auth,(req,res)=>{
 const law=db.prepare('SELECT * FROM regional_local_laws WHERE id=?').get(req.params.id);
 if(!law)return fail(res,404,'Місцевий законопроєкт не знайдено.');
 if(!canManageRegion(law.state_id,law.territory_key,req.player.id))return fail(res,403,'Результат підтверджує керівник регіону або власник держави.');
 if(law.status!=='proposed')return fail(res,409,'Законопроєкт уже завершено.');
 const yes=db.prepare("SELECT COUNT(*) n FROM regional_local_law_votes WHERE law_id=? AND decision='yes'").get(law.id).n;
 const no=db.prepare("SELECT COUNT(*) n FROM regional_local_law_votes WHERE law_id=? AND decision='no'").get(law.id).n;
 if(yes===no)return fail(res,409,'Немає більшості голосів.');
 const status=yes>no?'adopted':'rejected';
 db.prepare('UPDATE regional_local_laws SET status=? WHERE id=?').run(status,law.id);res.json({status,yes,no});
});
app.post('/api/states/:id/regions/:key/mayor-elections',auth,(req,res)=>{
 const key=req.params.key,{candidates}=req.body||{};
 if(!ownedState(req.params.id,req.player.id))return fail(res,403,'Вибори мера оголошує власник держави.');
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 if(!Array.isArray(candidates)||candidates.length<2||candidates.length>15)return fail(res,400,'Потрібно 2–15 кандидатів.');
 const clean=[...new Set(candidates.map(x=>typeof x==='string'?x.trim():'').filter(x=>x.length>=2&&x.length<=60))];
 if(clean.length!==candidates.length)return fail(res,400,'Перевір список кандидатів.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{db.prepare('INSERT INTO mayor_elections(id,state_id,territory_key,created_by,created_at) VALUES(?,?,?,?,?)').run(id,req.params.id,key,req.player.id,now);const put=db.prepare('INSERT INTO mayor_candidates(election_id,candidate_name) VALUES(?,?)');clean.forEach(x=>put.run(id,x));});
 tx();res.status(201).json({id,status:'open'});
});
app.get('/api/mayor-elections/:id',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM mayor_elections WHERE id=?').get(req.params.id);if(!e)return fail(res,404,'Вибори мера не знайдено.');
 const candidates=db.prepare(`SELECT c.candidate_name,COUNT(v.voter_id) votes FROM mayor_candidates c LEFT JOIN mayor_votes v ON v.election_id=c.election_id AND v.candidate_name=c.candidate_name WHERE c.election_id=? GROUP BY c.candidate_name ORDER BY votes DESC`).all(e.id);
 res.json({election:e,candidates});
});
app.post('/api/mayor-elections/:id/vote',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM mayor_elections WHERE id=?').get(req.params.id);if(!e)return fail(res,404,'Вибори мера не знайдено.');
 if(e.status!=='open')return fail(res,409,'Вибори завершено.');
 const {candidateName}=req.body||{};
 if(!db.prepare('SELECT 1 FROM mayor_candidates WHERE election_id=? AND candidate_name=?').get(e.id,candidateName))return fail(res,400,'Кандидата немає у бюлетені.');
 try{db.prepare('INSERT INTO mayor_votes(election_id,voter_id,candidate_name,created_at) VALUES(?,?,?,?)').run(e.id,req.player.id,candidateName,new Date().toISOString());}
 catch(err){if(String(err).includes('UNIQUE'))return fail(res,409,'Ти вже голосував на цих виборах.');throw err;}
 res.status(201).json({ok:true});
});
app.post('/api/mayor-elections/:id/close',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM mayor_elections WHERE id=?').get(req.params.id);if(!e)return fail(res,404,'Вибори мера не знайдено.');
 if(!ownedState(e.state_id,req.player.id))return fail(res,403,'Завершити вибори може власник держави.');
 if(e.status!=='open')return fail(res,409,'Вибори вже завершено.');
 const results=db.prepare(`SELECT c.candidate_name,COUNT(v.voter_id) votes FROM mayor_candidates c LEFT JOIN mayor_votes v ON v.election_id=c.election_id AND v.candidate_name=c.candidate_name WHERE c.election_id=? GROUP BY c.candidate_name ORDER BY votes DESC,c.candidate_name`).all(e.id);
 if(!results[0]?.votes)return fail(res,409,'Немає голосів.');
 const winner=results[0].candidate_name,now=new Date().toISOString();
 const tx=db.transaction(()=>{db.prepare("UPDATE mayor_elections SET status='closed',winner=? WHERE id=?").run(winner,e.id);db.prepare(`INSERT INTO regional_mayors(state_id,territory_key,mayor_name,election_id,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(state_id,territory_key) DO UPDATE SET mayor_name=excluded.mayor_name,election_id=excluded.election_id,updated_at=excluded.updated_at`).run(e.state_id,e.territory_key,winner,e.id,now);});
 tx();res.json({status:'closed',winner,results});
});


// Cities and urban development. All project costs are charged to the region's own treasury.
const CITY_PROJECTS={
 'Житловий квартал':{cost:400,population:800,level:0},
 'Школа':{cost:300,population:0,level:1},
 'Медичний центр':{cost:450,population:0,level:1},
 'Транспортний вузол':{cost:500,population:200,level:1},
 'Парк':{cost:220,population:100,level:1},
 'Комунальна мережа':{cost:350,population:0,level:1}
};
function cityManager(stateId,key,playerId){return canManageRegion(stateId,key,playerId);}
app.get('/api/states/:id/regions/:key/cities',auth,(req,res)=>{
 const key=req.params.key;
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 const cities=db.prepare(`SELECT c.id,c.name,c.population,c.urban_level,c.created_at,p.nickname AS mayor
 FROM cities c LEFT JOIN players p ON p.id=c.mayor_id
 WHERE c.state_id=? AND c.territory_key=? ORDER BY c.population DESC`).all(req.params.id,key);
 const projects=db.prepare(`SELECT p.city_id,p.project_type,p.level,p.created_at FROM city_projects p JOIN cities c ON c.id=p.city_id WHERE c.state_id=? AND c.territory_key=? ORDER BY p.created_at DESC`).all(req.params.id,key);
 res.json({cities,projects,catalog:CITY_PROJECTS});
});
app.post('/api/states/:id/regions/:key/cities',auth,(req,res)=>{
 const key=req.params.key,{name,population}=req.body||{};
 if(!cityManager(req.params.id,key,req.player.id))return fail(res,403,'Місто може заснувати керівник регіону або власник держави.');
 if(typeof name!=='string'||name.trim().length<2||name.trim().length>60)return fail(res,400,'Назва міста має містити 2–60 символів.');
 const pop=population===undefined?10000:population;
 if(!Number.isInteger(pop)||pop<1000||pop>5000000)return fail(res,400,'Початкове населення має бути від 1 000 до 5 000 000.');
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 try{db.prepare('INSERT INTO cities(id,state_id,territory_key,name,population,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(id,req.params.id,key,name.trim(),pop,req.player.id,now,now);}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Місто з такою назвою вже існує в цьому регіоні.');throw e;}
 res.status(201).json({id,name:name.trim(),population:pop,urbanLevel:1});
});
app.post('/api/cities/:id/mayor',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityManager(city.state_id,city.territory_key,req.player.id))return fail(res,403,'Призначати міського голову може керівник регіону або власник держави.');
 const {nickname}=req.body||{};
 if(typeof nickname!=='string'||nickname.trim().length<3||nickname.trim().length>24)return fail(res,400,'Вкажи нікнейм зареєстрованого гравця.');
 const player=db.prepare('SELECT id FROM players WHERE nickname=? COLLATE NOCASE').get(nickname.trim());
 if(!player)return fail(res,404,'Гравця з таким нікнеймом не знайдено.');
 db.prepare('UPDATE cities SET mayor_id=?,updated_at=? WHERE id=?').run(player.id,new Date().toISOString(),city.id);
 res.json({ok:true,mayor:nickname.trim()});
});
app.post('/api/cities/:id/projects',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityManager(city.state_id,city.territory_key,req.player.id))return fail(res,403,'Розвивати місто може керівник регіону або власник держави.');
 const {projectType}=req.body||{},spec=CITY_PROJECTS[projectType];if(!spec)return fail(res,400,'Невідомий міський проєкт.');
 const economy=ensureRegionalEconomy(city.state_id,city.territory_key);
 if(economy.treasury<spec.cost)return fail(res,409,'У бюджеті регіону недостатньо коштів.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{
  db.prepare('UPDATE regional_economies SET treasury=treasury-?,infrastructure_level=infrastructure_level+?,updated_at=? WHERE state_id=? AND territory_key=?').run(spec.cost,spec.level,now,city.state_id,city.territory_key);
  db.prepare('UPDATE cities SET population=population+?,urban_level=urban_level+1,updated_at=? WHERE id=?').run(spec.population,now,city.id);
  db.prepare('INSERT INTO city_projects(id,city_id,project_type,level,created_by,created_at) VALUES(?,?,?,1,?,?)').run(id,city.id,projectType,req.player.id,now);
 });
 tx();res.status(201).json({ok:true,cost:spec.cost,population:city.population+spec.population,urbanLevel:city.urban_level+1});
});
app.post('/api/cities/:id/growth',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityManager(city.state_id,city.territory_key,req.player.id))return fail(res,403,'Розрахувати приріст може керівник регіону або власник держави.');
 const growth=Math.max(1,Math.floor(city.population*0.01));
 db.prepare('UPDATE cities SET population=population+?,updated_at=? WHERE id=?').run(growth,new Date().toISOString(),city.id);
 res.json({ok:true,growth,population:city.population+growth});
});


// v1.8.0: elected city leadership, municipal council and independent city budgets.
function cityCanManage(city,playerId){
 if(city.mayor_id===playerId)return true;
 return canManageRegion(city.state_id,city.territory_key,playerId);
}
function ensureCityEconomy(cityId){
 db.prepare('INSERT OR IGNORE INTO city_economies(city_id,updated_at) VALUES(?,?)').run(cityId,new Date().toISOString());
 return db.prepare('SELECT * FROM city_economies WHERE city_id=?').get(cityId);
}
app.get('/api/cities/:id/governance',auth,(req,res)=>{
 const city=db.prepare('SELECT c.*,p.nickname AS mayor FROM cities c LEFT JOIN players p ON p.id=c.mayor_id WHERE c.id=?').get(req.params.id);
 if(!city)return fail(res,404,'Місто не знайдено.');
 const economy=ensureCityEconomy(city.id);
 const council=db.prepare('SELECT player_id,nickname,votes,seats FROM city_council_seats WHERE city_id=? ORDER BY seats DESC,votes DESC').all(city.id);
 const elections=db.prepare(`SELECT e.id,e.election_type,e.status,e.winner_nickname,e.created_at,
 (SELECT COUNT(*) FROM city_votes v WHERE v.election_id=e.id) turnout
 FROM city_elections e WHERE e.city_id=? ORDER BY e.created_at DESC LIMIT 20`).all(city.id);
 const proposals=db.prepare(`SELECT p.id,p.title,p.description,p.status,
 (SELECT COUNT(*) FROM city_proposal_votes v WHERE v.proposal_id=p.id AND v.decision='yes') yes,
 (SELECT COUNT(*) FROM city_proposal_votes v WHERE v.proposal_id=p.id AND v.decision='no') no
 FROM city_proposals p WHERE p.city_id=? ORDER BY p.created_at DESC LIMIT 20`).all(city.id);
 res.json({city,economy,council,elections,proposals});
});
app.post('/api/cities/:id/elections',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Міські вибори оголошує мер або керівник регіону.');
 const {electionType,candidates}=req.body||{};
 if(!['mayor','council'].includes(electionType))return fail(res,400,'Тип виборів має бути mayor або council.');
 if(!Array.isArray(candidates)||candidates.length<2||candidates.length>30)return fail(res,400,'Потрібно 2–30 кандидатів.');
 const clean=[...new Set(candidates.map(x=>typeof x==='string'?x.trim():'').filter(x=>x.length>=3&&x.length<=24))];
 if(clean.length!==candidates.length)return fail(res,400,'Вкажи нікнейми зареєстрованих гравців без повторів.');
 const players=clean.map(n=>db.prepare('SELECT id,nickname FROM players WHERE nickname=? COLLATE NOCASE').get(n));
 if(players.some(x=>!x))return fail(res,404,'Один або кілька кандидатів не мають зареєстрованих акаунтів.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{
  db.prepare('INSERT INTO city_elections(id,city_id,election_type,created_by,created_at) VALUES(?,?,?,?,?)').run(id,city.id,electionType,req.player.id,now);
  const put=db.prepare('INSERT INTO city_candidates(election_id,player_id,nickname) VALUES(?,?,?)');
  players.forEach(p=>put.run(id,p.id,p.nickname));
 });
 tx();res.status(201).json({id,status:'open',electionType});
});
app.get('/api/city-elections/:id',auth,(req,res)=>{
 const election=db.prepare('SELECT * FROM city_elections WHERE id=?').get(req.params.id);
 if(!election)return fail(res,404,'Вибори не знайдено.');
 const candidates=db.prepare(`SELECT c.player_id,c.nickname,COUNT(v.voter_id) votes FROM city_candidates c LEFT JOIN city_votes v ON v.election_id=c.election_id AND v.candidate_id=c.player_id WHERE c.election_id=? GROUP BY c.player_id ORDER BY votes DESC,c.nickname`).all(election.id);
 res.json({election,candidates});
});
app.post('/api/city-elections/:id/vote',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM city_elections WHERE id=?').get(req.params.id);
 if(!e)return fail(res,404,'Вибори не знайдено.');
 if(e.status!=='open')return fail(res,409,'Голосування завершено.');
 const {candidateId}=req.body||{};
 if(!db.prepare('SELECT 1 FROM city_candidates WHERE election_id=? AND player_id=?').get(e.id,candidateId))return fail(res,400,'Кандидата немає у бюлетені.');
 try{db.prepare('INSERT INTO city_votes(election_id,voter_id,candidate_id,created_at) VALUES(?,?,?,?)').run(e.id,req.player.id,candidateId,new Date().toISOString());}
 catch(err){if(String(err).includes('UNIQUE'))return fail(res,409,'Ти вже голосував на цих виборах.');throw err;}
 res.status(201).json({ok:true});
});
app.post('/api/city-elections/:id/close',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM city_elections WHERE id=?').get(req.params.id);
 if(!e)return fail(res,404,'Вибори не знайдено.');
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(e.city_id);
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Підтвердити результат може мер або керівник регіону.');
 if(e.status!=='open')return fail(res,409,'Вибори вже завершено.');
 const results=db.prepare(`SELECT c.player_id,c.nickname,COUNT(v.voter_id) votes FROM city_candidates c LEFT JOIN city_votes v ON v.election_id=c.election_id AND v.candidate_id=c.player_id WHERE c.election_id=? GROUP BY c.player_id ORDER BY votes DESC,c.nickname`).all(e.id);
 if(!results[0]?.votes)return fail(res,409,'Немає голосів.');
 const now=new Date().toISOString(),winner=results[0];
 const tx=db.transaction(()=>{
  db.prepare("UPDATE city_elections SET status='closed',winner_id=?,winner_nickname=? WHERE id=?").run(winner.player_id,winner.nickname,e.id);
  if(e.election_type==='mayor')db.prepare('UPDATE cities SET mayor_id=?,updated_at=? WHERE id=?').run(winner.player_id,now,city.id);
  else{
   db.prepare('DELETE FROM city_council_seats WHERE city_id=?').run(city.id);
   const total=15,sum=results.reduce((n,x)=>n+x.votes,0);
   let assigned=0;const shares=results.map(x=>{const exact=x.votes*total/sum;const seats=Math.floor(exact);assigned+=seats;return {...x,seats,rem:exact-seats};});
   shares.sort((x,y)=>y.rem-x.rem);for(let i=0;i<total-assigned;i++)shares[i].seats++;
   const put=db.prepare('INSERT INTO city_council_seats(city_id,player_id,nickname,votes,seats) VALUES(?,?,?,?,?)');
   shares.forEach(x=>{if(x.seats)put.run(city.id,x.player_id,x.nickname,x.votes,x.seats);});
  }
 });
 tx();res.json({status:'closed',winner:winner.nickname,results});
});
app.post('/api/cities/:id/municipal-tax',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Місцевий податок встановлює мер або керівник регіону.');
 const {taxRate}=req.body||{};if(!Number.isInteger(taxRate)||taxRate<0||taxRate>20)return fail(res,400,'Міський податок має бути від 0 до 20%.');
 ensureCityEconomy(city.id);db.prepare('UPDATE city_economies SET tax_rate=?,updated_at=? WHERE city_id=?').run(taxRate,new Date().toISOString(),city.id);
 res.json({ok:true,taxRate});
});
app.post('/api/cities/:id/municipal-income',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Міський дохід збирає мер або керівник регіону.');
 const e=ensureCityEconomy(city.id);
 const income=Math.floor((60+city.urban_level*20+Math.floor(city.population/1000))*(1+e.tax_rate/100));
 db.prepare('UPDATE city_economies SET treasury=treasury+?,turn_number=turn_number+1,updated_at=? WHERE city_id=?').run(income,new Date().toISOString(),city.id);
 res.json({income,treasury:e.treasury+income,turn:e.turn_number+1});
});
app.post('/api/cities/:id/municipal-projects',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Міський бюджетом керує мер або керівник регіону.');
 const {projectType}=req.body||{};
 const catalog={'Міське освітлення':180,'Прибирання вулиць':120,'Дитячий майданчик':160,'Бібліотека':240,'Пішохідна зона':200};
 const cost=catalog[projectType];if(!cost)return fail(res,400,'Невідомий муніципальний проєкт.');
 const e=ensureCityEconomy(city.id);if(e.treasury<cost)return fail(res,409,'У міському бюджеті недостатньо коштів.');
 const now=new Date().toISOString(),id=randomBytes(12).toString('hex');
 const tx=db.transaction(()=>{
  db.prepare('UPDATE city_economies SET treasury=treasury-?,updated_at=? WHERE city_id=?').run(cost,now,city.id);
  db.prepare('INSERT INTO city_projects(id,city_id,project_type,level,created_by,created_at) VALUES(?,?,?,1,?,?)').run(id,city.id,projectType,req.player.id,now);
 });
 tx();res.status(201).json({ok:true,cost,treasury:e.treasury-cost});
});
app.post('/api/cities/:id/proposals',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Місцеву ініціативу може подати мер або керівник регіону.');
 const {title,description}=req.body||{};
 if(typeof title!=='string'||title.trim().length<3||title.length>80||typeof description!=='string'||description.trim().length<5||description.length>500)return fail(res,400,'Перевір назву та опис пропозиції.');
 const id=randomBytes(12).toString('hex');
 db.prepare('INSERT INTO city_proposals(id,city_id,title,description,created_by,created_at) VALUES(?,?,?,?,?,?)').run(id,city.id,title.trim(),description.trim(),req.player.id,new Date().toISOString());
 res.status(201).json({id,status:'proposed'});
});
app.post('/api/city-proposals/:id/vote',auth,(req,res)=>{
 const p=db.prepare('SELECT * FROM city_proposals WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Пропозицію не знайдено.');
 if(p.status!=='proposed')return fail(res,409,'Голосування завершено.');
 const {decision}=req.body||{};if(!['yes','no'].includes(decision))return fail(res,400,'Вкажи yes або no.');
 try{db.prepare('INSERT INTO city_proposal_votes(proposal_id,voter_id,decision,created_at) VALUES(?,?,?,?)').run(p.id,req.player.id,decision,new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Ти вже голосував за цю пропозицію.');throw e;}
 const yes=db.prepare("SELECT COUNT(*) n FROM city_proposal_votes WHERE proposal_id=? AND decision='yes'").get(p.id).n;
 const no=db.prepare("SELECT COUNT(*) n FROM city_proposal_votes WHERE proposal_id=? AND decision='no'").get(p.id).n;
 res.status(201).json({yes,no});
});
app.post('/api/city-proposals/:id/finalize',auth,(req,res)=>{
 const p=db.prepare('SELECT * FROM city_proposals WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Пропозицію не знайдено.');
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(p.city_id);
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Результат підтверджує мер або керівник регіону.');
 if(p.status!=='proposed')return fail(res,409,'Пропозицію вже завершено.');
 const yes=db.prepare("SELECT COUNT(*) n FROM city_proposal_votes WHERE proposal_id=? AND decision='yes'").get(p.id).n;
 const no=db.prepare("SELECT COUNT(*) n FROM city_proposal_votes WHERE proposal_id=? AND decision='no'").get(p.id).n;
 if(yes===no)return fail(res,409,'Немає більшості голосів.');
 const status=yes>no?'adopted':'rejected';db.prepare('UPDATE city_proposals SET status=? WHERE id=?').run(status,p.id);
 res.json({status,yes,no});
});

app.use((err,req,res,next)=>{console.error(err.message);res.status(500).json({error:'Внутрішня помилка сервера.'});});
app.listen(PORT,'0.0.0.0',()=>console.log(`Chemis World API listening on ${PORT}`));
