# ChemisWorld 6.0.8 — об’єднана вебверсія

## Що об’єднано
- База вебверсії 6.0.5: компактна верхня плашка, мобільна адаптація `100dvh`, safe-area та оновлення кешу браузера.
- Функції 6.0.4: сторінка «Моя партія», запрошення гравців, завантаження емблеми з галереї, редагування назви/ідеології/опису, вихід і розпуск партії.
- Google-only облікові записи з гілки 6.0.6, переведені на Firebase Authentication.

## Авторизація
- Вхід та створення профілю — лише через Google у Firebase Authentication.
- Перший успішний вхід створює один серверний профіль; наступні входи відкривають його.
- Унікальний Google subject у `google_identities` не дозволяє створити другий профіль для того самого Google-акаунта.
- Гостьові й парольні маршрути повертають HTTP 410.
- Старий гостьовий профіль можна прив’язати, якщо в браузері ще є його чинний токен 6.0.5.
- Firebase ID token перевіряється сервером за публічними ключами Firebase Secure Token; service-account private key не потрібен.

## Одноразове налаштування Firebase
1. Відкрий Firebase Console: https://console.firebase.google.com/ і створи проєкт ChemisWorld (або вибери наявний).
2. У Authentication → Sign-in method увімкни Google.
3. У Project settings → General → Your apps додай Web app і скопіюй `apiKey`, `authDomain`, `projectId`, `appId` та `messagingSenderId`.
4. У Firebase Authentication → Settings → Authorized domains додай домен сайту (наприклад, `chemisworld.onrender.com`).
5. У Render → Environment додай ці значення як `FIREBASE_API_KEY`, `FIREBASE_AUTH_DOMAIN`, `FIREBASE_PROJECT_ID`, `FIREBASE_APP_ID`, `FIREBASE_MESSAGING_SENDER_ID`.
6. Збережи чинні `JWT_SECRET`, `DB_PATH` та Persistent Disk. Запусти Deploy.

Google Cloud Console і сервісний ключ вручну налаштовувати не потрібно. Створення Firebase-проєкту та ввімкнення Google provider у Firebase Console один раз усе одно має виконати власник проєкту.

## Важливо
- Це вебреліз; APK не змінюється.
- Не видаляй базу даних або Persistent Disk.
- Якщо наявні записи Google identity створювалися через попередню пряму Google-авторизацію, Firebase Google provider зазвичай повертає той самий Google subject; після першого входу перевір відповідність профілю.
- Перевірки локальні: синтаксис JS, серверний синтаксис, конфігурація та ZIP. Реальний Firebase sign-in і деплой потребують твого Firebase-проєкту та домену.
