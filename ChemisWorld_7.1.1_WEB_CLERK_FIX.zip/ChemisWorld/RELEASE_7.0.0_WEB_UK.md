# ChemisWorld 7.0.0 WEB

## Зміни
- Вхід і створення акаунта лише через Google за допомогою Clerk. Firebase Authentication більше не використовується.
- Сервер перевіряє Clerk session JWT через JWKS і підтверджує Google-провайдера через Clerk Backend API.
- Під час першого входу система повторно використовує попередній ігровий профіль Firebase, якщо збігається підтверджена Google-пошта.
- Прибрано згадки про гостьові профілі з інтерфейсу.
- Додано окрему нижню кнопку «Чат» та повноекранну сторінку чату.
- Чат підтримує текст, JPG/PNG/WEBP та MP4/WEBM/QuickTime до 8 МБ. Читання й надсилання вимагають авторизації.
- Існуюча SQLite база та ігрові механіки збережені; додано таблицю Clerk identities та поле типу медіа.

## Render Environment
- `JWT_SECRET` — залишити поточний секрет (щонайменше 32 символи).
- `CLERK_PUBLISHABLE_KEY` — Publishable Key із Clerk Dashboard.
- `CLERK_SECRET_KEY` — Secret Key із Clerk Dashboard.
- `CLERK_ISSUER` — необов’язковий; якщо не заданий, визначається з Publishable Key.
- `DB_PATH` — залишити чинний шлях до SQLite / persistent disk.
Firebase environment variables для 7.0.0 не потрібні.

## Clerk setup
1. Створи Clerk application.
2. У SSO connections увімкни Google для sign-up і sign-in. Залиш Google єдиним увімкненим способом входу.
3. У API keys скопіюй Publishable Key та Secret Key у Render Environment.
4. За потреби встанови точний issuer URL зі свого Clerk instance у `CLERK_ISSUER`; зазвичай можна залишити його автоматичне визначення.
5. Для production налаштуй власні Google OAuth credentials і redirect URI, які покаже Clerk Dashboard.
6. Перевір, що `https://chemisworld.onrender.com` дозволений у налаштуваннях домену Clerk.
7. Збережи зміни та дочекайся Render deploy.

Офіційна інструкція Google OAuth: https://clerk.com/docs/guides/configure/auth-strategies/social-connections/google

## Важливо
- Не публікуй `CLERK_SECRET_KEY` або `JWT_SECRET`.
- Медійні вкладення чату зберігаються в SQLite. Для Render потрібен чинний persistent disk, інакше медіа/дані можуть втратитися під час перезапуску.
- Ліміт одного медіафайлу — 8 МБ.
- Реальну авторизацію треба протестувати на Render після внесення Clerk keys.
