# ChemisWorld 7.0.2 WEB — Render deployment

1. Розпакуй ZIP зі збереженням структури `ChemisWorld/backend`.
2. Для Render використовуй папку `ChemisWorld/backend` як Root Directory або відповідний шлях у Build/Start Command.
3. Залиш чинні `JWT_SECRET` і `DB_PATH`, який вказує на Persistent Disk. Не змінюй і не видаляй їх під час оновлення.
4. Залиш чинні `CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY`, `CLERK_ISSUER`, `APP_ORIGIN` та `ALLOWED_ORIGINS`.
5. Запусти `npm install`, потім `npm start` (або використовуй налаштовані команди Render).
6. SQLite автоматично створить таблицю `player_game_saves`; ручна міграція не потрібна.

Це **WEB-реліз**. APK та Android-проєкт не оновлюються. Firebase Authentication для вебверсії не використовується.
