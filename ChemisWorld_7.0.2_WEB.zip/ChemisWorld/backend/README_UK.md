# ChemisWorld Backend 7.0.0 WEB

## Запуск
- Node.js 20 або новіший.
- `npm install` у папці `backend`.
- Скопіюй `.env.example` у `.env` і заповни значення.
- `npm start`.

## Environment
- `JWT_SECRET` — випадковий секрет щонайменше 32 символи; для оновлення залиш поточний.
- `DB_PATH` — шлях до SQLite; на Render має вказувати на Persistent Disk.
- `CLERK_PUBLISHABLE_KEY` — публічний ключ Clerk.
- `CLERK_SECRET_KEY` — секретний ключ Clerk; не публікуй його.
- `CLERK_ISSUER` — необов’язковий; за замовчуванням визначається з Publishable Key.
- `APP_ORIGIN` — домен браузерної версії, за замовчуванням `https://chemisworld.onrender.com`.
- `ALLOWED_ORIGINS` — дозволені origin для API.

## Google sign-in через Clerk
1. Створи Clerk application.
2. У SSO connections увімкни Google для sign-up і sign-in; для ChemisWorld залиш Google єдиним способом входу.
3. У API keys скопіюй Publishable Key і Secret Key у Render Environment.
4. Для production налаштуй власні Google OAuth credentials і redirect URI, які покаже Clerk Dashboard.
5. Дочекайся Render deploy і протестуй вхід через Google.

Сервер перевіряє Clerk session JWT через JWKS, перевіряє дозволений домен і Google provider через Clerk Backend API. Під час першого входу попередній ігровий профіль може бути збережений, якщо підтверджена Google-пошта збігається з адресою в старій Firebase identity.

## Дані та чат
- Ігрові дані зберігаються в SQLite; не видаляй Persistent Disk і не змінюй `DB_PATH`.
- Світовий чат доступний лише авторизованим користувачам.
- Чат підтримує текст, JPG/PNG/WEBP і MP4/WEBM/QuickTime до 8 МБ.
- Медіавкладення зберігаються в SQLite, тому для Render потрібен Persistent Disk.
- Не змінюй чинний `JWT_SECRET` під час оновлення.
