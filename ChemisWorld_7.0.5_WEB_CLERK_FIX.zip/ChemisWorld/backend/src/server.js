import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import Database from 'better-sqlite3';
import { randomBytes, timingSafeEqual, createHmac } from 'node:crypto';
import { createRemoteJWKSet, jwtVerify } from 'jose';
const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
const CLERK_PUBLISHABLE_KEY = process.env.CLERK_PUBLISHABLE_KEY || '';
const CLERK_SECRET_KEY = process.env.CLERK_SECRET_KEY || '';
const clerkFrontendHost = (() => { try { return Buffer.from((CLERK_PUBLISHABLE_KEY.split('_')[2] || ''), 'base64').toString('utf8').replace(/\$$/, ''); } catch { return ''; } })();
const clerkFrontendOrigin = clerkFrontendHost ? `https://${clerkFrontendHost}` : '';
const CLERK_ISSUER = String(process.env.CLERK_ISSUER || clerkFrontendOrigin).replace(/\/$/, '');
const clerkJwks = CLERK_ISSUER ? createRemoteJWKSet(new URL(`${CLERK_ISSUER}/.well-known/jwks.json`)) : null;
const DB_PATH = process.env.DB_PATH || './data/chemis-world.sqlite';
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('Set JWT_SECRET to a random value of at least 32 characters in backend/.env');
  process.exit(1);
}
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x=>x.trim()).filter(Boolean);
const clerkAuthorizedParties = new Set([...allowedOrigins, process.env.APP_ORIGIN || 'https://chemisworld.onrender.com']);
app.use(helmet({
  crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' },
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://cdn.jsdelivr.net", ...(clerkFrontendOrigin ? [clerkFrontendOrigin] : [])],
      styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net", ...(clerkFrontendOrigin ? [clerkFrontendOrigin] : [])],
      imgSrc: ["'self'", "data:", "blob:", "https:"],
      connectSrc: ["'self'", "https:", ...(clerkFrontendOrigin ? [clerkFrontendOrigin] : [])],
      frameSrc: ["'self'", ...(clerkFrontendOrigin ? [clerkFrontendOrigin] : [])],
      fontSrc: ["'self'", "data:", "https://cdn.jsdelivr.net"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(cors({origin(origin,cb){ if(!origin || allowedOrigins.length===0 || allowedOrigins.includes(origin)) return cb(null,true); cb(new Error('Origin not allowed')); }}));
app.use(express.json({limit:'16mb'}));
const fs = await import('node:fs');
fs.mkdirSync(new URL('../data/', import.meta.url), {recursive:true});
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS players(
 id TEXT PRIMARY KEY, nickname TEXT NOT NULL COLLATE NOCASE UNIQUE,
 password_hash TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '',
 home_region TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_players_nickname ON players(nickname);
CREATE TABLE IF NOT EXISTS clerk_identities(
 clerk_user_id TEXT PRIMARY KEY, player_id TEXT NOT NULL UNIQUE REFERENCES players(id) ON DELETE CASCADE,
 email TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS google_identities(
 google_sub TEXT PRIMARY KEY, player_id TEXT NOT NULL UNIQUE REFERENCES players(id) ON DELETE CASCADE,
 email TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS google_oauth_states(
 state TEXT PRIMARY KEY, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS game_states(
 id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES players(id),
 name TEXT NOT NULL, capital TEXT NOT NULL, color TEXT NOT NULL,
 symbol TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS political_parties(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 creator_id TEXT NOT NULL REFERENCES players(id), name TEXT NOT NULL,
 ideology TEXT NOT NULL DEFAULT '', platform TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL, UNIQUE(state_id,name)
);
CREATE TABLE IF NOT EXISTS state_elections(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 created_by TEXT NOT NULL REFERENCES players(id), status TEXT NOT NULL DEFAULT 'open',
 created_at TEXT NOT NULL, closes_at TEXT
);
CREATE TABLE IF NOT EXISTS election_candidates(
 election_id TEXT NOT NULL REFERENCES state_elections(id) ON DELETE CASCADE,
 party_id TEXT NOT NULL REFERENCES political_parties(id), candidate_name TEXT NOT NULL,
 PRIMARY KEY(election_id,party_id)
);
CREATE TABLE IF NOT EXISTS election_votes(
 election_id TEXT NOT NULL REFERENCES state_elections(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), party_id TEXT NOT NULL REFERENCES political_parties(id),
 created_at TEXT NOT NULL, PRIMARY KEY(election_id,voter_id)
);
CREATE TABLE IF NOT EXISTS state_laws(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 author_id TEXT NOT NULL REFERENCES players(id), title TEXT NOT NULL,
 description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'proposed',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS parliament_seats(
 election_id TEXT NOT NULL REFERENCES state_elections(id) ON DELETE CASCADE,
 party_id TEXT NOT NULL REFERENCES political_parties(id), seats INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(election_id,party_id)
);
CREATE TABLE IF NOT EXISTS law_votes(
 law_id TEXT NOT NULL REFERENCES state_laws(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), decision TEXT NOT NULL CHECK(decision IN ('yes','no')),
 created_at TEXT NOT NULL, PRIMARY KEY(law_id,voter_id)
);
CREATE TABLE IF NOT EXISTS state_governments(
 state_id TEXT PRIMARY KEY REFERENCES game_states(id) ON DELETE CASCADE,
 election_id TEXT REFERENCES state_elections(id), prime_minister TEXT NOT NULL,
 formed_by TEXT NOT NULL REFERENCES players(id), formed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS government_ministers(
 state_id TEXT NOT NULL REFERENCES state_governments(state_id) ON DELETE CASCADE,
 portfolio TEXT NOT NULL, minister_name TEXT NOT NULL,
 PRIMARY KEY(state_id,portfolio)
);
CREATE TABLE IF NOT EXISTS regional_administrations(
 state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 territory_key TEXT NOT NULL, governor_id TEXT NOT NULL REFERENCES players(id),
 appointed_by TEXT NOT NULL REFERENCES players(id), updated_at TEXT NOT NULL,
 PRIMARY KEY(state_id,territory_key),
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS regional_elections(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 created_by TEXT NOT NULL REFERENCES players(id), status TEXT NOT NULL DEFAULT 'open',
 created_at TEXT NOT NULL,
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS regional_candidates(
 election_id TEXT NOT NULL REFERENCES regional_elections(id) ON DELETE CASCADE,
 candidate_name TEXT NOT NULL, PRIMARY KEY(election_id,candidate_name)
);
CREATE TABLE IF NOT EXISTS regional_votes(
 election_id TEXT NOT NULL REFERENCES regional_elections(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), candidate_name TEXT NOT NULL,
 created_at TEXT NOT NULL, PRIMARY KEY(election_id,voter_id)
);
CREATE TABLE IF NOT EXISTS regional_councils(
 election_id TEXT NOT NULL REFERENCES regional_elections(id) ON DELETE CASCADE,
 candidate_name TEXT NOT NULL, votes INTEGER NOT NULL, seats INTEGER NOT NULL,
 PRIMARY KEY(election_id,candidate_name)
);
CREATE TABLE IF NOT EXISTS regional_economies(
 state_id TEXT NOT NULL, territory_key TEXT NOT NULL, treasury INTEGER NOT NULL DEFAULT 1000,
 tax_rate INTEGER NOT NULL DEFAULT 10, infrastructure_level INTEGER NOT NULL DEFAULT 1,
 turn_number INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL,
 PRIMARY KEY(state_id,territory_key),
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS regional_buildings(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 building_type TEXT NOT NULL, level INTEGER NOT NULL DEFAULT 1,
 created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL,
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS regional_local_laws(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 title TEXT NOT NULL, description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'proposed',
 created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL,
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS regional_local_law_votes(
 law_id TEXT NOT NULL REFERENCES regional_local_laws(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), decision TEXT NOT NULL CHECK(decision IN ('yes','no')),
 created_at TEXT NOT NULL, PRIMARY KEY(law_id,voter_id)
);
CREATE TABLE IF NOT EXISTS mayor_elections(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open', winner TEXT, created_by TEXT NOT NULL REFERENCES players(id),
 created_at TEXT NOT NULL,
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS mayor_candidates(
 election_id TEXT NOT NULL REFERENCES mayor_elections(id) ON DELETE CASCADE,
 candidate_name TEXT NOT NULL, PRIMARY KEY(election_id,candidate_name)
);
CREATE TABLE IF NOT EXISTS mayor_votes(
 election_id TEXT NOT NULL REFERENCES mayor_elections(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), candidate_name TEXT NOT NULL,
 created_at TEXT NOT NULL, PRIMARY KEY(election_id,voter_id)
);
CREATE TABLE IF NOT EXISTS regional_mayors(
 state_id TEXT NOT NULL, territory_key TEXT NOT NULL, mayor_name TEXT NOT NULL,
 election_id TEXT NOT NULL REFERENCES mayor_elections(id), updated_at TEXT NOT NULL,
 PRIMARY KEY(state_id,territory_key),
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS cities(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 name TEXT NOT NULL, population INTEGER NOT NULL DEFAULT 10000,
 urban_level INTEGER NOT NULL DEFAULT 1, mayor_id TEXT REFERENCES players(id),
 created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(state_id,territory_key,name),
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS city_economies(
 city_id TEXT PRIMARY KEY REFERENCES cities(id) ON DELETE CASCADE,
 treasury INTEGER NOT NULL DEFAULT 500, tax_rate INTEGER NOT NULL DEFAULT 5,
 turn_number INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS city_elections(
 id TEXT PRIMARY KEY, city_id TEXT NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
 election_type TEXT NOT NULL CHECK(election_type IN ('mayor','council')),
 status TEXT NOT NULL DEFAULT 'open', winner_id TEXT REFERENCES players(id),
 winner_nickname TEXT, created_by TEXT NOT NULL REFERENCES players(id),
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS city_candidates(
 election_id TEXT NOT NULL REFERENCES city_elections(id) ON DELETE CASCADE,
 player_id TEXT NOT NULL REFERENCES players(id), nickname TEXT NOT NULL,
 PRIMARY KEY(election_id,player_id)
);
CREATE TABLE IF NOT EXISTS city_votes(
 election_id TEXT NOT NULL REFERENCES city_elections(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), candidate_id TEXT NOT NULL REFERENCES players(id),
 created_at TEXT NOT NULL, PRIMARY KEY(election_id,voter_id)
);
CREATE TABLE IF NOT EXISTS city_council_seats(
 city_id TEXT NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
 player_id TEXT NOT NULL REFERENCES players(id), nickname TEXT NOT NULL,
 votes INTEGER NOT NULL, seats INTEGER NOT NULL,
 PRIMARY KEY(city_id,player_id)
);
CREATE TABLE IF NOT EXISTS city_proposals(
 id TEXT PRIMARY KEY, city_id TEXT NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
 title TEXT NOT NULL, description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'proposed',
 created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS city_proposal_votes(
 proposal_id TEXT NOT NULL REFERENCES city_proposals(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES players(id), decision TEXT NOT NULL CHECK(decision IN ('yes','no')),
 created_at TEXT NOT NULL, PRIMARY KEY(proposal_id,voter_id)
);
CREATE TABLE IF NOT EXISTS city_projects(
 id TEXT PRIMARY KEY, city_id TEXT NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
 project_type TEXT NOT NULL, level INTEGER NOT NULL DEFAULT 1,
 created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS state_territories(
 state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 territory_key TEXT NOT NULL UNIQUE, added_at TEXT NOT NULL,
 PRIMARY KEY(state_id,territory_key)
);
CREATE TABLE IF NOT EXISTS player_game_stats(
 player_id TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
 xp INTEGER NOT NULL DEFAULT 0, energy INTEGER NOT NULL DEFAULT 500,
 avatar TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS player_region_wallets(
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL,
 gold INTEGER NOT NULL DEFAULT 0, last_refill_at INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(player_id,region_key)
);
CREATE TABLE IF NOT EXISTS game_articles(
 id TEXT PRIMARY KEY, author_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 title TEXT NOT NULL, body TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'general',
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_articles_updated ON game_articles(updated_at DESC);

CREATE TABLE IF NOT EXISTS guest_articles(
 id TEXT PRIMARY KEY, author_name TEXT NOT NULL DEFAULT 'Гість',
 title TEXT NOT NULL, body TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'general',
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_guest_articles_created ON guest_articles(created_at DESC);
CREATE TABLE IF NOT EXISTS world_chat_messages(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 player_id TEXT REFERENCES players(id) ON DELETE SET NULL,
 author_name TEXT NOT NULL,
 body TEXT NOT NULL, image_data TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_world_chat_created ON world_chat_messages(created_at DESC);
CREATE TABLE IF NOT EXISTS regional_party_members(
 party_id TEXT NOT NULL REFERENCES regional_parties(id) ON DELETE CASCADE,
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 role TEXT NOT NULL DEFAULT 'member', joined_at INTEGER NOT NULL,
 PRIMARY KEY(party_id,player_id)
);
CREATE TABLE IF NOT EXISTS guest_article_votes(
 article_id TEXT NOT NULL REFERENCES guest_articles(id) ON DELETE CASCADE, voter_key TEXT NOT NULL,
 value INTEGER NOT NULL CHECK(value IN (-1,1)), created_at TEXT NOT NULL, PRIMARY KEY(article_id,voter_key)
);
CREATE TABLE IF NOT EXISTS guest_article_comments(
 id TEXT PRIMARY KEY, article_id TEXT NOT NULL REFERENCES guest_articles(id) ON DELETE CASCADE,
 author_name TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL
);


CREATE TABLE IF NOT EXISTS regional_game_profiles(
 region_key TEXT PRIMARY KEY, region_name TEXT NOT NULL, country TEXT NOT NULL DEFAULT '',
 budget INTEGER NOT NULL DEFAULT 100000,
 health_index INTEGER NOT NULL DEFAULT 5, defense_index INTEGER NOT NULL DEFAULT 5,
 education_index INTEGER NOT NULL DEFAULT 5, development_index INTEGER NOT NULL DEFAULT 5,
 governor_nickname TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS regional_presidential_decrees(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, governor_id TEXT NOT NULL REFERENCES players(id),
 president_id TEXT NOT NULL REFERENCES players(id), decree_text TEXT NOT NULL,
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_region_decrees ON regional_presidential_decrees(region_key,created_at DESC);
CREATE TABLE IF NOT EXISTS regional_residencies(
 player_id TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL, registered_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_residencies_region ON regional_residencies(region_key);
CREATE TABLE IF NOT EXISTS academy_build_history(
 id INTEGER PRIMARY KEY AUTOINCREMENT, player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL, built_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_academy_history_player ON academy_build_history(player_id,built_at DESC);
CREATE TABLE IF NOT EXISTS player_medals(
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 medal_key TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(player_id,medal_key)
);
CREATE TABLE IF NOT EXISTS regional_academies(
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL,
 last_built_at INTEGER NOT NULL,
 PRIMARY KEY(player_id,region_key)
);
CREATE TABLE IF NOT EXISTS regional_parties(
 id TEXT PRIMARY KEY, player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL,
 name TEXT NOT NULL, ideology TEXT NOT NULL, program TEXT NOT NULL DEFAULT '',
 created_at INTEGER NOT NULL,
 UNIQUE(region_key,name)
);
CREATE INDEX IF NOT EXISTS idx_regional_parties_region ON regional_parties(region_key,created_at);
CREATE TABLE IF NOT EXISTS region_political_elections(
 id TEXT PRIMARY KEY, region_key TEXT NOT NULL, region_name TEXT NOT NULL,
 created_at INTEGER NOT NULL, eligible_at INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'scheduled', result_json TEXT
);
CREATE TABLE IF NOT EXISTS player_region_presence(
 player_id TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, region_name TEXT NOT NULL, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS schema_migrations(
 name TEXT PRIMARY KEY, applied_at TEXT NOT NULL
);
`);

// 6.0.3: separate regional-game election cycles from administrative regional elections.
// Older releases accidentally reused the `regional_elections` table name for two schemas.
// Keep the administrative table and its foreign keys intact; copy legacy game-election
// rows only when that older table actually contains the game-election columns.
const regionElectionColumns = new Set(db.pragma('table_info(regional_elections)').map(column => column.name));
const regionElectionMigration = db.prepare("SELECT name FROM schema_migrations WHERE name='region_political_elections_table_v1'").get();
if (!regionElectionMigration) {
  const migrateRegionElections = db.transaction(() => {
    if (regionElectionColumns.has('region_key') && regionElectionColumns.has('region_name') &&
        regionElectionColumns.has('created_at') && regionElectionColumns.has('eligible_at') &&
        regionElectionColumns.has('status')) {
      const resultColumn = regionElectionColumns.has('result_json') ? 'result_json' : 'NULL';
      db.exec(`INSERT OR IGNORE INTO region_political_elections
        (id,region_key,region_name,created_at,eligible_at,status,result_json)
        SELECT id,region_key,region_name,created_at,eligible_at,status,${resultColumn}
        FROM regional_elections`);
    }
    db.prepare("INSERT INTO schema_migrations(name,applied_at) VALUES('region_political_elections_table_v1',?)")
      .run(new Date().toISOString());
  });
  migrateRegionElections();
}

// 5.0.0 political career: persistent offices, terms and public career history.
db.exec(`
CREATE TABLE IF NOT EXISTS political_offices(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 office_key TEXT NOT NULL CHECK(office_key IN ('president','prime_minister','minister','governor','mayor','deputy')),
 office_title TEXT NOT NULL, territory_key TEXT NOT NULL DEFAULT '',
 appointed_by TEXT REFERENCES players(id) ON DELETE SET NULL,
 source_type TEXT NOT NULL DEFAULT 'appointment' CHECK(source_type IN ('appointment','election')),
 started_at TEXT NOT NULL, ends_at TEXT, ended_at TEXT, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','completed','resigned','dismissed')),
 notes TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_political_offices_player ON political_offices(player_id,status,started_at DESC);
CREATE INDEX IF NOT EXISTS idx_political_offices_state ON political_offices(state_id,status,office_key);
CREATE TABLE IF NOT EXISTS political_reputation(
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 score INTEGER NOT NULL DEFAULT 0 CHECK(score BETWEEN -100 AND 100),
 updated_at TEXT NOT NULL, PRIMARY KEY(player_id,state_id)
);
`);
db.exec(`
CREATE TABLE IF NOT EXISTS player_profile_settings(
 player_id TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
 avatar TEXT NOT NULL DEFAULT '👤', cover_color TEXT NOT NULL DEFAULT '#183153',
 status TEXT NOT NULL DEFAULT '', visibility TEXT NOT NULL DEFAULT 'public' CHECK(visibility IN ('public','friends','private')),
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS player_follows(
 follower_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 followed_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL, PRIMARY KEY(follower_id,followed_id), CHECK(follower_id<>followed_id)
);
CREATE INDEX IF NOT EXISTS idx_player_follows_target ON player_follows(followed_id);
CREATE TABLE IF NOT EXISTS player_blocks(
 blocker_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 blocked_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL, PRIMARY KEY(blocker_id,blocked_id), CHECK(blocker_id<>blocked_id)
);
CREATE TABLE IF NOT EXISTS player_reports(
 id TEXT PRIMARY KEY, reporter_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 reported_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 reason TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS player_activity(
 id TEXT PRIMARY KEY, player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 activity_type TEXT NOT NULL, title TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_player_activity ON player_activity(player_id,created_at DESC);
`);
db.exec(`CREATE TABLE IF NOT EXISTS guest_sessions(guest_key TEXT PRIMARY KEY, player_id TEXT NOT NULL UNIQUE REFERENCES players(id) ON DELETE CASCADE, created_at TEXT NOT NULL, last_seen_at TEXT NOT NULL);`);
// 6.0.0 inventory, swords, marketplace and party invitations.
db.exec(`
CREATE TABLE IF NOT EXISTS player_inventory(
 player_id TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
 battering_rams INTEGER NOT NULL DEFAULT 0 CHECK(battering_rams>=0), updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS player_swords(
 id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 status TEXT NOT NULL DEFAULT 'owned' CHECK(status IN ('owned','listed','sold')),
 region_key TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, sold_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_player_swords_owner ON player_swords(owner_id,status);
CREATE TABLE IF NOT EXISTS sword_auction_listings(
 id TEXT PRIMARY KEY, sword_id TEXT NOT NULL UNIQUE REFERENCES player_swords(id) ON DELETE CASCADE,
 seller_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 price INTEGER NOT NULL CHECK(price BETWEEN 5 AND 20), status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','sold','cancelled')),
 created_at TEXT NOT NULL, sold_at TEXT, buyer_id TEXT REFERENCES players(id), seller_region_key TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS party_invites(
 id TEXT PRIMARY KEY, party_id TEXT NOT NULL REFERENCES regional_parties(id) ON DELETE CASCADE,
 inviter_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 invitee_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','rejected')),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE(party_id,invitee_id), CHECK(inviter_id<>invitee_id)
);
CREATE TABLE IF NOT EXISTS player_ram_strikes(
 id TEXT PRIMARY KEY, player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 region_key TEXT NOT NULL, xp_awarded INTEGER NOT NULL DEFAULT 500, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS game_duels(
 id TEXT PRIMARY KEY, challenger_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 opponent_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','finished','declined')),
 challenger_hp INTEGER NOT NULL DEFAULT 100 CHECK(challenger_hp BETWEEN 0 AND 100),
 opponent_hp INTEGER NOT NULL DEFAULT 100 CHECK(opponent_hp BETWEEN 0 AND 100),
 current_turn_id TEXT REFERENCES players(id), winner_id TEXT REFERENCES players(id),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, CHECK(challenger_id<>opponent_id)
);
CREATE INDEX IF NOT EXISTS idx_game_duels_players ON game_duels(challenger_id,opponent_id,status);
CREATE TABLE IF NOT EXISTS state_government_settings( state_id TEXT PRIMARY KEY REFERENCES game_states(id) ON DELETE CASCADE, government_type TEXT NOT NULL DEFAULT 'democracy' CHECK(government_type IN ('democracy','monarchy')), updated_at TEXT NOT NULL );
CREATE TABLE IF NOT EXISTS state_knights( state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE, player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE, appointed_by TEXT NOT NULL REFERENCES players(id), appointed_at TEXT NOT NULL, PRIMARY KEY(state_id,player_id) );
CREATE TABLE IF NOT EXISTS regional_construction_queue( id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE, territory_key TEXT NOT NULL, building_type TEXT NOT NULL, cost INTEGER NOT NULL, duration_ms INTEGER NOT NULL, started_at INTEGER NOT NULL, completes_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','completed','cancelled')), created_by TEXT NOT NULL REFERENCES players(id), completed_at INTEGER );
CREATE INDEX IF NOT EXISTS idx_construction_due ON regional_construction_queue(status,completes_at);
CREATE TABLE IF NOT EXISTS state_bank_transfers( id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE, player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE, region_key TEXT NOT NULL, treasury_amount INTEGER NOT NULL, gold_amount INTEGER NOT NULL, created_at TEXT NOT NULL );
`);

const swordCols=db.prepare('PRAGMA table_info(player_swords)').all().map(x=>x.name);if(!swordCols.includes('region_key'))db.exec("ALTER TABLE player_swords ADD COLUMN region_key TEXT NOT NULL DEFAULT ''");const auctionCols=db.prepare('PRAGMA table_info(sword_auction_listings)').all().map(x=>x.name);if(!auctionCols.includes('seller_region_key'))db.exec("ALTER TABLE sword_auction_listings ADD COLUMN seller_region_key TEXT NOT NULL DEFAULT ''");
// 3.1.0 persistent online-world systems. CREATE IF NOT EXISTS keeps existing 2.x saves intact.
db.exec(`
CREATE TABLE IF NOT EXISTS player_friends(
 id TEXT PRIMARY KEY, requester_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 addressee_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','rejected')),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE(requester_id,addressee_id), CHECK(requester_id<>addressee_id)
);
CREATE TABLE IF NOT EXISTS player_notifications(
 id TEXT PRIMARY KEY, player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', data_json TEXT NOT NULL DEFAULT '{}',
 is_read INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notifications_player ON player_notifications(player_id,is_read,created_at DESC);
CREATE TABLE IF NOT EXISTS diplomacy_treaties(
 id TEXT PRIMARY KEY, proposer_state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 target_state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 treaty_type TEXT NOT NULL, title TEXT NOT NULL, terms TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','rejected','cancelled')),
 created_by TEXT NOT NULL REFERENCES players(id), responded_by TEXT REFERENCES players(id),
 created_at TEXT NOT NULL, responded_at TEXT NOT NULL DEFAULT '', CHECK(proposer_state_id<>target_state_id)
);
CREATE INDEX IF NOT EXISTS idx_treaties_states ON diplomacy_treaties(proposer_state_id,target_state_id,status);
CREATE TABLE IF NOT EXISTS regional_demographics(
 state_id TEXT NOT NULL, territory_key TEXT NOT NULL,
 population INTEGER NOT NULL DEFAULT 10000 CHECK(population>=0),
 growth_permille INTEGER NOT NULL DEFAULT 2 CHECK(growth_permille BETWEEN -20 AND 20),
 health_index INTEGER NOT NULL DEFAULT 50 CHECK(health_index BETWEEN 0 AND 100),
 education_index INTEGER NOT NULL DEFAULT 50 CHECK(education_index BETWEEN 0 AND 100),
 employment_index INTEGER NOT NULL DEFAULT 90 CHECK(employment_index BETWEEN 0 AND 100),
 wellbeing_index INTEGER NOT NULL DEFAULT 50 CHECK(wellbeing_index BETWEEN 0 AND 100),
 last_simulated_at INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL,
 PRIMARY KEY(state_id,territory_key),
 FOREIGN KEY(state_id,territory_key) REFERENCES state_territories(state_id,territory_key) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_regional_demographics_population ON regional_demographics(population DESC);
CREATE TABLE IF NOT EXISTS state_treasuries(
 state_id TEXT PRIMARY KEY REFERENCES game_states(id) ON DELETE CASCADE,
 balance INTEGER NOT NULL DEFAULT 100000 CHECK(balance>=0), tax_rate INTEGER NOT NULL DEFAULT 5 CHECK(tax_rate BETWEEN 0 AND 25),
 last_income_at INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS state_ledger(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 player_id TEXT REFERENCES players(id) ON DELETE SET NULL, entry_type TEXT NOT NULL,
 amount INTEGER NOT NULL, description TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_state_ledger ON state_ledger(state_id,created_at DESC);
CREATE TABLE IF NOT EXISTS state_trade_offers(
 id TEXT PRIMARY KEY, from_state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 to_state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 amount INTEGER NOT NULL CHECK(amount>0), note TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','rejected','cancelled')),
 created_by TEXT NOT NULL REFERENCES players(id), responded_by TEXT REFERENCES players(id),
 created_at TEXT NOT NULL, responded_at TEXT NOT NULL DEFAULT '', CHECK(from_state_id<>to_state_id)
);
CREATE TABLE IF NOT EXISTS world_events(
 id TEXT PRIMARY KEY, actor_id TEXT REFERENCES players(id) ON DELETE SET NULL,
 scope TEXT NOT NULL DEFAULT 'world', title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_world_events ON world_events(created_at DESC);
CREATE TABLE IF NOT EXISTS player_achievements(
 player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 achievement_key TEXT NOT NULL, unlocked_at TEXT NOT NULL,
 PRIMARY KEY(player_id,achievement_key)
);
CREATE TABLE IF NOT EXISTS state_economy_projects(
 id TEXT PRIMARY KEY, state_id TEXT NOT NULL REFERENCES game_states(id) ON DELETE CASCADE,
 project_type TEXT NOT NULL, cost INTEGER NOT NULL, created_by TEXT NOT NULL REFERENCES players(id), created_at TEXT NOT NULL
);
`);

// Add per-article edit keys without breaking existing SQLite installations.
const guestArticleColumns=db.prepare('PRAGMA table_info(guest_articles)').all().map(x=>x.name);
const guestCommentColumns=db.prepare('PRAGMA table_info(guest_article_comments)').all().map(x=>x.name);
if(!guestArticleColumns.includes('player_id'))db.exec('ALTER TABLE guest_articles ADD COLUMN player_id TEXT REFERENCES players(id) ON DELETE SET NULL');
if(!guestCommentColumns.includes('player_id'))db.exec('ALTER TABLE guest_article_comments ADD COLUMN player_id TEXT REFERENCES players(id) ON DELETE SET NULL');
const chatColumns=db.prepare('PRAGMA table_info(world_chat_messages)').all().map(x=>x.name);
if(!chatColumns.includes('image_data'))db.exec("ALTER TABLE world_chat_messages ADD COLUMN image_data TEXT NOT NULL DEFAULT ''");
if(!chatColumns.includes('media_type'))db.exec("ALTER TABLE world_chat_messages ADD COLUMN media_type TEXT NOT NULL DEFAULT ''");
if(!guestArticleColumns.includes('edit_key'))db.exec("ALTER TABLE guest_articles ADD COLUMN edit_key TEXT NOT NULL DEFAULT ''");
const regionalPartyColumns=db.prepare('PRAGMA table_info(regional_parties)').all().map(x=>x.name);
if(!regionalPartyColumns.includes('emblem_data'))db.exec("ALTER TABLE regional_parties ADD COLUMN emblem_data TEXT NOT NULL DEFAULT ''");
const regionalEconomyColumns=db.prepare('PRAGMA table_info(regional_economies)').all().map(x=>x.name);
if(!regionalEconomyColumns.includes('last_income_at'))db.exec('ALTER TABLE regional_economies ADD COLUMN last_income_at INTEGER NOT NULL DEFAULT 0');
const cityEconomyColumns=db.prepare('PRAGMA table_info(city_economies)').all().map(x=>x.name);
if(!cityEconomyColumns.includes('last_income_at'))db.exec('ALTER TABLE city_economies ADD COLUMN last_income_at INTEGER NOT NULL DEFAULT 0');
db.prepare("INSERT OR IGNORE INTO regional_party_members(party_id,player_id,role,joined_at) SELECT id,player_id,'leader',created_at FROM regional_parties").run();
// Per-player browser game snapshots. Data is isolated by authenticated player ID.
db.exec(`CREATE TABLE IF NOT EXISTS player_game_saves(
 player_id TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
 payload TEXT NOT NULL,
 updated_at TEXT NOT NULL
);`);

function articleEditHash(key){return createHmac('sha256',JWT_SECRET).update('article-edit:'+key).digest('hex');}

const registerAttempts = new Map();
function rateLimit(key, max=8, windowMs=60000){
 const now=Date.now(), recent=(registerAttempts.get(key)||[]).filter(t=>now-t<windowMs);
 if(recent.length>=max) return false;
 recent.push(now); registerAttempts.set(key,recent); return true;
}
function fail(res,status,message){return res.status(status).json({error:message});}
function validNick(n){return typeof n==='string' && /^[\p{L}\p{N}_ -]{3,24}$/u.test(n.trim());}
function signToken(playerId){
 const header=Buffer.from(JSON.stringify({alg:'HS256',typ:'JWT'})).toString('base64url');
 const payload=Buffer.from(JSON.stringify({iss:'chemisworld-clerk',sub:playerId,iat:Math.floor(Date.now()/1000),exp:Math.floor(Date.now()/1000)+60*60*24*30})).toString('base64url');
 const input=header+'.'+payload;
 return input+'.'+createHmac('sha256',JWT_SECRET).update(input).digest('base64url');
}
// Google-only authentication. Legacy guest/password endpoints are intentionally disabled.
for (const route of ['/api/auth/guest','/api/auth/register','/api/auth/login','/api/auth/upgrade']) {
 app.post(route,(req,res)=>fail(res,410,'Реєстрація доступна лише через Google.'));
}

function playerFromToken(token){
 const parts=String(token||'').split('.');
 if(parts.length!==3)return null;
 const input=parts[0]+'.'+parts[1];
 const expected=createHmac('sha256',JWT_SECRET).update(input).digest();
 let actual;try{actual=Buffer.from(parts[2],'base64url');}catch{return null;}
 if(actual.length!==expected.length||!timingSafeEqual(actual,expected))return null;
 let payload;try{payload=JSON.parse(Buffer.from(parts[1],'base64url').toString());}catch{return null;}
 if(payload.iss!=='chemisworld-clerk'||!payload.sub||!payload.exp||payload.exp<Date.now()/1000)return null;
 return db.prepare('SELECT id,nickname,bio,home_region,created_at FROM players WHERE id=?').get(payload.sub)||null;
}
function auth(req,res,next){
 const player=playerFromToken((req.headers.authorization||'').replace(/^Bearer\s+/i,''));
 if(!player)return fail(res,401,'Потрібен вхід через Google.');
 req.player=player;next();
}
function optionalAuth(req,res,next){
 const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
 req.player=token?playerFromToken(token):null;next();
}
// Save/load local-prototype systems against the signed-in account.
app.get('/api/game/save',auth,(req,res)=>{
 const row=db.prepare('SELECT payload,updated_at FROM player_game_saves WHERE player_id=?').get(req.player.id);
 if(!row)return res.json({save:null,updatedAt:null});
 try{return res.json({save:JSON.parse(row.payload),updatedAt:row.updated_at});}
 catch(error){console.error('Corrupt game save for player:',req.player.id,error.message);return fail(res,500,'Не вдалося прочитати збереження гри.');}
});
app.put('/api/game/save',auth,(req,res)=>{
 const payload=req.body?.save;
 if(!payload||typeof payload!=='object'||Array.isArray(payload))return fail(res,400,'Некоректні дані збереження.');
 const clean={version:2};
 // Keep the complete client game snapshot, including future local game systems.
 // Authentication/session secrets are filtered on the client and never belong here.
 for(const [key,value] of Object.entries(payload)){if(key==='version')continue;if(!/^[a-zA-Z0-9_-]{1,100}$/.test(key))continue;clean[key]=value;}
 const encoded=JSON.stringify(clean);
 if(Buffer.byteLength(encoded,'utf8')>5*1024*1024)return fail(res,413,'Збереження завелике.');
 const now=new Date().toISOString();
 db.prepare(`INSERT INTO player_game_saves(player_id,payload,updated_at) VALUES(?,?,?)
 ON CONFLICT(player_id) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at`).run(req.player.id,encoded,now);
 res.json({ok:true,updatedAt:now});
});
function googleSafeNickname(name,email){
 let base=String(name||email.split('@')[0]||'Гравець').normalize('NFKC').replace(/[^\p{L}\p{N}_ -]/gu,'').trim().replace(/\s+/g,' ').slice(0,20);
 if(base.length<3)base='Гравець';
 let candidate=base;
 while(db.prepare('SELECT 1 FROM players WHERE nickname=? COLLATE NOCASE').get(candidate)){
  const suffix='_'+randomBytes(2).toString('hex').toUpperCase();candidate=(base.slice(0,24-suffix.length)+suffix);
 }
 return candidate;
}
app.get('/api/auth/config',(req,res)=>res.json({clerkPublishableKey:CLERK_PUBLISHABLE_KEY||null}));
app.post('/api/auth/clerk',async(req,res)=>{
 if(!CLERK_PUBLISHABLE_KEY||!CLERK_SECRET_KEY||!CLERK_ISSUER||!clerkJwks)return fail(res,503,'Clerk ще не налаштований адміністратором сайту.');
 const sessionToken=String(req.body?.sessionToken||'');
 if(!sessionToken||sessionToken.length>16000)return fail(res,400,'Не отримано токен сесії Clerk.');
 if(!rateLimit('clerk:'+req.ip,20,60000))return fail(res,429,'Забагато спроб входу. Спробуй пізніше.');
 let claims;
 try{const verified=await jwtVerify(sessionToken,clerkJwks,{algorithms:['RS256'],issuer:CLERK_ISSUER});claims=verified.payload;}
 catch(e){console.warn('Clerk session verification failed:',e.code||e.message);return fail(res,401,'Clerk не підтвердив цю сесію. Увійди через Google ще раз.');}
 if(claims.azp&&!clerkAuthorizedParties.has(String(claims.azp)))return fail(res,403,'Цей домен не дозволений для входу в ChemisWorld.');
 const clerkUserId=String(claims.sub||'');
 if(!clerkUserId.startsWith('user_'))return fail(res,401,'Некоректний ідентифікатор користувача Clerk.');
 let clerkUser;
 try{const response=await fetch(`https://api.clerk.com/v1/users/${encodeURIComponent(clerkUserId)}`,{headers:{Authorization:`Bearer ${CLERK_SECRET_KEY}`,Accept:'application/json'}});if(!response.ok)throw new Error(`Clerk API HTTP ${response.status}`);clerkUser=await response.json();}
 catch(e){console.error('Clerk user lookup failed:',e.message);return fail(res,502,'Не вдалося отримати профіль із Clerk. Спробуй ще раз.');}
 const googleConnected=(clerkUser.external_accounts||[]).some(x=>String(x.provider||'').toLowerCase().includes('google'));
 if(!googleConnected)return fail(res,403,'Для ChemisWorld дозволений лише вхід через Google.');
 const primaryEmail=(clerkUser.email_addresses||[]).find(x=>x.id===clerkUser.primary_email_address_id);
 const email=String(primaryEmail?.email_address||'').trim().toLowerCase();
 if(!email||primaryEmail?.verification?.status!=='verified')return fail(res,403,'Потрібна підтверджена адреса Google.');
 const displayName=[clerkUser.first_name,clerkUser.last_name].filter(Boolean).join(' ').trim()||email.split('@')[0]||'Гравець';
 const now=new Date().toISOString();let identity=db.prepare('SELECT player_id FROM clerk_identities WHERE clerk_user_id=?').get(clerkUserId);let playerId=identity?.player_id;let created=false;
 if(!playerId){
  const previous=db.prepare('SELECT player_id FROM google_identities WHERE lower(email)=? ORDER BY created_at LIMIT 1').get(email);
  if(previous){playerId=previous.player_id;db.prepare('INSERT INTO clerk_identities(clerk_user_id,player_id,email,created_at) VALUES(?,?,?,?)').run(clerkUserId,playerId,email,now);}
  else{
   playerId=randomBytes(16).toString('hex');const nickname=googleSafeNickname(displayName,email);const fakeHash='clerk$'+randomBytes(32).toString('hex');
   const tx=db.transaction(()=>{db.prepare('INSERT INTO players(id,nickname,password_hash,bio,home_region,created_at) VALUES(?,?,?,?,?,?)').run(playerId,nickname,fakeHash,'','',now);db.prepare('INSERT INTO clerk_identities(clerk_user_id,player_id,email,created_at) VALUES(?,?,?,?)').run(clerkUserId,playerId,email,now);db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) VALUES(?,?)').run(playerId,now);});
   try{tx();created=true;}catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Цей акаунт уже прив’язаний до ігрового профілю. Увійди через той самий Google-акаунт.');throw e;}
  }
 }else db.prepare('UPDATE clerk_identities SET email=? WHERE clerk_user_id=?').run(email,clerkUserId);
 db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) VALUES(?,?)').run(playerId,now);
 const player=db.prepare('SELECT id,nickname,bio,home_region,created_at FROM players WHERE id=?').get(playerId);
 res.json({ok:true,token:signToken(playerId),player,created,clerkLinked:true});
});

// Player progression, regional gold mines and community articles.
// One-time starting reserve migration for existing players.
const startingGoldMigration=db.prepare("SELECT name FROM schema_migrations WHERE name='regional_starting_gold_500'").get();
if(!startingGoldMigration){
 const migrationTx=db.transaction(()=>{
  db.prepare('UPDATE player_region_wallets SET gold=500 WHERE gold<500').run();
  db.prepare("INSERT INTO schema_migrations(name,applied_at) VALUES('regional_starting_gold_500',?)").run(new Date().toISOString());
 });
 migrationTx();
}
function ensurePlayerGame(playerId){
 db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) VALUES(?,?)').run(playerId,new Date().toISOString());
 return db.prepare('SELECT * FROM player_game_stats WHERE player_id=?').get(playerId);
}
function ensureRegionWallet(playerId,regionKey,regionName){
 const now=Date.now();
 db.prepare('INSERT OR IGNORE INTO player_region_wallets(player_id,region_key,region_name,gold,last_refill_at) VALUES(?,?,?,500,?)').run(playerId,regionKey,regionName,now);
 let wallet=db.prepare('SELECT * FROM player_region_wallets WHERE player_id=? AND region_key=?').get(playerId,regionKey);
 const intervals=Math.floor((now-wallet.last_refill_at)/(12*60*60*1000));
 if(intervals>0){
  const refill=Math.min(intervals*100,5000);
  db.prepare('UPDATE player_region_wallets SET gold=gold+?,last_refill_at=? WHERE player_id=? AND region_key=?').run(refill,wallet.last_refill_at+intervals*12*60*60*1000,playerId,regionKey);
  wallet=db.prepare('SELECT * FROM player_region_wallets WHERE player_id=? AND region_key=?').get(playerId,regionKey);
 }
 return wallet;
}
// Automatic 12-hour gold income for every region wallet. If the free host sleeps,
// elapsed periods are credited on the next region request by ensureRegionWallet().
function refillAllRegionalWallets(){
 const now=Date.now();
 const due=db.prepare('SELECT player_id,region_key,last_refill_at FROM player_region_wallets WHERE last_refill_at <= ?').all(now-12*60*60*1000);
 if(!due.length)return;
 const update=db.prepare('UPDATE player_region_wallets SET gold=gold+?,last_refill_at=? WHERE player_id=? AND region_key=?');
 const tx=db.transaction(rows=>{for(const row of rows){const intervals=Math.floor((now-row.last_refill_at)/(12*60*60*1000));if(intervals>0){const credited=Math.min(intervals*100,5000);update.run(credited,row.last_refill_at+intervals*12*60*60*1000,row.player_id,row.region_key);}}});
 tx(due);
}
setInterval(refillAllRegionalWallets,60*1000).unref?.();
function gameProfile(playerId){
 const stats=ensurePlayerGame(playerId);
 const settings=db.prepare('SELECT avatar FROM player_profile_settings WHERE player_id=?').get(playerId);return {xp:stats.xp,level:Number((stats.xp/1000).toFixed(1)),energy:stats.energy,avatar:settings?.avatar||stats.avatar||'👤'};
}
app.get('/api/public/stats',(req,res)=>{
 const players=db.prepare('SELECT COUNT(*) AS n FROM players').get().n;
 const regions=db.prepare('SELECT COUNT(*) n FROM (SELECT region_key FROM regional_game_profiles UNION SELECT territory_key AS region_key FROM state_territories UNION SELECT region_key FROM player_region_wallets)').get().n;
 const memberArticles=db.prepare('SELECT COUNT(*) AS n FROM game_articles').get().n;
 const guestArticles=db.prepare('SELECT COUNT(*) AS n FROM guest_articles').get().n;
 res.json({players,regions,articles:memberArticles+guestArticles});
});
app.get('/api/game/profile',auth,(req,res)=>{
 const profile=gameProfile(req.player.id);
 const rank=db.prepare('SELECT COUNT(*)+1 AS rank FROM player_game_stats WHERE xp>(SELECT xp FROM player_game_stats WHERE player_id=?)').get(req.player.id)?.rank||1;
 const total=db.prepare('SELECT COUNT(*) AS n FROM players').get().n;
 res.json({profile,rank,totalPlayers:total});
});
app.get('/api/game/region/:key',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.query.name||key).slice(0,100);
 if(!key||!/[A-Za-z0-9:_-]/.test(key))return fail(res,400,'Некоректний регіон.');
 const wallet=ensureRegionWallet(req.player.id,key,name),profile=gameProfile(req.player.id);
 res.json({region:{key,name:wallet.region_name,gold:wallet.gold,nextRefillAt:wallet.last_refill_at+12*60*60*1000},profile});
});
app.post('/api/game/region/:key/mine',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.body?.name||key).slice(0,100),energy=Number(req.body?.energy);
 if(![10,50,100,200,300,400,500].includes(energy))return fail(res,400,'Обери доступний обсяг енергії.');
 const wallet=ensureRegionWallet(req.player.id,key,name),stats=ensurePlayerGame(req.player.id);
 if(stats.energy<energy)return fail(res,409,'Недостатньо енергії. Придбай енергетики за золото.');
 const now=new Date().toISOString();
 const tx=db.transaction(()=>{
  db.prepare('UPDATE player_game_stats SET energy=energy-?,xp=xp+? WHERE player_id=?').run(energy,energy*5,req.player.id);
  db.prepare('UPDATE player_region_wallets SET gold=gold+? WHERE player_id=? AND region_key=?').run(energy,req.player.id,key);
 });
 tx();
 const updated=ensureRegionWallet(req.player.id,key,name);
 res.json({ok:true,earnedGold:energy,earnedXp:energy*5,wallet:updated,profile:gameProfile(req.player.id)});
});
app.post('/api/game/energy/buy',auth,(req,res)=>{
 const amount=Number(req.body?.amount);
 if(!Number.isInteger(amount)||amount<1||amount>500)return fail(res,400,'Кількість енергії має бути від 1 до 500.');
 const key=String(req.body?.regionKey||'').slice(0,120),name=String(req.body?.regionName||key).slice(0,100);
 if(!key)return fail(res,400,'Спочатку обери регіон.');
 const wallet=ensureRegionWallet(req.player.id,key,name),stats=ensurePlayerGame(req.player.id);
 const actual=Math.min(amount,500-stats.energy);
 if(actual<1)return fail(res,409,'Енергія вже заповнена до максимуму 500.');
 if(wallet.gold<actual)return fail(res,409,'Недостатньо золота.');
 const tx=db.transaction(()=>{
  const debit=db.prepare('UPDATE player_region_wallets SET gold=gold-? WHERE player_id=? AND region_key=? AND gold>=?').run(actual,req.player.id,key,actual);
  if(debit.changes!==1)throw new Error('ENERGY_NO_GOLD');
  const credit=db.prepare('UPDATE player_game_stats SET energy=energy+? WHERE player_id=? AND energy+?<=500').run(actual,req.player.id,actual);
  if(credit.changes!==1)throw new Error('ENERGY_FULL');
 });
 try{tx();}catch(e){if(e.message==='ENERGY_NO_GOLD')return fail(res,409,'Недостатньо золота.');if(e.message==='ENERGY_FULL')return fail(res,409,'Енергія вже заповнена. Онови інвентар.');throw e;}
 res.json({ok:true,bought:actual,wallet:ensureRegionWallet(req.player.id,key,name),profile:gameProfile(req.player.id)});
});
app.post('/api/game/avatar/buy',auth,(req,res)=>{
 const avatar=String(req.body?.avatar||'').slice(0,8),key=String(req.body?.regionKey||'').slice(0,120),name=String(req.body?.regionName||key).slice(0,100);
 if(!avatar||!key)return fail(res,400,'Обери аватар і регіон.');
 const wallet=ensureRegionWallet(req.player.id,key,name);
 if(wallet.gold<50)return fail(res,409,'Для створення аватара потрібно 50 золота.');
 const tx=db.transaction(()=>{
  db.prepare('UPDATE player_region_wallets SET gold=gold-50 WHERE player_id=? AND region_key=?').run(req.player.id,key);
  db.prepare('UPDATE player_game_stats SET avatar=? WHERE player_id=?').run(avatar,req.player.id);
 });
 tx();res.json({ok:true,wallet:ensureRegionWallet(req.player.id,key,name),profile:gameProfile(req.player.id)});
});
app.get('/api/game/leaderboard',auth,(req,res)=>{
 db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) SELECT id,created_at FROM players').run();
 const rows=db.prepare(`SELECT p.id,p.nickname,p.home_region,s.xp,ROUND(s.xp/1000,1) AS level,(SELECT COUNT(*) FROM player_swords sw WHERE sw.owner_id=p.id AND sw.status IN ('owned','listed')) AS swords FROM players p JOIN player_game_stats s ON s.player_id=p.id ORDER BY s.xp DESC,p.created_at ASC LIMIT 100`).all();
 res.json({players:rows.map((p,i)=>({...p,rank:i+1})),totalPlayers:db.prepare('SELECT COUNT(*) n FROM players').get().n});
});

// Regional game mechanics: academies, parties, travel and scheduled elections.
app.get('/api/game/region/:key/politics',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120);
 const parties=db.prepare(`SELECT p.id,p.name,p.ideology,p.program,p.created_at,
 (SELECT COUNT(*) FROM regional_party_members m WHERE m.party_id=p.id) AS members,
 (SELECT nickname FROM players u WHERE u.id=p.player_id) AS leader,
 EXISTS(SELECT 1 FROM regional_party_members m WHERE m.party_id=p.id AND m.player_id=?) AS isMember
 FROM regional_parties p WHERE p.region_key=? ORDER BY p.created_at`).all(req.player.id,key);
 const election=db.prepare("SELECT id,created_at,eligible_at,status,result_json FROM region_political_elections WHERE region_key=? ORDER BY created_at DESC LIMIT 1").get(key)||null;
 const presence=db.prepare('SELECT region_key,region_name FROM player_region_presence WHERE player_id=?').get(req.player.id)||null;
 res.json({parties,election,presence});
});
app.get('/api/game/party/:id',auth,(req,res)=>{
 const p=db.prepare(`SELECT p.id,p.name,p.ideology,p.program,p.region_name,p.created_at,p.emblem_data,u.nickname AS leader,
 (SELECT COUNT(*) FROM regional_party_members m WHERE m.party_id=p.id) AS members,
 (SELECT COUNT(*) FROM regional_party_members m WHERE m.party_id=p.id AND m.role<>'member') AS leadership,
 EXISTS(SELECT 1 FROM regional_party_members m WHERE m.party_id=p.id AND m.player_id=?) AS isMember,
 (p.player_id=?) AS isLeader,
 (SELECT role FROM regional_party_members m WHERE m.party_id=p.id AND m.player_id=?) AS myRole
 FROM regional_parties p JOIN players u ON u.id=p.player_id WHERE p.id=?`).get(req.player.id,req.player.id,req.player.id,req.params.id);
 if(!p)return fail(res,404,'Партію не знайдено.');res.json({party:p,activeSalary:0,leadershipSalary:0});
});
app.get('/api/game/party/:id/members',auth,(req,res)=>{
 const exists=db.prepare('SELECT id FROM regional_parties WHERE id=?').get(req.params.id);if(!exists)return fail(res,404,'Партію не знайдено.');
 const members=db.prepare(`SELECT u.id,u.nickname,m.role,m.joined_at FROM regional_party_members m JOIN players u ON u.id=m.player_id WHERE m.party_id=? ORDER BY CASE m.role WHEN 'leader' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END,m.joined_at`).all(req.params.id);
 res.json({members});
});
app.post('/api/game/party/:id/emblem',auth,(req,res)=>{
 const p=db.prepare('SELECT player_id FROM regional_parties WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Партію не знайдено.');
 const member=db.prepare('SELECT role FROM regional_party_members WHERE party_id=? AND player_id=?').get(req.params.id,req.player.id);
 if(p.player_id!==req.player.id&&(!member||!['leader','admin'].includes(member.role)))return fail(res,403,'Змінювати емблему можуть лише керівники партії.');
 const data=String(req.body?.emblem||'');if(!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(data)||data.length>1800000)return fail(res,400,'Завантаж PNG, JPG або WebP до 1,2 МБ.');
 db.prepare('UPDATE regional_parties SET emblem_data=? WHERE id=?').run(data,req.params.id);res.json({ok:true});
});
app.post('/api/game/party/:id/disband',auth,(req,res)=>{
 const p=db.prepare('SELECT player_id FROM regional_parties WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Партію не знайдено.');
 if(p.player_id!==req.player.id)return fail(res,403,'Розпустити партію може лише її засновник-лідер.');
 const count=db.prepare('SELECT COUNT(*) n FROM regional_party_members WHERE party_id=?').get(req.params.id).n;
 if(count>1)return fail(res,409,'У партії є інші учасники. Спочатку вийди з партії — керівництво буде передано іншому учаснику.');
 const tx=db.transaction(()=>{db.prepare('DELETE FROM party_invites WHERE party_id=?').run(req.params.id);db.prepare('DELETE FROM regional_parties WHERE id=?').run(req.params.id);});tx();res.json({ok:true});
});
app.post('/api/game/party/:id/join',auth,(req,res)=>{
 const p=db.prepare('SELECT id FROM regional_parties WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Партію не знайдено.');
 db.prepare("INSERT OR IGNORE INTO regional_party_members(party_id,player_id,role,joined_at) VALUES(?,?,'member',?)").run(p.id,req.player.id,Date.now());res.json({ok:true});
});
app.patch('/api/game/party/:id',auth,(req,res)=>{
 const p=db.prepare('SELECT player_id FROM regional_parties WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Партію не знайдено.');
 if(p.player_id!==req.player.id)return fail(res,403,'Змінювати назву, ідеологію та опис може лише лідер партії.');
 const name=String(req.body?.name||'').trim(),ideology=String(req.body?.ideology||'').trim(),program=String(req.body?.program||'').trim();
 if(name.length<3||name.length>50)return fail(res,400,'Назва має містити від 3 до 50 символів.');
 if(ideology.length>60)return fail(res,400,'Ідеологія має бути не довшою за 60 символів.');
 if(program.length>1000)return fail(res,400,'Опис має бути не довшим за 1000 символів.');
 try{db.prepare('UPDATE regional_parties SET name=?,ideology=?,program=? WHERE id=?').run(name,ideology,program,req.params.id);}catch(e){if(String(e.message).includes('UNIQUE'))return fail(res,409,'У цьому регіоні вже існує партія з такою назвою.');throw e;}
 res.json({ok:true});
});
app.post('/api/game/party/:id/leave',auth,(req,res)=>{
 const p=db.prepare('SELECT player_id FROM regional_parties WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Партію не знайдено.');
 const member=db.prepare('SELECT role FROM regional_party_members WHERE party_id=? AND player_id=?').get(req.params.id,req.player.id);if(!member)return fail(res,409,'Ти не перебуваєш у цій партії.');
 const count=db.prepare('SELECT COUNT(*) n FROM regional_party_members WHERE party_id=?').get(req.params.id).n;
 if(count<=1)return fail(res,409,'Останній учасник має розпустити партію.');
 const tx=db.transaction(()=>{
  if(p.player_id===req.player.id){
   const successor=db.prepare("SELECT player_id FROM regional_party_members WHERE party_id=? AND player_id<>? ORDER BY CASE role WHEN 'admin' THEN 0 ELSE 1 END,joined_at ASC LIMIT 1").get(req.params.id,req.player.id);
   if(!successor)throw new Error('NO_SUCCESSOR');
   db.prepare('UPDATE regional_parties SET player_id=? WHERE id=?').run(successor.player_id,req.params.id);
   db.prepare("UPDATE regional_party_members SET role=CASE WHEN player_id=? THEN 'leader' WHEN role='leader' THEN 'member' ELSE role END WHERE party_id=?").run(successor.player_id,req.params.id);
  }
  db.prepare('DELETE FROM regional_party_members WHERE party_id=? AND player_id=?').run(req.params.id,req.player.id);
 });
 try{tx();}catch(e){if(e.message==='NO_SUCCESSOR')return fail(res,409,'Немає учасника, якому можна передати керівництво.');throw e;}
 res.json({ok:true});
});

app.post('/api/game/region/:key/academy',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.body?.name||key).slice(0,100),now=Date.now();
 if(!key)return fail(res,400,'Спочатку обери регіон.');
 const previous=db.prepare('SELECT last_built_at FROM regional_academies WHERE player_id=? AND region_key=?').get(req.player.id,key);
 if(previous&&now-previous.last_built_at<6*60*60*1000){
  const next=previous.last_built_at+6*60*60*1000;
  return fail(res,409,'Наступну академію можна побудувати через '+Math.ceil((next-now)/60000)+' хв.');
 }
 const tx=db.transaction(()=>{
  db.prepare('INSERT INTO regional_academies(player_id,region_key,region_name,last_built_at) VALUES(?,?,?,?) ON CONFLICT(player_id,region_key) DO UPDATE SET region_name=excluded.region_name,last_built_at=excluded.last_built_at').run(req.player.id,key,name,now);
  ensureRegionWallet(req.player.id,key,name);
  db.prepare('UPDATE player_region_wallets SET gold=gold+100 WHERE player_id=? AND region_key=?').run(req.player.id,key);
  db.prepare('INSERT INTO academy_build_history(player_id,region_key,region_name,built_at) VALUES(?,?,?,?)').run(req.player.id,key,name,now);
  db.prepare(`INSERT INTO player_medals(player_id,medal_key,quantity) VALUES(?,'academy_builder',1)
    ON CONFLICT(player_id,medal_key) DO UPDATE SET quantity=quantity+1`).run(req.player.id);
  db.prepare(`INSERT INTO regional_game_profiles(region_key,region_name,updated_at,defense_index)
    VALUES(?,?,?,MIN(10,6))
    ON CONFLICT(region_key) DO UPDATE SET defense_index=MIN(10,regional_game_profiles.defense_index+1),updated_at=excluded.updated_at`).run(key,name,new Date().toISOString());
 });
 tx();
 res.json({ok:true,rewardGold:100,medal:{key:'academy_builder',quantity:db.prepare("SELECT quantity FROM player_medals WHERE player_id=? AND medal_key='academy_builder'").get(req.player.id).quantity},nextAvailableAt:now+6*60*60*1000,wallet:ensureRegionWallet(req.player.id,key,name)});
});
app.get('/api/game/region/:key/profile',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.query.name||key).slice(0,100),country=String(req.query.country||'').slice(0,80);
 if(!key)return fail(res,400,'Не вказано регіон.');
 db.prepare(`INSERT OR IGNORE INTO regional_game_profiles(region_key,region_name,country,updated_at)
 VALUES(?,?,?,?)`).run(key,name,country,new Date().toISOString());
 const profile=db.prepare('SELECT * FROM regional_game_profiles WHERE region_key=?').get(key);
 const residents=db.prepare('SELECT COUNT(*) n FROM regional_residencies WHERE region_key=?').get(key).n;
 const parties=db.prepare('SELECT COUNT(*) n FROM regional_parties WHERE region_key=?').get(key).n;
 const academies=db.prepare('SELECT COUNT(*) n FROM academy_build_history WHERE region_key=?').get(key).n;
 const governor=profile.governor_nickname||'Не призначений';
 const presidentStates=db.prepare(`SELECT s.id,s.name FROM game_states s JOIN state_territories t ON t.state_id=s.id
  WHERE s.owner_id=? AND t.territory_key=? ORDER BY s.created_at`).all(req.player.id,key);
 const latestDecree=db.prepare(`SELECT d.id,d.decree_text,d.created_at,p.nickname AS governor,s.name AS state_name
  FROM regional_presidential_decrees d JOIN players p ON p.id=d.governor_id JOIN game_states s ON s.id=d.state_id
  WHERE d.region_key=? ORDER BY d.created_at DESC LIMIT 1`).get(key)||null;
 res.json({profile,residents,parties,academies,governor,presidentStates,latestDecree});
});
app.post('/api/game/region/:key/decree',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120);
 const stateId=String(req.body?.stateId||'').slice(0,80);
 const nickname=String(req.body?.nickname||'').trim().slice(0,24);
 const decreeText=String(req.body?.decreeText||'Указ Президента про призначення губернатора').trim().slice(0,240);
 if(!key||!stateId||nickname.length<3)return fail(res,400,'Вкажи державу та нікнейм кандидата.');
 const state=db.prepare('SELECT id,name,owner_id FROM game_states WHERE id=?').get(stateId);
 if(!state)return fail(res,404,'Державу не знайдено.');
 if(state.owner_id!==req.player.id)return fail(res,403,'Указ може видати лише Президент — власник цієї держави.');
 const territory=db.prepare('SELECT territory_key FROM state_territories WHERE state_id=? AND territory_key=?').get(stateId,key);
 if(!territory)return fail(res,403,'Цей регіон не входить до складу держави, від імені якої видається указ.');
 const governor=db.prepare('SELECT id,nickname FROM players WHERE nickname=? COLLATE NOCASE').get(nickname);
 if(!governor)return fail(res,404,'Гравця з таким нікнеймом не знайдено.');
 const now=new Date().toISOString(),id=randomBytes(12).toString('hex');
 const tx=db.transaction(()=>{
  db.prepare(`INSERT INTO regional_administrations(state_id,territory_key,governor_id,appointed_by,updated_at)
   VALUES(?,?,?,?,?) ON CONFLICT(state_id,territory_key) DO UPDATE SET governor_id=excluded.governor_id,appointed_by=excluded.appointed_by,updated_at=excluded.updated_at`)
   .run(stateId,key,governor.id,req.player.id,now);
  db.prepare(`UPDATE regional_game_profiles SET governor_nickname=?,updated_at=? WHERE region_key=?`).run(governor.nickname,now,key);
  db.prepare(`INSERT INTO regional_presidential_decrees(id,state_id,region_key,governor_id,president_id,decree_text,created_at)
   VALUES(?,?,?,?,?,?,?)`).run(id,stateId,key,governor.id,req.player.id,decreeText,now);
 });
 tx();
 res.status(201).json({ok:true,decree:{id,state:state.name,region:key,governor:governor.nickname,text:decreeText,createdAt:now}});
});
app.post('/api/game/region/:key/residency',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.body?.name||key).slice(0,100),country=String(req.body?.country||'').slice(0,80);
 if(!key)return fail(res,400,'Спочатку обери регіон.');
 const existing=db.prepare('SELECT region_key,region_name FROM regional_residencies WHERE player_id=?').get(req.player.id);
 if(existing&&existing.region_key===key)return res.json({ok:true,alreadyRegistered:true,region:existing});
 const now=new Date().toISOString();
 const tx=db.transaction(()=>{
  db.prepare('INSERT INTO regional_residencies(player_id,region_key,region_name,registered_at) VALUES(?,?,?,?) ON CONFLICT(player_id) DO UPDATE SET region_key=excluded.region_key,region_name=excluded.region_name,registered_at=excluded.registered_at').run(req.player.id,key,name,now);
  db.prepare('UPDATE players SET home_region=? WHERE id=?').run(name,req.player.id);
  db.prepare('INSERT INTO player_region_presence(player_id,region_key,region_name,updated_at) VALUES(?,?,?,?) ON CONFLICT(player_id) DO UPDATE SET region_key=excluded.region_key,region_name=excluded.region_name,updated_at=excluded.updated_at').run(req.player.id,key,name,Date.now());
  db.prepare(`INSERT OR IGNORE INTO regional_game_profiles(region_key,region_name,country,updated_at) VALUES(?,?,?,?)`).run(key,name,country,now);
 });
 tx();
 res.json({ok:true,region:{key,name},registeredAt:now});
});
app.get('/api/game/medals',auth,(req,res)=>{
 const medals=db.prepare('SELECT medal_key,quantity FROM player_medals WHERE player_id=?').all(req.player.id);
 const academies=db.prepare('SELECT COUNT(*) n FROM academy_build_history WHERE player_id=?').get(req.player.id).n;
 res.json({medals,academyBuilds:academies});
});

app.post('/api/game/region/:key/party',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),regionName=String(req.body?.regionName||key).slice(0,100);
 const name=String(req.body?.name||'').trim(),ideology=String(req.body?.ideology||'').slice(0,60),program=String(req.body?.program||'').slice(0,1000);
 if(!key||name.length<3||name.length>60)return fail(res,400,'Назва партії має містити від 3 до 60 символів.');
 const wallet=ensureRegionWallet(req.player.id,key,regionName);
 if(wallet.gold<25)return fail(res,409,'Для створення партії потрібно 25 золота.');
 const id=randomBytes(12).toString('hex'),now=Date.now();
 try{
  const tx=db.transaction(()=>{
   db.prepare('UPDATE player_region_wallets SET gold=gold-25 WHERE player_id=? AND region_key=?').run(req.player.id,key);
   db.prepare('INSERT INTO regional_parties(id,player_id,region_key,region_name,name,ideology,program,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id,req.player.id,key,regionName,name,ideology,program,now);
   db.prepare("INSERT INTO regional_party_members(party_id,player_id,role,joined_at) VALUES(?,?,'leader',?)").run(id,req.player.id,now);
  });tx();
 }catch(e){return fail(res,409,'Партія з такою назвою вже існує в цьому регіоні.');}
 res.status(201).json({ok:true,id,costGold:25,party:{id,name,ideology,program,created_at:now},wallet:ensureRegionWallet(req.player.id,key,regionName)});
});
app.post('/api/game/travel',auth,(req,res)=>{
 const key=String(req.body?.regionKey||'').slice(0,120),name=String(req.body?.regionName||key).slice(0,100);
 if(!key)return fail(res,400,'Обери регіон для перельоту.');
 const wallet=ensureRegionWallet(req.player.id,key,name);
 if(wallet.gold<50)return fail(res,409,'Для перельоту потрібно 50 золота.');
 const now=Date.now();
 const tx=db.transaction(()=>{
  db.prepare('UPDATE player_region_wallets SET gold=gold-50 WHERE player_id=? AND region_key=?').run(req.player.id,key);
  db.prepare('INSERT INTO player_region_presence(player_id,region_key,region_name,updated_at) VALUES(?,?,?,?) ON CONFLICT(player_id) DO UPDATE SET region_key=excluded.region_key,region_name=excluded.region_name,updated_at=excluded.updated_at').run(req.player.id,key,name,now);
 });tx();
 res.json({ok:true,costGold:50,presence:{regionKey:key,regionName:name},wallet:ensureRegionWallet(req.player.id,key,name)});
});
app.post('/api/game/region/:key/election',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120),name=String(req.body?.name||key).slice(0,100),now=Date.now();
 const parties=db.prepare('SELECT id,name FROM regional_parties WHERE region_key=? ORDER BY created_at').all(key);
 if(!key||!parties.length)return fail(res,409,'Спочатку створи хоча б одну партію в цьому регіоні.');
 const first=db.prepare('SELECT MIN(created_at) AS first_at FROM regional_parties WHERE region_key=?').get(key).first_at;
 const eligibleAt=first+3*60*60*1000;
 if(now<eligibleAt)return fail(res,409,'Вибори можна провести через '+Math.ceil((eligibleAt-now)/60000)+' хвилин після створення першої партії.');
 const existing=db.prepare("SELECT id FROM region_political_elections WHERE region_key=? AND status='scheduled'").get(key);
 if(existing)return fail(res,409,'Вибори для цього регіону вже заплановані.');
 const id=randomBytes(12).toString('hex');
 db.prepare("INSERT INTO region_political_elections(id,region_key,region_name,created_at,eligible_at,status) VALUES(?,?,?,?,?,'scheduled')").run(id,key,name,now,now);
 res.status(201).json({ok:true,id,eligibleAt,parties});
});
app.get('/api/game/region/:key/election',auth,(req,res)=>{
 const key=String(req.params.key||'').slice(0,120);
 const election=db.prepare('SELECT * FROM region_political_elections WHERE region_key=? ORDER BY created_at DESC LIMIT 1').get(key)||null;
 const parties=db.prepare('SELECT id,name,ideology,created_at FROM regional_parties WHERE region_key=? ORDER BY created_at').all(key);
 res.json({election,parties});
});

// Shared online world chat. Messages are stored centrally and clients poll for updates.
app.get('/api/public/chat',auth,(req,res)=>{
 const after=Math.max(0,Number(req.query.after)||0);
 const messages=db.prepare('SELECT id,author_name AS author,body,image_data AS mediaData,media_type AS mediaType,created_at FROM world_chat_messages WHERE id>? ORDER BY id ASC LIMIT 100').all(after);
 const latest=db.prepare('SELECT COALESCE(MAX(id),0) AS id FROM world_chat_messages').get().id;res.json({messages,latest});
});
app.post('/api/public/chat',auth,(req,res)=>{
 const ip=String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim();
 if(!rateLimit('world-chat:'+ip,20,60000))return fail(res,429,'Зачекай перед наступним повідомленням.');
 const {body='',mediaData='',mediaType=''}=req.body||{};
 const allowedMedia=/^(image\/(jpeg|png|webp)|video\/(mp4|webm|quicktime))$/;
 if(typeof body!=='string'||body.length>500||typeof mediaData!=='string'||Buffer.byteLength(mediaData,'utf8')>11_500_000||(!body.trim()&&!mediaData))return fail(res,400,'Додай текст або файл до 8 МБ.');
 if(mediaData&&(!allowedMedia.test(mediaType)||!mediaData.startsWith(`data:${mediaType};base64,`)||!/^[A-Za-z0-9+/=]+$/.test(mediaData.split(',')[1]||'')))return fail(res,400,'Формат не підтримується. Додай JPG, PNG, WEBP, MP4 або WEBM.');
 const info=db.prepare('INSERT INTO world_chat_messages(player_id,author_name,body,image_data,media_type,created_at) VALUES(?,?,?,?,?,?)').run(req.player.id,req.player.nickname,body.trim(),mediaData,mediaData?mediaType:'',new Date().toISOString());
 res.status(201).json({ok:true,id:Number(info.lastInsertRowid)});
});

// Community articles and all interactions require Google authentication.
app.get('/api/public/articles',auth,(req,res)=>{
 const rows=db.prepare(`SELECT a.id,a.author_name AS author,a.title,a.body,a.category,a.created_at,(a.player_id=?) AS is_owner,
 (SELECT COALESCE(SUM(value),0) FROM guest_article_votes v WHERE v.article_id=a.id) AS score,
 (SELECT COUNT(*) FROM guest_article_comments c WHERE c.article_id=a.id) AS comments FROM guest_articles a ORDER BY a.created_at DESC LIMIT 100`).all(req.player.id);
 res.json({articles:rows});
});
app.post('/api/public/articles',auth,(req,res)=>{
 const ip=String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim();
 if(!rateLimit('guest-article:'+ip,5,60*60*1000))return fail(res,429,'Забагато публікацій. Спробуй пізніше.');
 const {title,body,category='general'}=req.body||{};
 if(typeof title!=='string'||title.trim().length<3||title.length>100||typeof body!=='string'||body.trim().length<20||body.length>5000000||typeof category!=='string'||category.length>24)return fail(res,400,'Перевір назву, текст і категорію статті.');
 const authorName=req.player.nickname;
 const safeBody=body.replace(/<(?!\/?(?:p|br|strong|b|em|i|u|s|blockquote|ul|ol|li|h2|h3|a|img)\b)[^>]*>/gi,'').replace(/\s(on\w+|style|srcdoc)=("[^"]*"|'[^']*'|[^\s>]+)/gi,'').replace(/javascript:/gi,'').replace(/<img\b([^>]*)>/gi,(m,a)=>{const src=(a.match(/src=(?:"([^"]*)"|'([^']*)')/i)||[]).slice(1).find(Boolean)||'';return (/^https?:\/\//i.test(src)||/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/i.test(src))&&src.length<4500000?`<img src="${src.replace(/"/g,'&quot;')}" alt="">`:'';});
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 db.prepare('INSERT INTO guest_articles(id,author_name,title,body,category,created_at,edit_key,player_id) VALUES(?,?,?,?,?,?,?,?)').run(id,authorName,title.trim(),safeBody,category,now,'',req.player.id);
 res.status(201).json({id,ok:true});
});
app.put('/api/public/articles/:id',auth,(req,res)=>{
 const {title,body,category='general'}=req.body||{};
 const article=db.prepare('SELECT id,player_id FROM guest_articles WHERE id=?').get(req.params.id);
 if(!article)return fail(res,404,'Статтю не знайдено.');
 if(article.player_id!==req.player.id)return fail(res,403,'Редагувати можна лише власні статті.');
 if(typeof title!=='string'||title.trim().length<3||title.length>100||typeof body!=='string'||body.trim().length<20||body.length>5000000||typeof category!=='string'||category.length>24)return fail(res,400,'Перевір назву, текст і категорію.');
 const safeBody=body.replace(/<(?!\/?(?:p|br|strong|b|em|i|u|s|blockquote|ul|ol|li|h2|h3|a|img)\b)[^>]*>/gi,'').replace(/\s(on\w+|style|srcdoc)=("[^"]*"|'[^']*'|[^\s>]+)/gi,'').replace(/javascript:/gi,'').replace(/<img\b([^>]*)>/gi,(m,a)=>{const src=(a.match(/src=(?:"([^"]*)"|'([^']*)')/i)||[]).slice(1).find(Boolean)||'';return (/^https?:\/\//i.test(src)||/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/i.test(src))&&src.length<4500000?`<img src="${src.replace(/"/g,'&quot;')}" alt="">`:'';});
 db.prepare('UPDATE guest_articles SET title=?,body=?,category=? WHERE id=?').run(title.trim(),safeBody,category,article.id);
 res.json({ok:true,id:article.id});
});
app.post('/api/public/articles/:id/vote',auth,(req,res)=>{
 const id=String(req.params.id||'');const {value}=req.body||{};
 const voterKey=req.player.id;
 if(![1,-1].includes(Number(value)))return fail(res,400,'Голос некоректний.');
 if(!db.prepare('SELECT id FROM guest_articles WHERE id=?').get(id))return fail(res,404,'Статтю не знайдено.');
 const previous=db.prepare('SELECT value FROM guest_article_votes WHERE article_id=? AND voter_key=?').get(id,voterKey);
 if(previous&&previous.value===Number(value))db.prepare('DELETE FROM guest_article_votes WHERE article_id=? AND voter_key=?').run(id,voterKey);
 else db.prepare('INSERT INTO guest_article_votes(article_id,voter_key,value,created_at) VALUES(?,?,?,?) ON CONFLICT(article_id,voter_key) DO UPDATE SET value=excluded.value,created_at=excluded.created_at').run(id,voterKey,Number(value),new Date().toISOString());
 const score=db.prepare('SELECT COALESCE(SUM(value),0) n FROM guest_article_votes WHERE article_id=?').get(id).n;
 res.json({ok:true,score,selected:previous&&previous.value===Number(value)?0:Number(value)});
});
app.get('/api/public/articles/:id/comments',auth,(req,res)=>{
 const rows=db.prepare('SELECT id,author_name AS author,body,created_at FROM guest_article_comments WHERE article_id=? ORDER BY created_at ASC LIMIT 200').all(req.params.id);res.json({comments:rows});
});
app.post('/api/public/articles/:id/comments',auth,(req,res)=>{
 const {body=''}=req.body||{};if(typeof body!=='string'||body.trim().length<1||body.length>1000)return fail(res,400,'Коментар має містити 1–1000 символів.');
 if(!db.prepare('SELECT id FROM guest_articles WHERE id=?').get(req.params.id))return fail(res,404,'Статтю не знайдено.');
 const id=randomBytes(12).toString('hex');db.prepare('INSERT INTO guest_article_comments(id,article_id,author_name,body,created_at,player_id) VALUES(?,?,?,?,?,?)').run(id,req.params.id,req.player.nickname,body.trim(),new Date().toISOString(),req.player.id);res.status(201).json({ok:true,id});
});

app.get('/api/articles',auth,(req,res)=>{
 const rows=db.prepare(`SELECT a.id,a.title,a.body,a.category,a.created_at,a.updated_at,p.nickname AS author,(a.author_id=? ) AS is_owner FROM game_articles a JOIN players p ON p.id=a.author_id ORDER BY a.updated_at DESC LIMIT 100`).all(req.player.id);
 res.json({articles:rows});
});
app.post('/api/articles',auth,(req,res)=>{
 const {title,body,category='general'}=req.body||{};
 if(typeof title!=='string'||title.trim().length<3||title.length>100||typeof body!=='string'||body.trim().length<20||body.length>12000||typeof category!=='string'||category.length>24)return fail(res,400,'Перевір назву, текст і категорію статті.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 db.prepare('INSERT INTO game_articles(id,author_id,title,body,category,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(id,req.player.id,title.trim(),body.trim(),category,now,now);
 res.status(201).json({id});
});
app.patch('/api/articles/:id',auth,(req,res)=>{
 const article=db.prepare('SELECT * FROM game_articles WHERE id=?').get(req.params.id);
 if(!article)return fail(res,404,'Статтю не знайдено.');
 if(article.author_id!==req.player.id)return fail(res,403,'Редагувати можна лише власні статті.');
 const {title,body,category=article.category}=req.body||{};
 if(typeof title!=='string'||title.trim().length<3||title.length>100||typeof body!=='string'||body.trim().length<20||body.length>12000||typeof category!=='string'||category.length>24)return fail(res,400,'Перевір назву, текст і категорію.');
 db.prepare('UPDATE game_articles SET title=?,body=?,category=?,updated_at=? WHERE id=?').run(title.trim(),body.trim(),category,new Date().toISOString(),article.id);
 res.json({ok:true});
});
app.delete('/api/articles/:id',auth,(req,res)=>{
 const article=db.prepare('SELECT author_id FROM game_articles WHERE id=?').get(req.params.id);
 if(!article)return fail(res,404,'Статтю не знайдено.');
 if(article.author_id!==req.player.id)return fail(res,403,'Видаляти можна лише власні статті.');
 db.prepare('DELETE FROM game_articles WHERE id=?').run(req.params.id);res.json({ok:true});
});

app.get('/api/health',(req,res)=>res.json({ok:true,service:'Chemis World API',version:'7.0.5'}));

app.get('/api/me',auth,(req,res)=>res.json({player:req.player,accountLinked:!!db.prepare('SELECT 1 FROM clerk_identities WHERE player_id=?').get(req.player.id),clerkLinked:!!db.prepare('SELECT 1 FROM clerk_identities WHERE player_id=?').get(req.player.id)}));
app.patch('/api/me',auth,(req,res)=>{
 const {bio,homeRegion,nickname}=req.body||{};
 if(typeof bio!=='string'||bio.length>120||typeof homeRegion!=='string'||homeRegion.length>60||!validNick(nickname))return fail(res,400,'Перевір нікнейм, опис і назву регіону.');
 try{db.prepare('UPDATE players SET nickname=?,bio=?,home_region=? WHERE id=?').run(nickname.trim(),bio.trim(),homeRegion.trim(),req.player.id);}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Такий нікнейм уже зайнятий.');throw e;}
 res.json({player:db.prepare('SELECT id,nickname,bio,home_region,created_at FROM players WHERE id=?').get(req.player.id)});
});
app.get('/api/players',auth,(req,res)=>{
 const q=String(req.query.q||'').trim().slice(0,24);
 db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) SELECT id,created_at FROM players').run();
 const players=db.prepare(`SELECT p.id,p.nickname,p.bio,p.home_region,p.created_at,CASE WHEN ps.avatar LIKE 'data:image/%' THEN '👤' ELSE COALESCE(ps.avatar,'👤') END AS avatar,COALESCE(s.xp,0) AS xp,ROUND(COALESCE(s.xp,0)/1000,1) AS level,(SELECT COUNT(*) FROM player_swords sw WHERE sw.owner_id=p.id AND sw.status IN ('owned','listed')) AS swords FROM players p LEFT JOIN player_profile_settings ps ON ps.player_id=p.id LEFT JOIN player_game_stats s ON s.player_id=p.id WHERE p.nickname LIKE ? ORDER BY xp DESC,p.nickname LIMIT 100`).all('%'+q+'%');
 res.json({players,total:db.prepare('SELECT COUNT(*) n FROM players').get().n});
});

// Shared state registry. All ownership checks are enforced on the server.
function stateView(id){
 const state=db.prepare('SELECT s.id,s.owner_id,s.name,s.capital,s.color,s.symbol,s.created_at,p.nickname AS owner_nickname FROM game_states s JOIN players p ON p.id=s.owner_id WHERE s.id=?').get(id);
 if(!state)return null;
 state.territories=db.prepare('SELECT territory_key FROM state_territories WHERE state_id=? ORDER BY added_at').all(id).map(x=>x.territory_key);
 return state;
}
app.get('/api/states',auth,(req,res)=>{
 const rows=db.prepare('SELECT id FROM game_states ORDER BY created_at DESC LIMIT 100').all();
 res.json({states:rows.map(x=>stateView(x.id))});
});
app.post('/api/states',auth,(req,res)=>{
 const {name,capital,color,symbol,territories}=req.body||{};
 if(typeof name!=='string'||name.trim().length<3||name.trim().length>40)return fail(res,400,'Назва держави має містити 3–40 символів.');
 if(typeof capital!=='string'||capital.trim().length<2||capital.trim().length>40)return fail(res,400,'Перевір назву столиці.');
 if(typeof color!=='string'||!/^#[0-9a-fA-F]{6}$/.test(color))return fail(res,400,'Некоректний колір прапора.');
 if(typeof symbol!=='string'||symbol.length>3)return fail(res,400,'Некоректний символ.');
 if(!Array.isArray(territories)||territories.length<1||territories.length>100)return fail(res,400,'Держава повинна мати від 1 до 100 територій.');
 const clean=[...new Set(territories.map(x=>typeof x==='string'?x.trim():'').filter(x=>x.length>0&&x.length<=180))];
 if(clean.length!==territories.length)return fail(res,400,'Перевір список територій: є повтори або некоректні значення.');
 const id=randomBytes(16).toString('hex'), now=new Date().toISOString();
 const insertState=db.prepare('INSERT INTO game_states(id,owner_id,name,capital,color,symbol,created_at) VALUES(?,?,?,?,?,?,?)');
 const insertTerritory=db.prepare('INSERT INTO state_territories(state_id,territory_key,added_at) VALUES(?,?,?)');
 try{
  const transaction=db.transaction(()=>{insertState.run(id,req.player.id,name.trim(),capital.trim(),color,symbol||'★',now);for(const key of clean)insertTerritory.run(id,key,now);});
  transaction();
 }catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Одна з територій уже належить іншій державі.');throw e;}
 cwTreasury(id);cwEvent(req.player.id,'politics','Створено нову державу',name.trim());
 res.status(201).json({state:stateView(id)});
});
app.post('/api/states/:id/territories',auth,(req,res)=>{
 const {territoryKey}=req.body||{};
 if(typeof territoryKey!=='string'||territoryKey.trim().length<1||territoryKey.trim().length>180)return fail(res,400,'Некоректна територія.');
 const state=db.prepare('SELECT id,owner_id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 if(state.owner_id!==req.player.id)return fail(res,403,'Лише власник може змінювати території цієї держави.');
 try{db.prepare('INSERT INTO state_territories(state_id,territory_key,added_at) VALUES(?,?,?)').run(state.id,territoryKey.trim(),new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Ця територія вже належить державі.');throw e;}
 res.status(201).json({state:stateView(state.id)});
});


// Server-authoritative political system: parties, one-person-one-vote elections and law proposals.
function ownedState(stateId,playerId){return db.prepare('SELECT * FROM game_states WHERE id=? AND owner_id=?').get(stateId,playerId);}
app.get('/api/states/:id/politics',auth,(req,res)=>{
 const state=db.prepare('SELECT id,name,owner_id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 const parties=db.prepare(`SELECT pp.id,pp.name,pp.ideology,pp.platform,pp.creator_id,p.nickname AS creator FROM political_parties pp JOIN players p ON p.id=pp.creator_id WHERE pp.state_id=? ORDER BY pp.created_at`).all(state.id);
 const elections=db.prepare('SELECT id,status,created_at,closes_at FROM state_elections WHERE state_id=? ORDER BY created_at DESC LIMIT 20').all(state.id).map(e=>{
  const results=db.prepare(`SELECT c.party_id,c.candidate_name,pp.name AS party_name,COUNT(v.voter_id) AS votes,COALESCE(ps.seats,0) AS seats FROM election_candidates c JOIN political_parties pp ON pp.id=c.party_id LEFT JOIN election_votes v ON v.election_id=c.election_id AND v.party_id=c.party_id LEFT JOIN parliament_seats ps ON ps.election_id=c.election_id AND ps.party_id=c.party_id WHERE c.election_id=? GROUP BY c.party_id`).all(e.id);
  return {...e,results};
 });
 const laws=db.prepare('SELECT id,title,description,status,created_at FROM state_laws WHERE state_id=? ORDER BY created_at DESC LIMIT 50').all(state.id).map(l=>{
  const tally=db.prepare("SELECT decision,COUNT(*) AS votes FROM law_votes WHERE law_id=? GROUP BY decision").all(l.id);
  return {...l,tally};
 });
 const government=db.prepare('SELECT * FROM state_governments WHERE state_id=?').get(state.id);
 const ministers=government?db.prepare('SELECT portfolio,minister_name FROM government_ministers WHERE state_id=? ORDER BY portfolio').all(state.id):[];
 const parliament=elections.filter(e=>e.status==='closed').slice(0,1).map(e=>({election_id:e.id,seats:db.prepare('SELECT ps.party_id,pp.name AS party_name,ps.seats FROM parliament_seats ps JOIN political_parties pp ON pp.id=ps.party_id WHERE ps.election_id=? ORDER BY ps.seats DESC').all(e.id)}))[0]||null;
 res.json({state,parties,elections,laws,government, ministers, parliament});
});
app.post('/api/states/:id/parties',auth,(req,res)=>{
 const state=db.prepare('SELECT id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 const {name,ideology='',platform=''}=req.body||{};
 if(typeof name!=='string'||name.trim().length<3||name.trim().length>50)return fail(res,400,'Назва партії має містити 3–50 символів.');
 if(typeof ideology!=='string'||ideology.length>60||typeof platform!=='string'||platform.length>300)return fail(res,400,'Перевір ідеологію та програму.');
 const id=randomBytes(12).toString('hex');
 try{db.prepare('INSERT INTO political_parties(id,state_id,creator_id,name,ideology,platform,created_at) VALUES(?,?,?,?,?,?,?)').run(id,state.id,req.player.id,name.trim(),ideology.trim(),platform.trim(),new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'У цій державі вже є партія з такою назвою.');throw e;}
 res.status(201).json({party:db.prepare('SELECT id,name,ideology,platform FROM political_parties WHERE id=?').get(id)});
});
app.post('/api/states/:id/elections',auth,(req,res)=>{
 if(!ownedState(req.params.id,req.player.id))return fail(res,403,'Вибори може оголосити лише власник держави.');
 const parties=db.prepare('SELECT id,name FROM political_parties WHERE state_id=?').all(req.params.id);
 if(parties.length<2)return fail(res,400,'Для виборів потрібно щонайменше дві партії.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{
  db.prepare('INSERT INTO state_elections(id,state_id,created_by,status,created_at) VALUES(?,?,?,"open",?)').run(id,req.params.id,req.player.id,now);
  const candidate=db.prepare('INSERT INTO election_candidates(election_id,party_id,candidate_name) VALUES(?,?,?)');
  for(const p of parties)candidate.run(id,p.id,p.name);
 });
 tx();res.status(201).json({electionId:id,status:'open'});
});
app.post('/api/elections/:id/vote',auth,(req,res)=>{
 const election=db.prepare('SELECT * FROM state_elections WHERE id=?').get(req.params.id);
 if(!election)return fail(res,404,'Вибори не знайдено.');
 if(election.status!=='open')return fail(res,409,'Голосування вже завершено.');
 const {partyId}=req.body||{};
 const candidate=db.prepare('SELECT 1 FROM election_candidates WHERE election_id=? AND party_id=?').get(election.id,partyId);
 if(!candidate)return fail(res,400,'Обрана партія не бере участі в цих виборах.');
 try{db.prepare('INSERT INTO election_votes(election_id,voter_id,party_id,created_at) VALUES(?,?,?,?)').run(election.id,req.player.id,partyId,new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Ти вже проголосував у цих виборах.');throw e;}
 res.status(201).json({ok:true,message:'Голос зараховано.'});
});
app.post('/api/elections/:id/close',auth,(req,res)=>{
 const election=db.prepare('SELECT * FROM state_elections WHERE id=?').get(req.params.id);
 if(!election)return fail(res,404,'Вибори не знайдено.');
 if(!ownedState(election.state_id,req.player.id))return fail(res,403,'Завершити вибори може лише власник держави.');
 const results=db.prepare(`SELECT c.party_id,c.candidate_name,pp.name AS party_name,COUNT(v.voter_id) AS votes FROM election_candidates c JOIN political_parties pp ON pp.id=c.party_id LEFT JOIN election_votes v ON v.election_id=c.election_id AND v.party_id=c.party_id WHERE c.election_id=? GROUP BY c.party_id ORDER BY votes DESC`).all(election.id);
 const total=results.reduce((n,r)=>n+r.votes,0);
 if(total===0)return fail(res,409,'Немає жодного голосу: вибори не можна завершити без учасників.');
 const seatsTotal=100;
 const allocations=results.map(r=>({...r,seats:total?Math.floor(r.votes/total*seatsTotal):0}));
 let remainder=seatsTotal-allocations.reduce((n,r)=>n+r.seats,0);
 allocations.sort((a,b)=>((total?b.votes/total*seatsTotal-Math.floor(b.votes/total*seatsTotal):0)-(total?a.votes/total*seatsTotal-Math.floor(a.votes/total*seatsTotal):0)));
 for(let i=0;i<remainder;i++)allocations[i%allocations.length].seats++;
 const tx=db.transaction(()=>{
  db.prepare('UPDATE state_elections SET status="closed" WHERE id=?').run(election.id);
  const put=db.prepare('INSERT OR REPLACE INTO parliament_seats(election_id,party_id,seats) VALUES(?,?,?)');
  for(const a of allocations)put.run(election.id,a.party_id,a.seats);
 });
 tx();
 res.json({status:'closed',results:allocations,seatsTotal});
});
app.post('/api/states/:id/laws',auth,(req,res)=>{
 const state=db.prepare('SELECT id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 const {title,description}=req.body||{};
 if(typeof title!=='string'||title.trim().length<4||title.length>80||typeof description!=='string'||description.length>1000)return fail(res,400,'Перевір назву та опис законопроєкту.');
 const id=randomBytes(12).toString('hex');
 db.prepare('INSERT INTO state_laws(id,state_id,author_id,title,description,created_at) VALUES(?,?,?,?,?,?)').run(id,state.id,req.player.id,title.trim(),description.trim(),new Date().toISOString());
 res.status(201).json({law:{id,title:title.trim(),status:'proposed'}});
});
app.post('/api/laws/:id/vote',auth,(req,res)=>{
 const law=db.prepare('SELECT * FROM state_laws WHERE id=?').get(req.params.id);
 if(!law)return fail(res,404,'Законопроєкт не знайдено.');
 if(law.status!=='proposed')return fail(res,409,'Голосування за цей законопроєкт уже завершено.');
 const {decision}=req.body||{};
 if(!['yes','no'].includes(decision))return fail(res,400,'Вкажи yes або no.');
 const latest=db.prepare("SELECT id FROM state_elections WHERE state_id=? AND status='closed' ORDER BY created_at DESC LIMIT 1").get(law.state_id);
 if(!latest)return fail(res,409,'Спочатку мають відбутися вибори до парламенту.');
 const membership=db.prepare('SELECT 1 FROM parliament_seats WHERE election_id=? AND seats>0 LIMIT 1').get(latest.id);
 if(!membership)return fail(res,409,'Парламент ще не сформовано.');
 try{db.prepare('INSERT INTO law_votes(law_id,voter_id,decision,created_at) VALUES(?,?,?,?)').run(law.id,req.player.id,decision,new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Твій голос за цей законопроєкт уже враховано.');throw e;}
 const tally=db.prepare('SELECT decision,COUNT(*) AS votes FROM law_votes WHERE law_id=? GROUP BY decision').all(law.id);
 const yes=tally.find(x=>x.decision==='yes')?.votes||0,no=tally.find(x=>x.decision==='no')?.votes||0;
 // The simple public prototype closes when the state owner reviews the result, not automatically.
 res.status(201).json({ok:true,tally:{yes,no},message:'Голос депутата/учасника зараховано.'});
});


app.post('/api/states/:id/government',auth,(req,res)=>{
 if(!ownedState(req.params.id,req.player.id))return fail(res,403,'Уряд може сформувати лише власник держави.');
 const latest=db.prepare("SELECT id FROM state_elections WHERE state_id=? AND status='closed' ORDER BY created_at DESC LIMIT 1").get(req.params.id);
 if(!latest)return fail(res,409,'Спочатку заверши вибори та сформуй парламент.');
 const {primeMinister,ministers}=req.body||{};
 if(typeof primeMinister!=='string'||primeMinister.trim().length<2||primeMinister.length>60||!Array.isArray(ministers)||ministers.length>12)return fail(res,400,'Перевір кандидатуру прем’єр-міністра та склад уряду.');
 const valid=['Фінанси','Освіта','Інфраструктура','Охорона здоров’я','Зовнішні справи','Культура','Екологія','Цифровізація'];
 for(const m of ministers)if(!m||!valid.includes(m.portfolio)||typeof m.name!=='string'||m.name.trim().length<2||m.name.length>60)return fail(res,400,'Некоректні дані міністра.');
 const tx=db.transaction(()=>{
  db.prepare('INSERT OR REPLACE INTO state_governments(state_id,election_id,prime_minister,formed_by,formed_at) VALUES(?,?,?,?,?)').run(req.params.id,latest.id,primeMinister.trim(),req.player.id,new Date().toISOString());
  db.prepare('DELETE FROM government_ministers WHERE state_id=?').run(req.params.id);
  const put=db.prepare('INSERT INTO government_ministers(state_id,portfolio,minister_name) VALUES(?,?,?)');
  for(const m of ministers)put.run(req.params.id,m.portfolio,m.name.trim());
 });
 tx();res.status(201).json({ok:true,primeMinister:primeMinister.trim(),ministers:ministers.length});
});
app.post('/api/laws/:id/finalize',auth,(req,res)=>{
 const law=db.prepare('SELECT * FROM state_laws WHERE id=?').get(req.params.id);
 if(!law)return fail(res,404,'Законопроєкт не знайдено.');
 if(!ownedState(law.state_id,req.player.id))return fail(res,403,'Підсумкове рішення може підтвердити власник держави.');
 if(law.status!=='proposed')return fail(res,409,'Закон уже має остаточний статус.');
 const yes=db.prepare("SELECT COUNT(*) AS n FROM law_votes WHERE law_id=? AND decision='yes'").get(law.id).n;
 const no=db.prepare("SELECT COUNT(*) AS n FROM law_votes WHERE law_id=? AND decision='no'").get(law.id).n;
 if(yes===no)return fail(res,409,'Немає більшості: голоси порівну або їх ще немає.');
 const status=yes>no?'adopted':'rejected';
 db.prepare('UPDATE state_laws SET status=? WHERE id=?').run(status,law.id);
 res.json({status,yes,no});
});


// Regional administration and local council elections.
app.get('/api/states/:id/regions',auth,(req,res)=>{
 const state=db.prepare('SELECT id,name,owner_id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 const regions=db.prepare(`SELECT t.territory_key,ra.governor_id,p.nickname AS governor
 FROM state_territories t LEFT JOIN regional_administrations ra ON ra.state_id=t.state_id AND ra.territory_key=t.territory_key
 LEFT JOIN players p ON p.id=ra.governor_id WHERE t.state_id=? ORDER BY t.territory_key`).all(state.id);
 const elections=db.prepare(`SELECT e.id,e.territory_key,e.status,e.created_at,
 (SELECT COUNT(*) FROM regional_votes v WHERE v.election_id=e.id) AS turnout
 FROM regional_elections e WHERE e.state_id=? ORDER BY e.created_at DESC LIMIT 30`).all(state.id);
 const councils=db.prepare(`SELECT e.id,e.territory_key,c.candidate_name,c.votes,c.seats
 FROM regional_elections e JOIN regional_councils c ON c.election_id=e.id
 WHERE e.state_id=? ORDER BY e.created_at DESC,c.seats DESC`).all(state.id);
 res.json({state,regions,elections,councils});
});
app.post('/api/states/:id/regions/governor',auth,(req,res)=>{
 if(!ownedState(req.params.id,req.player.id))return fail(res,403,'Керівників регіонів призначає власник держави.');
 const {territoryKey,nickname}=req.body||{};
 if(typeof territoryKey!=='string'||typeof nickname!=='string'||!territoryKey.trim()||!nickname.trim())return fail(res,400,'Вкажи територію та нікнейм гравця.');
 const territory=db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,territoryKey.trim());
 if(!territory)return fail(res,404,'Ця територія не входить до складу держави.');
 const player=db.prepare('SELECT id FROM players WHERE nickname=? COLLATE NOCASE').get(nickname.trim());
 if(!player)return fail(res,404,'Гравця з таким нікнеймом не знайдено.');
 db.prepare(`INSERT INTO regional_administrations(state_id,territory_key,governor_id,appointed_by,updated_at)
 VALUES(?,?,?,?,?) ON CONFLICT(state_id,territory_key) DO UPDATE SET governor_id=excluded.governor_id,appointed_by=excluded.appointed_by,updated_at=excluded.updated_at`)
 .run(req.params.id,territoryKey.trim(),player.id,req.player.id,new Date().toISOString());
 res.json({ok:true,governor:nickname.trim()});
});
app.post('/api/states/:id/regions/elections',auth,(req,res)=>{
 if(!ownedState(req.params.id,req.player.id))return fail(res,403,'Місцеві вибори оголошує власник держави.');
 const {territoryKey,candidates}=req.body||{};
 if(typeof territoryKey!=='string'||!Array.isArray(candidates)||candidates.length<2||candidates.length>20)return fail(res,400,'Потрібно вказати територію та 2–20 кандидатів.');
 const key=territoryKey.trim();
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територія не належить цій державі.');
 const clean=[...new Set(candidates.map(x=>typeof x==='string'?x.trim():'').filter(x=>x.length>=2&&x.length<=60))];
 if(clean.length!==candidates.length)return fail(res,400,'Перевір імена кандидатів: повтори або некоректні значення.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{db.prepare('INSERT INTO regional_elections(id,state_id,territory_key,created_by,status,created_at) VALUES(?,?,?,?,"open",?)').run(id,req.params.id,key,req.player.id,now);const put=db.prepare('INSERT INTO regional_candidates(election_id,candidate_name) VALUES(?,?)');for(const c of clean)put.run(id,c);});
 tx();res.status(201).json({electionId:id,status:'open'});
});
app.get('/api/regions/elections/:id',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM regional_elections WHERE id=?').get(req.params.id);
 if(!e)return fail(res,404,'Місцеві вибори не знайдено.');
 const candidates=db.prepare(`SELECT c.candidate_name,COUNT(v.voter_id) AS votes,COALESCE(rc.seats,0) AS seats
 FROM regional_candidates c LEFT JOIN regional_votes v ON v.election_id=c.election_id AND v.candidate_name=c.candidate_name
 LEFT JOIN regional_councils rc ON rc.election_id=c.election_id AND rc.candidate_name=c.candidate_name
 WHERE c.election_id=? GROUP BY c.candidate_name ORDER BY votes DESC`).all(e.id);
 res.json({election:e,candidates});
});
app.post('/api/regions/elections/:id/vote',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM regional_elections WHERE id=?').get(req.params.id);
 if(!e)return fail(res,404,'Місцеві вибори не знайдено.');
 if(e.status!=='open')return fail(res,409,'Місцеве голосування завершено.');
 const {candidateName}=req.body||{};
 if(!db.prepare('SELECT 1 FROM regional_candidates WHERE election_id=? AND candidate_name=?').get(e.id,candidateName))return fail(res,400,'Такого кандидата немає у бюлетені.');
 try{db.prepare('INSERT INTO regional_votes(election_id,voter_id,candidate_name,created_at) VALUES(?,?,?,?)').run(e.id,req.player.id,candidateName,new Date().toISOString());}
 catch(err){if(String(err).includes('UNIQUE'))return fail(res,409,'Ти вже голосував на цих місцевих виборах.');throw err;}
 res.status(201).json({ok:true});
});
app.post('/api/regions/elections/:id/close',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM regional_elections WHERE id=?').get(req.params.id);
 if(!e)return fail(res,404,'Місцеві вибори не знайдено.');
 if(!ownedState(e.state_id,req.player.id))return fail(res,403,'Завершити місцеві вибори може лише власник держави.');
 if(e.status!=='open')return fail(res,409,'Вибори вже завершені.');
 const results=db.prepare(`SELECT c.candidate_name,COUNT(v.voter_id) AS votes FROM regional_candidates c LEFT JOIN regional_votes v ON v.election_id=c.election_id AND v.candidate_name=c.candidate_name WHERE c.election_id=? GROUP BY c.candidate_name`).all(e.id);
 const total=results.reduce((n,r)=>n+r.votes,0);
 if(!total)return fail(res,409,'Немає голосів: вибори не можна завершити.');
 const seats=15,alloc=results.map(r=>({...r,seats:Math.floor(r.votes/total*seats)}));
 let remaining=seats-alloc.reduce((n,r)=>n+r.seats,0);
 alloc.sort((a,b)=>(b.votes/total*seats-Math.floor(b.votes/total*seats))-(a.votes/total*seats-Math.floor(a.votes/total*seats)));
 for(let i=0;i<remaining;i++)alloc[i%alloc.length].seats++;
 const tx=db.transaction(()=>{db.prepare('UPDATE regional_elections SET status="closed" WHERE id=?').run(e.id);const put=db.prepare('INSERT INTO regional_councils(election_id,candidate_name,votes,seats) VALUES(?,?,?,?)');for(const r of alloc)put.run(e.id,r.candidate_name,r.votes,r.seats);});
 tx();res.json({status:'closed',council:alloc,seatsTotal:seats});
});


// Regional economy, public works, local laws and mayoral elections.
const REGION_BUILDINGS={
 'Школа':{cost:300,income:15},'Лікарня':{cost:450,income:20},
 'Дорога':{cost:250,income:25},'Культурний центр':{cost:220,income:12},
 'Водопостачання':{cost:350,income:18}
};
function ensureRegionalEconomy(stateId,key){
 db.prepare(`INSERT OR IGNORE INTO regional_economies(state_id,territory_key,updated_at) VALUES(?,?,?)`)
 .run(stateId,key,new Date().toISOString());
 return db.prepare('SELECT * FROM regional_economies WHERE state_id=? AND territory_key=?').get(stateId,key);
}
function canManageRegion(stateId,key,playerId){
 if(ownedState(stateId,playerId))return true;
 return !!db.prepare('SELECT 1 FROM regional_administrations WHERE state_id=? AND territory_key=? AND governor_id=?').get(stateId,key,playerId);
}
function completeDueConstruction(stateId,key){const now=Date.now();const due=db.prepare("SELECT * FROM regional_construction_queue WHERE state_id=? AND territory_key=? AND status='pending' AND completes_at<=?").all(stateId,key,now);if(!due.length)return;const tx=db.transaction(()=>{for(const item of due){const changed=db.prepare("UPDATE regional_construction_queue SET status='completed',completed_at=? WHERE id=? AND status='pending' AND completes_at<=?").run(now,item.id,now);if(changed.changes===1){db.prepare('INSERT INTO regional_buildings(id,state_id,territory_key,building_type,level,created_by,created_at) VALUES(?,?,?,?,1,?,?)').run(item.id,stateId,key,item.building_type,item.created_by,new Date(now).toISOString());db.prepare('UPDATE regional_economies SET infrastructure_level=infrastructure_level+1,updated_at=? WHERE state_id=? AND territory_key=?').run(new Date(now).toISOString(),stateId,key);}}});tx();}
app.get('/api/states/:id/regions/:key/economy',auth,(req,res)=>{
 const key=req.params.key;completeDueConstruction(req.params.id,key);
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 const economy=ensureRegionalEconomy(req.params.id,key);
 const buildings=db.prepare('SELECT id,building_type,level,created_at FROM regional_buildings WHERE state_id=? AND territory_key=? ORDER BY created_at').all(req.params.id,key);
 const mayor=db.prepare('SELECT mayor_name FROM regional_mayors WHERE state_id=? AND territory_key=?').get(req.params.id,key);
 const construction=db.prepare('SELECT id,building_type,cost,started_at,completes_at,status FROM regional_construction_queue WHERE state_id=? AND territory_key=? ORDER BY started_at DESC LIMIT 30').all(req.params.id,key);
 const laws=db.prepare(`SELECT l.id,l.title,l.description,l.status,
 (SELECT COUNT(*) FROM regional_local_law_votes v WHERE v.law_id=l.id AND v.decision='yes') AS yes,
 (SELECT COUNT(*) FROM regional_local_law_votes v WHERE v.law_id=l.id AND v.decision='no') AS no
 FROM regional_local_laws l WHERE l.state_id=? AND l.territory_key=? ORDER BY l.created_at DESC LIMIT 30`).all(req.params.id,key);
 const elections=db.prepare(`SELECT e.id,e.status,e.winner,e.created_at,
 (SELECT COUNT(*) FROM mayor_votes v WHERE v.election_id=e.id) AS turnout
 FROM mayor_elections e WHERE e.state_id=? AND e.territory_key=? ORDER BY e.created_at DESC LIMIT 10`).all(req.params.id,key);
 res.json({economy,buildings,construction,mayor:mayor?.mayor_name||null,laws,elections,buildingCatalog:REGION_BUILDINGS});
});
app.post('/api/states/:id/regions/:key/economy/tax',auth,(req,res)=>{
 const key=req.params.key,{taxRate}=req.body||{};
 if(!canManageRegion(req.params.id,key,req.player.id))return fail(res,403,'Змінювати місцеві податки може керівник регіону або власник держави.');
 if(!Number.isInteger(taxRate)||taxRate<0||taxRate>25)return fail(res,400,'Податкова ставка має бути від 0 до 25%.');
 ensureRegionalEconomy(req.params.id,key);
 db.prepare('UPDATE regional_economies SET tax_rate=?,updated_at=? WHERE state_id=? AND territory_key=?').run(taxRate,new Date().toISOString(),req.params.id,key);
 res.json({ok:true,taxRate});
});
app.post('/api/states/:id/regions/:key/economy/collect',auth,(req,res)=>{
 const key=req.params.key;
 if(!canManageRegion(req.params.id,key,req.player.id))return fail(res,403,'Збирати дохід може керівник регіону або власник держави.');
 const territory=db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key);
 if(!territory)return fail(res,404,'Територію не знайдено.');
 const e=ensureRegionalEconomy(req.params.id,key);
 const now=Date.now();if(e.last_income_at&&now-e.last_income_at<6*60*60*1000)return fail(res,409,'Наступний регіональний дохід доступний через шість годин.');
 const buildings=db.prepare('SELECT building_type,level FROM regional_buildings WHERE state_id=? AND territory_key=?').all(req.params.id,key);
 const buildingIncome=buildings.reduce((sum,b)=>sum+(REGION_BUILDINGS[b.building_type]?.income||0)*b.level,0);
 const income=Math.max(0,Math.floor((100+e.infrastructure_level*35+buildingIncome)*(1+e.tax_rate/100)));
 db.prepare('UPDATE regional_economies SET treasury=treasury+?,turn_number=turn_number+1,last_income_at=?,updated_at=? WHERE state_id=? AND territory_key=?').run(income,now,new Date().toISOString(),req.params.id,key);
 res.json({ok:true,income,turn:e.turn_number+1,treasury:e.treasury+income});
});
app.post('/api/states/:id/regions/:key/buildings',auth,(req,res)=>{
 const key=req.params.key,{buildingType}=req.body||{};if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено в цій державі.');if(!canManageRegion(req.params.id,key,req.player.id))return fail(res,403,'Будувати може керівник регіону або власник держави.');
 const spec=REGION_BUILDINGS[buildingType];if(!spec)return fail(res,400,'Невідомий тип будівлі.');const e=ensureRegionalEconomy(req.params.id,key);if(e.treasury<spec.cost)return fail(res,409,'Недостатньо коштів у бюджеті регіону.');
 const gov=db.prepare('SELECT government_type FROM state_government_settings WHERE state_id=?').get(req.params.id);const baseDuration=spec.cost>=400?20*60*1000:10*60*1000;const duration=(!gov||gov.government_type==='democracy')?Math.round(baseDuration/1.2):baseDuration;
 const id=randomBytes(12).toString('hex'),now=Date.now(),stamp=new Date(now).toISOString();const tx=db.transaction(()=>{const debit=db.prepare('UPDATE regional_economies SET treasury=treasury-?,updated_at=? WHERE state_id=? AND territory_key=? AND treasury>=?').run(spec.cost,stamp,req.params.id,key,spec.cost);if(debit.changes!==1)throw new Error('NO_REGION_FUNDS');db.prepare("INSERT INTO regional_construction_queue(id,state_id,territory_key,building_type,cost,duration_ms,started_at,completes_at,status,created_by) VALUES(?,?,?,?,?,?,?,?, 'pending',?)").run(id,req.params.id,key,buildingType,spec.cost,duration,now,now+duration,req.player.id);});try{tx();}catch(err){if(err.message==='NO_REGION_FUNDS')return fail(res,409,'Недостатньо коштів у бюджеті регіону.');throw err;}res.status(202).json({ok:true,id,buildingType,cost:spec.cost,startedAt:now,completesAt:now+duration,durationMs:duration,treasury:e.treasury-spec.cost});
});
app.post('/api/states/:id/regions/:key/laws',auth,(req,res)=>{
 const key=req.params.key,{title,description}=req.body||{};
 if(!canManageRegion(req.params.id,key,req.player.id))return fail(res,403,'Місцевий законопроєкт може подати керівник регіону або власник держави.');
 if(typeof title!=='string'||title.trim().length<3||title.length>80||typeof description!=='string'||description.trim().length<5||description.length>700)return fail(res,400,'Перевір назву та опис законопроєкту.');
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 const id=randomBytes(12).toString('hex');
 db.prepare('INSERT INTO regional_local_laws(id,state_id,territory_key,title,description,created_by,created_at) VALUES(?,?,?,?,?,?,?)').run(id,req.params.id,key,title.trim(),description.trim(),req.player.id,new Date().toISOString());
 res.status(201).json({id,status:'proposed'});
});
app.post('/api/regions/local-laws/:id/vote',auth,(req,res)=>{
 const law=db.prepare('SELECT * FROM regional_local_laws WHERE id=?').get(req.params.id);
 if(!law)return fail(res,404,'Місцевий законопроєкт не знайдено.');
 if(law.status!=='proposed')return fail(res,409,'Голосування завершено.');
 const {decision}=req.body||{};if(!['yes','no'].includes(decision))return fail(res,400,'Вкажи yes або no.');
 try{db.prepare('INSERT INTO regional_local_law_votes(law_id,voter_id,decision,created_at) VALUES(?,?,?,?)').run(law.id,req.player.id,decision,new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Ти вже голосував за цей законопроєкт.');throw e;}
 const yes=db.prepare("SELECT COUNT(*) n FROM regional_local_law_votes WHERE law_id=? AND decision='yes'").get(law.id).n;
 const no=db.prepare("SELECT COUNT(*) n FROM regional_local_law_votes WHERE law_id=? AND decision='no'").get(law.id).n;
 res.status(201).json({ok:true,yes,no});
});
app.post('/api/regions/local-laws/:id/finalize',auth,(req,res)=>{
 const law=db.prepare('SELECT * FROM regional_local_laws WHERE id=?').get(req.params.id);
 if(!law)return fail(res,404,'Місцевий законопроєкт не знайдено.');
 if(!canManageRegion(law.state_id,law.territory_key,req.player.id))return fail(res,403,'Результат підтверджує керівник регіону або власник держави.');
 if(law.status!=='proposed')return fail(res,409,'Законопроєкт уже завершено.');
 const yes=db.prepare("SELECT COUNT(*) n FROM regional_local_law_votes WHERE law_id=? AND decision='yes'").get(law.id).n;
 const no=db.prepare("SELECT COUNT(*) n FROM regional_local_law_votes WHERE law_id=? AND decision='no'").get(law.id).n;
 if(yes===no)return fail(res,409,'Немає більшості голосів.');
 const status=yes>no?'adopted':'rejected';
 db.prepare('UPDATE regional_local_laws SET status=? WHERE id=?').run(status,law.id);res.json({status,yes,no});
});
app.post('/api/states/:id/regions/:key/mayor-elections',auth,(req,res)=>{
 const key=req.params.key,{candidates}=req.body||{};
 if(!ownedState(req.params.id,req.player.id))return fail(res,403,'Вибори мера оголошує власник держави.');
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 if(!Array.isArray(candidates)||candidates.length<2||candidates.length>15)return fail(res,400,'Потрібно 2–15 кандидатів.');
 const clean=[...new Set(candidates.map(x=>typeof x==='string'?x.trim():'').filter(x=>x.length>=2&&x.length<=60))];
 if(clean.length!==candidates.length)return fail(res,400,'Перевір список кандидатів.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{db.prepare('INSERT INTO mayor_elections(id,state_id,territory_key,created_by,created_at) VALUES(?,?,?,?,?)').run(id,req.params.id,key,req.player.id,now);const put=db.prepare('INSERT INTO mayor_candidates(election_id,candidate_name) VALUES(?,?)');clean.forEach(x=>put.run(id,x));});
 tx();res.status(201).json({id,status:'open'});
});
app.get('/api/mayor-elections/:id',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM mayor_elections WHERE id=?').get(req.params.id);if(!e)return fail(res,404,'Вибори мера не знайдено.');
 const candidates=db.prepare(`SELECT c.candidate_name,COUNT(v.voter_id) votes FROM mayor_candidates c LEFT JOIN mayor_votes v ON v.election_id=c.election_id AND v.candidate_name=c.candidate_name WHERE c.election_id=? GROUP BY c.candidate_name ORDER BY votes DESC`).all(e.id);
 res.json({election:e,candidates});
});
app.post('/api/mayor-elections/:id/vote',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM mayor_elections WHERE id=?').get(req.params.id);if(!e)return fail(res,404,'Вибори мера не знайдено.');
 if(e.status!=='open')return fail(res,409,'Вибори завершено.');
 const {candidateName}=req.body||{};
 if(!db.prepare('SELECT 1 FROM mayor_candidates WHERE election_id=? AND candidate_name=?').get(e.id,candidateName))return fail(res,400,'Кандидата немає у бюлетені.');
 try{db.prepare('INSERT INTO mayor_votes(election_id,voter_id,candidate_name,created_at) VALUES(?,?,?,?)').run(e.id,req.player.id,candidateName,new Date().toISOString());}
 catch(err){if(String(err).includes('UNIQUE'))return fail(res,409,'Ти вже голосував на цих виборах.');throw err;}
 res.status(201).json({ok:true});
});
app.post('/api/mayor-elections/:id/close',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM mayor_elections WHERE id=?').get(req.params.id);if(!e)return fail(res,404,'Вибори мера не знайдено.');
 if(!ownedState(e.state_id,req.player.id))return fail(res,403,'Завершити вибори може власник держави.');
 if(e.status!=='open')return fail(res,409,'Вибори вже завершено.');
 const results=db.prepare(`SELECT c.candidate_name,COUNT(v.voter_id) votes FROM mayor_candidates c LEFT JOIN mayor_votes v ON v.election_id=c.election_id AND v.candidate_name=c.candidate_name WHERE c.election_id=? GROUP BY c.candidate_name ORDER BY votes DESC,c.candidate_name`).all(e.id);
 if(!results[0]?.votes)return fail(res,409,'Немає голосів.');
 const winner=results[0].candidate_name,now=new Date().toISOString();
 const tx=db.transaction(()=>{db.prepare("UPDATE mayor_elections SET status='closed',winner=? WHERE id=?").run(winner,e.id);db.prepare(`INSERT INTO regional_mayors(state_id,territory_key,mayor_name,election_id,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(state_id,territory_key) DO UPDATE SET mayor_name=excluded.mayor_name,election_id=excluded.election_id,updated_at=excluded.updated_at`).run(e.state_id,e.territory_key,winner,e.id,now);});
 tx();res.json({status:'closed',winner,results});
});


// Cities and urban development. All project costs are charged to the region's own treasury.
const CITY_PROJECTS={
 'Житловий квартал':{cost:400,population:800,level:0},
 'Школа':{cost:300,population:0,level:1},
 'Медичний центр':{cost:450,population:0,level:1},
 'Транспортний вузол':{cost:500,population:200,level:1},
 'Парк':{cost:220,population:100,level:1},
 'Комунальна мережа':{cost:350,population:0,level:1}
};
function cityManager(stateId,key,playerId){return canManageRegion(stateId,key,playerId);}
app.get('/api/states/:id/regions/:key/cities',auth,(req,res)=>{
 const key=req.params.key;
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 const cities=db.prepare(`SELECT c.id,c.name,c.population,c.urban_level,c.created_at,p.nickname AS mayor
 FROM cities c LEFT JOIN players p ON p.id=c.mayor_id
 WHERE c.state_id=? AND c.territory_key=? ORDER BY c.population DESC`).all(req.params.id,key);
 const projects=db.prepare(`SELECT p.city_id,p.project_type,p.level,p.created_at FROM city_projects p JOIN cities c ON c.id=p.city_id WHERE c.state_id=? AND c.territory_key=? ORDER BY p.created_at DESC`).all(req.params.id,key);
 res.json({cities,projects,catalog:CITY_PROJECTS});
});
app.post('/api/states/:id/regions/:key/cities',auth,(req,res)=>{
 const key=req.params.key,{name,population}=req.body||{};
 if(!cityManager(req.params.id,key,req.player.id))return fail(res,403,'Місто може заснувати керівник регіону або власник держави.');
 if(typeof name!=='string'||name.trim().length<2||name.trim().length>60)return fail(res,400,'Назва міста має містити 2–60 символів.');
 const pop=population===undefined?10000:population;
 if(!Number.isInteger(pop)||pop<1000||pop>5000000)return fail(res,400,'Початкове населення має бути від 1 000 до 5 000 000.');
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 try{db.prepare('INSERT INTO cities(id,state_id,territory_key,name,population,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(id,req.params.id,key,name.trim(),pop,req.player.id,now,now);}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Місто з такою назвою вже існує в цьому регіоні.');throw e;}
 res.status(201).json({id,name:name.trim(),population:pop,urbanLevel:1});
});
app.post('/api/cities/:id/mayor',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityManager(city.state_id,city.territory_key,req.player.id))return fail(res,403,'Призначати міського голову може керівник регіону або власник держави.');
 const {nickname}=req.body||{};
 if(typeof nickname!=='string'||nickname.trim().length<3||nickname.trim().length>24)return fail(res,400,'Вкажи нікнейм зареєстрованого гравця.');
 const player=db.prepare('SELECT id FROM players WHERE nickname=? COLLATE NOCASE').get(nickname.trim());
 if(!player)return fail(res,404,'Гравця з таким нікнеймом не знайдено.');
 db.prepare('UPDATE cities SET mayor_id=?,updated_at=? WHERE id=?').run(player.id,new Date().toISOString(),city.id);
 res.json({ok:true,mayor:nickname.trim()});
});
app.post('/api/cities/:id/projects',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityManager(city.state_id,city.territory_key,req.player.id))return fail(res,403,'Розвивати місто може керівник регіону або власник держави.');
 const {projectType}=req.body||{},spec=CITY_PROJECTS[projectType];if(!spec)return fail(res,400,'Невідомий міський проєкт.');
 const economy=ensureRegionalEconomy(city.state_id,city.territory_key);
 if(economy.treasury<spec.cost)return fail(res,409,'У бюджеті регіону недостатньо коштів.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{
  db.prepare('UPDATE regional_economies SET treasury=treasury-?,infrastructure_level=infrastructure_level+?,updated_at=? WHERE state_id=? AND territory_key=?').run(spec.cost,spec.level,now,city.state_id,city.territory_key);
  db.prepare('UPDATE cities SET population=population+?,urban_level=urban_level+1,updated_at=? WHERE id=?').run(spec.population,now,city.id);
  db.prepare('INSERT INTO city_projects(id,city_id,project_type,level,created_by,created_at) VALUES(?,?,?,1,?,?)').run(id,city.id,projectType,req.player.id,now);
 });
 tx();res.status(201).json({ok:true,cost:spec.cost,population:city.population+spec.population,urbanLevel:city.urban_level+1});
});
app.post('/api/cities/:id/growth',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityManager(city.state_id,city.territory_key,req.player.id))return fail(res,403,'Розрахувати приріст може керівник регіону або власник держави.');
 const growth=Math.max(1,Math.floor(city.population*0.01));
 db.prepare('UPDATE cities SET population=population+?,updated_at=? WHERE id=?').run(growth,new Date().toISOString(),city.id);
 res.json({ok:true,growth,population:city.population+growth});
});


// v1.8.0: elected city leadership, municipal council and independent city budgets.
function cityCanManage(city,playerId){
 if(city.mayor_id===playerId)return true;
 return canManageRegion(city.state_id,city.territory_key,playerId);
}
function ensureCityEconomy(cityId){
 db.prepare('INSERT OR IGNORE INTO city_economies(city_id,updated_at) VALUES(?,?)').run(cityId,new Date().toISOString());
 return db.prepare('SELECT * FROM city_economies WHERE city_id=?').get(cityId);
}
app.get('/api/cities/:id/governance',auth,(req,res)=>{
 const city=db.prepare('SELECT c.*,p.nickname AS mayor FROM cities c LEFT JOIN players p ON p.id=c.mayor_id WHERE c.id=?').get(req.params.id);
 if(!city)return fail(res,404,'Місто не знайдено.');
 const economy=ensureCityEconomy(city.id);
 const council=db.prepare('SELECT player_id,nickname,votes,seats FROM city_council_seats WHERE city_id=? ORDER BY seats DESC,votes DESC').all(city.id);
 const elections=db.prepare(`SELECT e.id,e.election_type,e.status,e.winner_nickname,e.created_at,
 (SELECT COUNT(*) FROM city_votes v WHERE v.election_id=e.id) turnout
 FROM city_elections e WHERE e.city_id=? ORDER BY e.created_at DESC LIMIT 20`).all(city.id);
 const proposals=db.prepare(`SELECT p.id,p.title,p.description,p.status,
 (SELECT COUNT(*) FROM city_proposal_votes v WHERE v.proposal_id=p.id AND v.decision='yes') yes,
 (SELECT COUNT(*) FROM city_proposal_votes v WHERE v.proposal_id=p.id AND v.decision='no') no
 FROM city_proposals p WHERE p.city_id=? ORDER BY p.created_at DESC LIMIT 20`).all(city.id);
 res.json({city,economy,council,elections,proposals});
});
app.post('/api/cities/:id/elections',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Міські вибори оголошує мер або керівник регіону.');
 const {electionType,candidates}=req.body||{};
 if(!['mayor','council'].includes(electionType))return fail(res,400,'Тип виборів має бути mayor або council.');
 if(!Array.isArray(candidates)||candidates.length<2||candidates.length>30)return fail(res,400,'Потрібно 2–30 кандидатів.');
 const clean=[...new Set(candidates.map(x=>typeof x==='string'?x.trim():'').filter(x=>x.length>=3&&x.length<=24))];
 if(clean.length!==candidates.length)return fail(res,400,'Вкажи нікнейми зареєстрованих гравців без повторів.');
 const players=clean.map(n=>db.prepare('SELECT id,nickname FROM players WHERE nickname=? COLLATE NOCASE').get(n));
 if(players.some(x=>!x))return fail(res,404,'Один або кілька кандидатів не мають зареєстрованих акаунтів.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 const tx=db.transaction(()=>{
  db.prepare('INSERT INTO city_elections(id,city_id,election_type,created_by,created_at) VALUES(?,?,?,?,?)').run(id,city.id,electionType,req.player.id,now);
  const put=db.prepare('INSERT INTO city_candidates(election_id,player_id,nickname) VALUES(?,?,?)');
  players.forEach(p=>put.run(id,p.id,p.nickname));
 });
 tx();res.status(201).json({id,status:'open',electionType});
});
app.get('/api/city-elections/:id',auth,(req,res)=>{
 const election=db.prepare('SELECT * FROM city_elections WHERE id=?').get(req.params.id);
 if(!election)return fail(res,404,'Вибори не знайдено.');
 const candidates=db.prepare(`SELECT c.player_id,c.nickname,COUNT(v.voter_id) votes FROM city_candidates c LEFT JOIN city_votes v ON v.election_id=c.election_id AND v.candidate_id=c.player_id WHERE c.election_id=? GROUP BY c.player_id ORDER BY votes DESC,c.nickname`).all(election.id);
 res.json({election,candidates});
});
app.post('/api/city-elections/:id/vote',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM city_elections WHERE id=?').get(req.params.id);
 if(!e)return fail(res,404,'Вибори не знайдено.');
 if(e.status!=='open')return fail(res,409,'Голосування завершено.');
 const {candidateId}=req.body||{};
 if(!db.prepare('SELECT 1 FROM city_candidates WHERE election_id=? AND player_id=?').get(e.id,candidateId))return fail(res,400,'Кандидата немає у бюлетені.');
 try{db.prepare('INSERT INTO city_votes(election_id,voter_id,candidate_id,created_at) VALUES(?,?,?,?)').run(e.id,req.player.id,candidateId,new Date().toISOString());}
 catch(err){if(String(err).includes('UNIQUE'))return fail(res,409,'Ти вже голосував на цих виборах.');throw err;}
 res.status(201).json({ok:true});
});
app.post('/api/city-elections/:id/close',auth,(req,res)=>{
 const e=db.prepare('SELECT * FROM city_elections WHERE id=?').get(req.params.id);
 if(!e)return fail(res,404,'Вибори не знайдено.');
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(e.city_id);
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Підтвердити результат може мер або керівник регіону.');
 if(e.status!=='open')return fail(res,409,'Вибори вже завершено.');
 const results=db.prepare(`SELECT c.player_id,c.nickname,COUNT(v.voter_id) votes FROM city_candidates c LEFT JOIN city_votes v ON v.election_id=c.election_id AND v.candidate_id=c.player_id WHERE c.election_id=? GROUP BY c.player_id ORDER BY votes DESC,c.nickname`).all(e.id);
 if(!results[0]?.votes)return fail(res,409,'Немає голосів.');
 const now=new Date().toISOString(),winner=results[0];
 const tx=db.transaction(()=>{
  db.prepare("UPDATE city_elections SET status='closed',winner_id=?,winner_nickname=? WHERE id=?").run(winner.player_id,winner.nickname,e.id);
  if(e.election_type==='mayor')db.prepare('UPDATE cities SET mayor_id=?,updated_at=? WHERE id=?').run(winner.player_id,now,city.id);
  else{
   db.prepare('DELETE FROM city_council_seats WHERE city_id=?').run(city.id);
   const total=15,sum=results.reduce((n,x)=>n+x.votes,0);
   let assigned=0;const shares=results.map(x=>{const exact=x.votes*total/sum;const seats=Math.floor(exact);assigned+=seats;return {...x,seats,rem:exact-seats};});
   shares.sort((x,y)=>y.rem-x.rem);for(let i=0;i<total-assigned;i++)shares[i].seats++;
   const put=db.prepare('INSERT INTO city_council_seats(city_id,player_id,nickname,votes,seats) VALUES(?,?,?,?,?)');
   shares.forEach(x=>{if(x.seats)put.run(city.id,x.player_id,x.nickname,x.votes,x.seats);});
  }
 });
 tx();res.json({status:'closed',winner:winner.nickname,results});
});
app.post('/api/cities/:id/municipal-tax',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Місцевий податок встановлює мер або керівник регіону.');
 const {taxRate}=req.body||{};if(!Number.isInteger(taxRate)||taxRate<0||taxRate>20)return fail(res,400,'Міський податок має бути від 0 до 20%.');
 ensureCityEconomy(city.id);db.prepare('UPDATE city_economies SET tax_rate=?,updated_at=? WHERE city_id=?').run(taxRate,new Date().toISOString(),city.id);
 res.json({ok:true,taxRate});
});
app.post('/api/cities/:id/municipal-income',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Міський дохід збирає мер або керівник регіону.');
 const e=ensureCityEconomy(city.id);
 const now=Date.now();if(e.last_income_at&&now-e.last_income_at<6*60*60*1000)return fail(res,409,'Наступний міський дохід доступний через шість годин.');
 const income=Math.floor((60+city.urban_level*20+Math.floor(city.population/1000))*(1+e.tax_rate/100));
 db.prepare('UPDATE city_economies SET treasury=treasury+?,turn_number=turn_number+1,last_income_at=?,updated_at=? WHERE city_id=?').run(income,now,new Date().toISOString(),city.id);
 res.json({income,treasury:e.treasury+income,turn:e.turn_number+1});
});
app.post('/api/cities/:id/municipal-projects',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Міський бюджетом керує мер або керівник регіону.');
 const {projectType}=req.body||{};
 const catalog={'Міське освітлення':180,'Прибирання вулиць':120,'Дитячий майданчик':160,'Бібліотека':240,'Пішохідна зона':200};
 const cost=catalog[projectType];if(!cost)return fail(res,400,'Невідомий муніципальний проєкт.');
 const e=ensureCityEconomy(city.id);if(e.treasury<cost)return fail(res,409,'У міському бюджеті недостатньо коштів.');
 const now=new Date().toISOString(),id=randomBytes(12).toString('hex');
 const tx=db.transaction(()=>{
  db.prepare('UPDATE city_economies SET treasury=treasury-?,updated_at=? WHERE city_id=?').run(cost,now,city.id);
  db.prepare('INSERT INTO city_projects(id,city_id,project_type,level,created_by,created_at) VALUES(?,?,?,1,?,?)').run(id,city.id,projectType,req.player.id,now);
 });
 tx();res.status(201).json({ok:true,cost,treasury:e.treasury-cost});
});
app.post('/api/cities/:id/proposals',auth,(req,res)=>{
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(req.params.id);if(!city)return fail(res,404,'Місто не знайдено.');
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Місцеву ініціативу може подати мер або керівник регіону.');
 const {title,description}=req.body||{};
 if(typeof title!=='string'||title.trim().length<3||title.length>80||typeof description!=='string'||description.trim().length<5||description.length>500)return fail(res,400,'Перевір назву та опис пропозиції.');
 const id=randomBytes(12).toString('hex');
 db.prepare('INSERT INTO city_proposals(id,city_id,title,description,created_by,created_at) VALUES(?,?,?,?,?,?)').run(id,city.id,title.trim(),description.trim(),req.player.id,new Date().toISOString());
 res.status(201).json({id,status:'proposed'});
});
app.post('/api/city-proposals/:id/vote',auth,(req,res)=>{
 const p=db.prepare('SELECT * FROM city_proposals WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Пропозицію не знайдено.');
 if(p.status!=='proposed')return fail(res,409,'Голосування завершено.');
 const {decision}=req.body||{};if(!['yes','no'].includes(decision))return fail(res,400,'Вкажи yes або no.');
 try{db.prepare('INSERT INTO city_proposal_votes(proposal_id,voter_id,decision,created_at) VALUES(?,?,?,?)').run(p.id,req.player.id,decision,new Date().toISOString());}
 catch(e){if(String(e).includes('UNIQUE'))return fail(res,409,'Ти вже голосував за цю пропозицію.');throw e;}
 const yes=db.prepare("SELECT COUNT(*) n FROM city_proposal_votes WHERE proposal_id=? AND decision='yes'").get(p.id).n;
 const no=db.prepare("SELECT COUNT(*) n FROM city_proposal_votes WHERE proposal_id=? AND decision='no'").get(p.id).n;
 res.status(201).json({yes,no});
});
app.post('/api/city-proposals/:id/finalize',auth,(req,res)=>{
 const p=db.prepare('SELECT * FROM city_proposals WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Пропозицію не знайдено.');
 const city=db.prepare('SELECT * FROM cities WHERE id=?').get(p.city_id);
 if(!cityCanManage(city,req.player.id))return fail(res,403,'Результат підтверджує мер або керівник регіону.');
 if(p.status!=='proposed')return fail(res,409,'Пропозицію вже завершено.');
 const yes=db.prepare("SELECT COUNT(*) n FROM city_proposal_votes WHERE proposal_id=? AND decision='yes'").get(p.id).n;
 const no=db.prepare("SELECT COUNT(*) n FROM city_proposal_votes WHERE proposal_id=? AND decision='no'").get(p.id).n;
 if(yes===no)return fail(res,409,'Немає більшості голосів.');
 const status=yes>no?'adopted':'rejected';db.prepare('UPDATE city_proposals SET status=? WHERE id=?').run(status,p.id);
 res.json({status,yes,no});
});


// Daily SQLite snapshots. On Render, BACKUP_DIR must point to a mounted persistent disk.
const backupDir=process.env.BACKUP_DIR || new URL('../data/backups/',import.meta.url).pathname;
async function cwCreateDatabaseBackup(){
 try{
  fs.mkdirSync(backupDir,{recursive:true});
  const stamp=new Date().toISOString().replace(/[:.]/g,'-');
  await db.backup(`${backupDir}/chemis-world-${stamp}.sqlite`);
  const files=fs.readdirSync(backupDir).filter(x=>x.endsWith('.sqlite')).sort();
  for(const old of files.slice(0,Math.max(0,files.length-7)))fs.unlinkSync(`${backupDir}/${old}`);
  console.log('Chemis World database backup created.');
 }catch(error){console.error('Database backup failed:',error.message);}
}
setTimeout(cwCreateDatabaseBackup,5*60*1000).unref?.();
setInterval(cwCreateDatabaseBackup,24*60*60*1000).unref?.();

// Chemis World 4.0.0: demographic simulation. One in-game day is 24 real hours.
function cwEnsureDemographics(stateId,territoryKey){
 const stamp=new Date().toISOString();
 db.prepare('INSERT OR IGNORE INTO regional_demographics(state_id,territory_key,last_simulated_at,updated_at) VALUES(?,?,?,?)').run(stateId,territoryKey,Date.now(),stamp);
 let row=db.prepare('SELECT * FROM regional_demographics WHERE state_id=? AND territory_key=?').get(stateId,territoryKey);
 const day=24*60*60*1000,now=Date.now(),elapsed=Math.floor((now-row.last_simulated_at)/day);
 if(elapsed>0){
  const buildings=db.prepare('SELECT building_type,COUNT(*) n FROM regional_buildings WHERE state_id=? AND territory_key=? GROUP BY building_type').all(stateId,territoryKey);
  const counts=Object.fromEntries(buildings.map(x=>[x.building_type,x.n]));
  const health=Math.max(0,Math.min(100,row.health_index+(counts['Лікарня']?1:0)));
  const education=Math.max(0,Math.min(100,row.education_index+(counts['Школа']?1:0)));
  const wellbeing=Math.max(0,Math.min(100,row.wellbeing_index+(counts['Культурний центр']?1:0)+(counts['Водопостачання']?1:0)));
  const employment=Math.max(0,Math.min(100,row.employment_index+(counts['Дорога']?1:0)));
  const growth=Math.max(-20,Math.min(20,row.growth_permille+Math.round((health+education+wellbeing+employment-200)/100)));
  const dailyRate=growth/1000;
  const population=Math.max(0,Math.round(row.population*Math.pow(1+dailyRate,Math.min(elapsed,30))));
  db.prepare('UPDATE regional_demographics SET population=?,health_index=?,education_index=?,employment_index=?,wellbeing_index=?,growth_permille=?,last_simulated_at=?,updated_at=? WHERE state_id=? AND territory_key=?').run(population,health,education,employment,wellbeing,growth,row.last_simulated_at+elapsed*day,stamp,stateId,territoryKey);
  row=db.prepare('SELECT * FROM regional_demographics WHERE state_id=? AND territory_key=?').get(stateId,territoryKey);
 }
 return row;
}
app.get('/api/states/:id/regions/:key/demographics',auth,(req,res)=>{
 const key=req.params.key;
 if(!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(req.params.id,key))return fail(res,404,'Територію не знайдено.');
 const d=cwEnsureDemographics(req.params.id,key);
 const buildings=db.prepare('SELECT building_type,COUNT(*) count FROM regional_buildings WHERE state_id=? AND territory_key=? GROUP BY building_type').all(req.params.id,key);
 res.json({demographics:d,buildings,simulation:'24h-per-game-day'});
});
app.post('/api/states/:id/regions/:key/demographics/policy',auth,(req,res)=>{
 const key=req.params.key;if(!canManageRegion(req.params.id,key,req.player.id))return fail(res,403,'Змінювати демографічну політику може керівник регіону або власник держави.');
 const d=cwEnsureDemographics(req.params.id,key);const {growthPermille,healthIndex,educationIndex,employmentIndex,wellbeingIndex}=req.body||{};
 const values=[growthPermille,healthIndex,educationIndex,employmentIndex,wellbeingIndex];
 if(!Number.isInteger(growthPermille)||growthPermille < -20||growthPermille>20||![healthIndex,educationIndex,employmentIndex,wellbeingIndex].every(x=>Number.isInteger(x)&&x>=0&&x<=100))return fail(res,400,'Показники мають бути цілими числами в допустимих межах.');
 const stamp=new Date().toISOString();db.prepare('UPDATE regional_demographics SET growth_permille=?,health_index=?,education_index=?,employment_index=?,wellbeing_index=?,updated_at=? WHERE state_id=? AND territory_key=?').run(...values,stamp,req.params.id,key);
 cwEvent(req.player.id,'demography','Оновлено демографічну політику',key);
 res.json({ok:true,demographics:db.prepare('SELECT * FROM regional_demographics WHERE state_id=? AND territory_key=?').get(req.params.id,key)});
});

// Chemis World 4.0.0: demographics, social, diplomacy, treasury, event and achievement APIs.
function cwNotify(playerId,kind,title,body='',data={}){
 db.prepare('INSERT INTO player_notifications(id,player_id,kind,title,body,data_json,created_at) VALUES(?,?,?,?,?,?,?)')
 .run(randomBytes(12).toString('hex'),playerId,kind,title,body,JSON.stringify(data),new Date().toISOString());
}
function cwEvent(actorId,scope,title,body=''){
 db.prepare('INSERT INTO world_events(id,actor_id,scope,title,body,created_at) VALUES(?,?,?,?,?,?)')
 .run(randomBytes(12).toString('hex'),actorId,scope,title,body,new Date().toISOString());
}
function cwTreasury(stateId){
 let row=db.prepare('SELECT * FROM state_treasuries WHERE state_id=?').get(stateId);
 if(!row){db.prepare('INSERT OR IGNORE INTO state_treasuries(state_id,balance,tax_rate,last_income_at,updated_at) VALUES(?,100000,5,0,?)').run(stateId,new Date().toISOString());row=db.prepare('SELECT * FROM state_treasuries WHERE state_id=?').get(stateId);}
 return row;
}
function cwOwnsState(stateId,playerId){return !!db.prepare('SELECT 1 FROM game_states WHERE id=? AND owner_id=?').get(stateId,playerId);}
app.get('/api/v3/dashboard',auth,(req,res)=>{
 const playerCount=db.prepare('SELECT COUNT(*) n FROM players').get().n;
 const stateCount=db.prepare('SELECT COUNT(*) n FROM game_states').get().n;
 const regionCount=db.prepare('SELECT COUNT(*) n FROM (SELECT region_key FROM regional_game_profiles UNION SELECT territory_key AS region_key FROM state_territories UNION SELECT region_key FROM player_region_wallets)').get().n;
 const articleCount=db.prepare('SELECT (SELECT COUNT(*) FROM game_articles)+(SELECT COUNT(*) FROM guest_articles) n').get().n;
 const unread=db.prepare('SELECT COUNT(*) n FROM player_notifications WHERE player_id=? AND is_read=0').get(req.player.id).n;
 const events=db.prepare(`SELECT e.id,e.scope,e.title,e.body,e.created_at,p.nickname AS actor FROM world_events e LEFT JOIN players p ON p.id=e.actor_id ORDER BY e.created_at DESC LIMIT 20`).all();
 const friends=db.prepare("SELECT COUNT(*) n FROM player_friends WHERE status='accepted' AND (requester_id=? OR addressee_id=?)").get(req.player.id,req.player.id).n;
 res.json({stats:{players:playerCount,states:stateCount,regions:regionCount,articles:articleCount},unreadNotifications:unread,friends,events});
});
app.get('/api/friends',auth,(req,res)=>{
 const rows=db.prepare(`SELECT f.id,f.status,f.created_at,f.requester_id,f.addressee_id,
 CASE WHEN f.requester_id=? THEN p2.nickname ELSE p1.nickname END AS nickname,
 CASE WHEN f.requester_id=? THEN 'outgoing' ELSE 'incoming' END AS direction
 FROM player_friends f JOIN players p1 ON p1.id=f.requester_id JOIN players p2 ON p2.id=f.addressee_id
 WHERE f.requester_id=? OR f.addressee_id=? ORDER BY f.created_at DESC LIMIT 100`).all(req.player.id,req.player.id,req.player.id,req.player.id);
 res.json({friends:rows});
});
app.post('/api/friends/request',auth,(req,res)=>{
 const nickname=String(req.body?.nickname||'').trim();if(nickname.length<3||nickname.length>24)return fail(res,400,'Вкажи нікнейм гравця.');
 const target=db.prepare('SELECT id,nickname FROM players WHERE nickname=? COLLATE NOCASE').get(nickname);
 if(!target)return fail(res,404,'Гравця не знайдено.');if(target.id===req.player.id)return fail(res,400,'Не можна додати самого себе.');
 const prior=db.prepare('SELECT * FROM player_friends WHERE (requester_id=? AND addressee_id=?) OR (requester_id=? AND addressee_id=?)').get(req.player.id,target.id,target.id,req.player.id);
 if(prior){if(prior.status==='accepted')return fail(res,409,'Ви вже друзі.');return fail(res,409,'Запит між вами вже існує.');}
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 db.prepare('INSERT INTO player_friends(id,requester_id,addressee_id,status,created_at,updated_at) VALUES(?,?,?,\'pending\',?,?)').run(id,req.player.id,target.id,now,now);
 cwNotify(target.id,'friend_request','Запит у друзі',req.player.nickname+' хоче додати тебе в друзі.',{friendRequestId:id});
 res.status(201).json({id,status:'pending',nickname:target.nickname});
});
app.post('/api/friends/:id/respond',auth,(req,res)=>{
 const row=db.prepare('SELECT * FROM player_friends WHERE id=?').get(req.params.id);if(!row)return fail(res,404,'Запит не знайдено.');
 if(row.addressee_id!==req.player.id)return fail(res,403,'Цей запит адресовано іншому гравцю.');
 if(row.status!=='pending')return fail(res,409,'Запит уже оброблено.');
 const accept=req.body?.accept===true;db.prepare('UPDATE player_friends SET status=?,updated_at=? WHERE id=?').run(accept?'accepted':'rejected',new Date().toISOString(),row.id);
 cwNotify(row.requester_id,'friend_response',accept?'Запит прийнято':'Запит відхилено',req.player.nickname+(accept?' прийняв':' відхилив')+' твій запит у друзі.');
 res.json({ok:true,status:accept?'accepted':'rejected'});
});
app.get('/api/notifications',auth,(req,res)=>{
 const rows=db.prepare('SELECT id,kind,title,body,data_json,is_read,created_at FROM player_notifications WHERE player_id=? ORDER BY created_at DESC LIMIT 100').all(req.player.id).map(x=>({...x,data:JSON.parse(x.data_json||'{}')}));
 res.json({notifications:rows,unread:rows.filter(x=>!x.is_read).length});
});
app.post('/api/notifications/read',auth,(req,res)=>{
 const ids=Array.isArray(req.body?.ids)?req.body.ids.filter(x=>typeof x==='string').slice(0,100):[];
 if(req.body?.all===true)db.prepare('UPDATE player_notifications SET is_read=1 WHERE player_id=?').run(req.player.id);
 else if(ids.length){const q=ids.map(()=>'?').join(',');db.prepare(`UPDATE player_notifications SET is_read=1 WHERE player_id=? AND id IN (${q})`).run(req.player.id,...ids);}
 res.json({ok:true});
});
app.get('/api/diplomacy',auth,(req,res)=>{
 const states=db.prepare('SELECT s.id,s.name,s.capital,p.nickname owner FROM game_states s JOIN players p ON p.id=s.owner_id ORDER BY s.name').all();
 const treaties=db.prepare(`SELECT t.*,a.name proposer_name,b.name target_name FROM diplomacy_treaties t JOIN game_states a ON a.id=t.proposer_state_id JOIN game_states b ON b.id=t.target_state_id WHERE t.proposer_state_id IN (SELECT id FROM game_states WHERE owner_id=?) OR t.target_state_id IN (SELECT id FROM game_states WHERE owner_id=?) ORDER BY t.created_at DESC LIMIT 100`).all(req.player.id,req.player.id);
 res.json({states,treaties});
});
app.post('/api/diplomacy/propose',auth,(req,res)=>{
 const {stateId,targetStateId,treatyType='friendship',title='',terms=''}=req.body||{};
 if(!cwOwnsState(stateId,req.player.id))return fail(res,403,'Пропонувати угоди може лише власник держави.');
 const target=db.prepare('SELECT id,owner_id,name FROM game_states WHERE id=?').get(targetStateId);if(!target)return fail(res,404,'Державу-партнера не знайдено.');
 if(stateId===targetStateId)return fail(res,400,'Не можна укласти угоду із собою.');
 const types=['friendship','non_aggression','trade','alliance','research'];if(!types.includes(treatyType))return fail(res,400,'Невідомий тип договору.');
 const cleanTitle=String(title||'').trim().slice(0,80)||({friendship:'Договір про дружбу',non_aggression:'Пакт про ненапад',trade:'Торгова угода',alliance:'Союзний договір',research:'Наукове співробітництво'}[treatyType]);
 const cleanTerms=String(terms||'').trim().slice(0,1000);const id=randomBytes(12).toString('hex'),now=new Date().toISOString();
 db.prepare('INSERT INTO diplomacy_treaties(id,proposer_state_id,target_state_id,treaty_type,title,terms,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id,stateId,targetStateId,treatyType,cleanTitle,cleanTerms,req.player.id,now);
 cwNotify(target.owner_id,'diplomacy','Нова дипломатична пропозиція',req.player.nickname+' надіслав державі «'+target.name+'» договір: '+cleanTitle,{treatyId:id});
 cwEvent(req.player.id,'diplomacy','Нова дипломатична пропозиція',cleanTitle);
 res.status(201).json({id,status:'pending'});
});
app.post('/api/diplomacy/:id/respond',auth,(req,res)=>{
 const t=db.prepare('SELECT * FROM diplomacy_treaties WHERE id=?').get(req.params.id);if(!t)return fail(res,404,'Договір не знайдено.');
 if(!cwOwnsState(t.target_state_id,req.player.id))return fail(res,403,'Рішення може ухвалити лише власник держави-адресата.');
 if(t.status!=='pending')return fail(res,409,'Пропозицію вже розглянуто.');
 const accept=req.body?.accept===true,now=new Date().toISOString();
 db.prepare('UPDATE diplomacy_treaties SET status=?,responded_by=?,responded_at=? WHERE id=?').run(accept?'accepted':'rejected',req.player.id,now,t.id);
 const proposer=db.prepare('SELECT owner_id,name FROM game_states WHERE id=?').get(t.proposer_state_id);
 cwNotify(proposer.owner_id,'diplomacy_response',accept?'Договір прийнято':'Договір відхилено','Держава-партнер '+(accept?'прийняла':'відхилила')+' пропозицію «'+t.title+'».',{treatyId:t.id});
 cwEvent(req.player.id,'diplomacy',accept?'Укладено міжнародний договір':'Відхилено міжнародну пропозицію',t.title);
 res.json({ok:true,status:accept?'accepted':'rejected'});
});
app.get('/api/states/:id/government',auth,(req,res)=>{const state=db.prepare('SELECT id,name,owner_id FROM game_states WHERE id=?').get(req.params.id);if(!state)return fail(res,404,'Державу не знайдено.');db.prepare("INSERT OR IGNORE INTO state_government_settings(state_id,government_type,updated_at) VALUES(?,'democracy',?)").run(state.id,new Date().toISOString());const setting=db.prepare('SELECT government_type FROM state_government_settings WHERE state_id=?').get(state.id);const knights=db.prepare('SELECT k.player_id,p.nickname,k.appointed_at FROM state_knights k JOIN players p ON p.id=k.player_id WHERE k.state_id=? ORDER BY k.appointed_at').all(state.id);res.json({state,governmentType:setting.government_type,knights,canManage:state.owner_id===req.player.id});});
app.post('/api/states/:id/government',auth,(req,res)=>{if(!cwOwnsState(req.params.id,req.player.id))return fail(res,403,'Форму правління може змінити лише власник держави.');const type=req.body?.governmentType;if(!['democracy','monarchy'].includes(type))return fail(res,400,'Оберіть демократію або монархію.');const now=new Date().toISOString();db.prepare('INSERT INTO state_government_settings(state_id,government_type,updated_at) VALUES(?,?,?) ON CONFLICT(state_id) DO UPDATE SET government_type=excluded.government_type,updated_at=excluded.updated_at').run(req.params.id,type,now);res.json({ok:true,governmentType:type});});
app.post('/api/states/:id/knights',auth,(req,res)=>{if(!cwOwnsState(req.params.id,req.player.id))return fail(res,403,'Призначати лицарів може лише власник держави.');const gov=db.prepare('SELECT government_type FROM state_government_settings WHERE state_id=?').get(req.params.id);if(gov?.government_type!=='monarchy')return fail(res,409,'Лицарі доступні лише за монархії.');const nickname=String(req.body?.nickname||'').trim();const target=db.prepare('SELECT id,nickname FROM players WHERE nickname=? COLLATE NOCASE').get(nickname);if(!target)return fail(res,404,'Гравця не знайдено.');try{const tx=db.transaction(()=>{const count=db.prepare('SELECT COUNT(*) n FROM state_knights WHERE state_id=?').get(req.params.id).n;if(count>=10)throw new Error('KNIGHT_LIMIT');db.prepare('INSERT INTO state_knights(state_id,player_id,appointed_by,appointed_at) VALUES(?,?,?,?)').run(req.params.id,target.id,req.player.id,new Date().toISOString());});tx();}catch(e){if(e.message==='KNIGHT_LIMIT')return fail(res,409,'У державі може бути не більше 10 лицарів.');return fail(res,409,'Гравець уже є лицарем цієї держави.');}cwNotify(target.id,'knight_appointed','Тебе призначено лицарем','Ти отримав +20% до шкоди в ігрових поєдинках.');res.status(201).json({ok:true,nickname:target.nickname,damageBonus:20});});
app.delete('/api/states/:id/knights/:playerId',auth,(req,res)=>{if(!cwOwnsState(req.params.id,req.player.id))return fail(res,403,'Зняти лицаря може лише власник держави.');const changed=db.prepare('DELETE FROM state_knights WHERE state_id=? AND player_id=?').run(req.params.id,req.params.playerId);if(!changed.changes)return fail(res,404,'Лицаря не знайдено.');res.json({ok:true});});
app.get('/api/states/:id/bank',auth,(req,res)=>{const state=db.prepare('SELECT id,name,owner_id FROM game_states WHERE id=?').get(req.params.id);if(!state)return fail(res,404,'Державу не знайдено.');const rows=db.prepare(`SELECT t.id,t.player_id,p.nickname,t.region_key,t.treasury_amount,t.gold_amount,t.created_at FROM state_bank_transfers t JOIN players p ON p.id=t.player_id WHERE t.state_id=? ORDER BY t.created_at DESC LIMIT 30`).all(state.id);res.json({state,treasury:cwTreasury(state.id),rate:100,limitGold24h:10,transfers:rows,canManage:state.owner_id===req.player.id});});
app.post('/api/states/:id/bank/transfer',auth,(req,res)=>{if(!cwOwnsState(req.params.id,req.player.id))return fail(res,403,'Виплати з державного банку може робити лише власник держави.');const nickname=String(req.body?.nickname||'').trim(),regionKey=String(req.body?.regionKey||'').slice(0,120),regionName=String(req.body?.regionName||regionKey).slice(0,100),gold=Number(req.body?.gold);if(!regionKey||!Number.isInteger(gold)||gold<1||gold>10)return fail(res,400,'Вкажи регіон і суму від 1 до 10 золота.');const target=db.prepare('SELECT id,nickname FROM players WHERE nickname=? COLLATE NOCASE').get(nickname);if(!target)return fail(res,404,'Гравця не знайдено.');const now=Date.now(),since=new Date(now-24*60*60*1000).toISOString();const cost=gold*100,stamp=new Date(now).toISOString(),id=randomBytes(12).toString('hex');activeWallet(target.id,regionKey,regionName);cwTreasury(req.params.id);try{const tx=db.transaction(()=>{const paid=db.prepare('SELECT COALESCE(SUM(gold_amount),0) n FROM state_bank_transfers WHERE state_id=? AND player_id=? AND created_at>=?').get(req.params.id,target.id,since).n;if(paid+gold>10)throw new Error('BANK_LIMIT');const debit=db.prepare('UPDATE state_treasuries SET balance=balance-?,updated_at=? WHERE state_id=? AND balance>=?').run(cost,stamp,req.params.id,cost);if(debit.changes!==1)throw new Error('BANK_FUNDS');db.prepare('UPDATE player_region_wallets SET gold=gold+? WHERE player_id=? AND region_key=?').run(gold,target.id,regionKey);db.prepare('INSERT INTO state_bank_transfers(id,state_id,player_id,region_key,treasury_amount,gold_amount,created_at) VALUES(?,?,?,?,?,?,?)').run(id,req.params.id,target.id,regionKey,cost,gold,stamp);db.prepare("INSERT INTO state_ledger(id,state_id,player_id,entry_type,amount,description,created_at) VALUES(?,?,?,'expense',?,?,?)").run(randomBytes(12).toString('hex'),req.params.id,req.player.id,-cost,'Банківська виплата гравцю '+target.nickname,stamp);});tx();}catch(e){if(e.message==='BANK_FUNDS')return fail(res,409,'У скарбниці недостатньо коштів.');if(e.message==='BANK_LIMIT')return fail(res,409,'Ліміт виплат цьому гравцю — 10 золота за 24 години.');throw e;}cwNotify(target.id,'state_bank_payout','Виплата з державного банку','Отримано '+gold+' золота від держави.',{stateId:req.params.id});res.json({ok:true,gold,treasurySpent:cost,rate:100,wallet:ensureRegionWallet(target.id,regionKey,regionName)});});
app.get('/api/states/:id/treasury',auth,(req,res)=>{
 const state=stateView(req.params.id);if(!state)return fail(res,404,'Державу не знайдено.');
 const treasury=cwTreasury(state.id);const ledger=db.prepare('SELECT l.id,l.entry_type,l.amount,l.description,l.created_at,p.nickname actor FROM state_ledger l LEFT JOIN players p ON p.id=l.player_id WHERE l.state_id=? ORDER BY l.created_at DESC LIMIT 30').all(state.id);
 res.json({state:{id:state.id,name:state.name,owner:state.owner_nickname},treasury,ledger,canManage:state.owner_id===req.player.id});
});
app.post('/api/states/:id/treasury/tax',auth,(req,res)=>{
 if(!cwOwnsState(req.params.id,req.player.id))return fail(res,403,'Податки може змінювати лише власник держави.');
 const rate=Number(req.body?.taxRate);if(!Number.isInteger(rate)||rate<0||rate>25)return fail(res,400,'Ставка має бути від 0 до 25%.');
 const t=cwTreasury(req.params.id);db.prepare('UPDATE state_treasuries SET tax_rate=?,updated_at=? WHERE state_id=?').run(rate,new Date().toISOString(),req.params.id);
 res.json({ok:true,taxRate:rate,balance:t.balance});
});
app.post('/api/states/:id/treasury/collect',auth,(req,res)=>{
 if(!cwOwnsState(req.params.id,req.player.id))return fail(res,403,'Податки збирає лише власник держави.');
 const t=cwTreasury(req.params.id),now=Date.now();if(t.last_income_at&&now-t.last_income_at<6*60*60*1000)return fail(res,409,'Наступне надходження доступне через шість годин.');
 const regions=db.prepare('SELECT COUNT(*) n FROM state_territories WHERE state_id=?').get(req.params.id).n;
 const income=Math.floor((250+regions*100)*(1+t.tax_rate/100));const stamp=new Date().toISOString();
 const tx=db.transaction(()=>{db.prepare('UPDATE state_treasuries SET balance=balance+?,last_income_at=?,updated_at=? WHERE state_id=?').run(income,now,stamp,req.params.id);db.prepare('INSERT INTO state_ledger(id,state_id,player_id,entry_type,amount,description,created_at) VALUES(?,?,?,\'income\',?,?,?)').run(randomBytes(12).toString('hex'),req.params.id,req.player.id,income,'Податкові надходження за '+regions+' регіонів',stamp);});tx();
 cwEvent(req.player.id,'economy','Державний бюджет отримав надходження', 'Дохід: '+income+' CW₵');res.json({ok:true,income,balance:t.balance+income,nextIncomeAt:now+6*60*60*1000});
});
app.post('/api/states/:id/treasury/project',auth,(req,res)=>{
 if(!cwOwnsState(req.params.id,req.player.id))return fail(res,403,'Державні проєкти затверджує власник держави.');
 const catalog={'Дороги':500,'Школи':700,'Лікарні':800,'Енергетика':1000,'Цифрова інфраструктура':900};const type=String(req.body?.projectType||'');const cost=catalog[type];if(!cost)return fail(res,400,'Невідомий тип державного проєкту.');
 const t=cwTreasury(req.params.id);if(t.balance<cost)return fail(res,409,'У державному бюджеті недостатньо коштів.');
 const now=new Date().toISOString(),id=randomBytes(12).toString('hex');try{const tx=db.transaction(()=>{const debit=db.prepare('UPDATE state_treasuries SET balance=balance-?,updated_at=? WHERE state_id=? AND balance>=?').run(cost,now,req.params.id,cost);if(debit.changes!==1)throw new Error('INSUFFICIENT_STATE_TREASURY');db.prepare('INSERT INTO state_economy_projects(id,state_id,project_type,cost,created_by,created_at) VALUES(?,?,?,?,?,?)').run(id,req.params.id,type,cost,req.player.id,now);db.prepare('INSERT INTO state_ledger(id,state_id,player_id,entry_type,amount,description,created_at) VALUES(?,?,?,\'expense\',?,?,?)').run(randomBytes(12).toString('hex'),req.params.id,req.player.id,-cost,'Державний проєкт: '+type,now);});tx();}catch(error){if(error.message==='INSUFFICIENT_STATE_TREASURY')return fail(res,409,'У державному бюджеті недостатньо коштів.');throw error;}
 cwEvent(req.player.id,'economy','Розпочато державний проєкт',type);res.status(201).json({ok:true,id,cost,balance:t.balance-cost});
});
app.post('/api/trade/offers',auth,(req,res)=>{
 const {fromStateId,toStateId,amount,note=''}=req.body||{};if(!cwOwnsState(fromStateId,req.player.id))return fail(res,403,'Пропонувати торгівлю може лише власник держави.');
 const target=db.prepare('SELECT id,owner_id,name FROM game_states WHERE id=?').get(toStateId);if(!target||fromStateId===toStateId)return fail(res,400,'Перевір державу-партнера.');
 const value=Number(amount);if(!Number.isInteger(value)||value<1||value>10000000)return fail(res,400,'Сума має бути від 1 до 10 000 000 CW₵.');
 const t=cwTreasury(fromStateId);if(t.balance<value)return fail(res,409,'Недостатньо коштів у бюджеті.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();db.prepare('INSERT INTO state_trade_offers(id,from_state_id,to_state_id,amount,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)').run(id,fromStateId,toStateId,value,String(note).slice(0,300),req.player.id,now);
 cwNotify(target.owner_id,'trade','Нова торгова пропозиція','Пропозиція на '+value+' CW₵',{tradeId:id});res.status(201).json({id,status:'pending'});
});
app.get('/api/trade/offers',auth,(req,res)=>{
 const rows=db.prepare(`SELECT o.*,a.name from_state_name,b.name to_state_name FROM state_trade_offers o JOIN game_states a ON a.id=o.from_state_id JOIN game_states b ON b.id=o.to_state_id WHERE o.from_state_id IN (SELECT id FROM game_states WHERE owner_id=?) OR o.to_state_id IN (SELECT id FROM game_states WHERE owner_id=?) ORDER BY o.created_at DESC LIMIT 100`).all(req.player.id,req.player.id);res.json({offers:rows});
});
app.post('/api/trade/offers/:id/respond',auth,(req,res)=>{
 const o=db.prepare('SELECT * FROM state_trade_offers WHERE id=?').get(req.params.id);if(!o)return fail(res,404,'Пропозицію не знайдено.');if(!cwOwnsState(o.to_state_id,req.player.id))return fail(res,403,'Прийняти пропозицію може лише власник держави-отримувача.');if(o.status!=='pending')return fail(res,409,'Пропозицію вже розглянуто.');
 const accept=req.body?.accept===true,now=new Date().toISOString();cwTreasury(o.from_state_id);cwTreasury(o.to_state_id);
 try{const tx=db.transaction(()=>{const changed=db.prepare('UPDATE state_trade_offers SET status=?,responded_by=?,responded_at=? WHERE id=? AND status=\'pending\'').run(accept?'accepted':'rejected',req.player.id,now,o.id);if(changed.changes!==1)throw new Error('TRADE_ALREADY_HANDLED');if(accept){const debit=db.prepare('UPDATE state_treasuries SET balance=balance-?,updated_at=? WHERE state_id=? AND balance>=?').run(o.amount,now,o.from_state_id,o.amount);if(debit.changes!==1)throw new Error('TRADE_INSUFFICIENT_FUNDS');db.prepare('UPDATE state_treasuries SET balance=balance+?,updated_at=? WHERE state_id=?').run(o.amount,now,o.to_state_id);for(const [sid,amt,desc] of [[o.from_state_id,-o.amount,'Торгова угода: переказ'],[o.to_state_id,o.amount,'Торгова угода: надходження']])db.prepare('INSERT INTO state_ledger(id,state_id,player_id,entry_type,amount,description,created_at) VALUES(?,?,?,?,?,?,?)').run(randomBytes(12).toString('hex'),sid,req.player.id,amt<0?'expense':'income',amt,desc,now);}});tx();}catch(error){if(error.message==='TRADE_INSUFFICIENT_FUNDS')return fail(res,409,'У державі-відправнику вже недостатньо коштів.');if(error.message==='TRADE_ALREADY_HANDLED')return fail(res,409,'Пропозицію вже розглянуто.');throw error;}
 const sender=db.prepare('SELECT owner_id FROM game_states WHERE id=?').get(o.from_state_id);cwNotify(sender.owner_id,'trade_response',accept?'Торгову угоду прийнято':'Торгову угоду відхилено','Сума: '+o.amount+' CW₵');cwEvent(req.player.id,'trade',accept?'Виконано торгову угоду':'Відхилено торгову угоду','Сума: '+o.amount+' CW₵');res.json({ok:true,status:accept?'accepted':'rejected'});
});
// 6.0.0 player inventory and sword marketplace APIs.
function ensurePlayerInventory(playerId){db.prepare('INSERT OR IGNORE INTO player_inventory(player_id,updated_at) VALUES(?,?)').run(playerId,new Date().toISOString());return db.prepare('SELECT * FROM player_inventory WHERE player_id=?').get(playerId);}
function activeWallet(playerId,key,name){if(!key)return null;return ensureRegionWallet(playerId,String(key).slice(0,120),String(name||key).slice(0,100));}
app.get('/api/game/inventory',auth,(req,res)=>{
 const inv=ensurePlayerInventory(req.player.id);
 const swords=db.prepare("SELECT COUNT(*) n FROM player_swords WHERE owner_id=? AND status IN ('owned','listed')").get(req.player.id).n;
 const listed=db.prepare("SELECT COUNT(*) n FROM sword_auction_listings WHERE seller_id=? AND status='active'").get(req.player.id).n;
 const walletKey=String(req.query.regionKey||'').slice(0,120),walletName=String(req.query.regionName||walletKey).slice(0,100);
 const wallet=walletKey?activeWallet(req.player.id,walletKey,walletName):null;
 res.json({inventory:{batteringRams:inv.battering_rams,swords,listedSwords:listed},wallet:wallet?{gold:wallet.gold}:null,energy:gameProfile(req.player.id).energy});
});
app.post('/api/game/inventory/ram/buy',auth,(req,res)=>{
 const count=Number(req.body?.count),key=String(req.body?.regionKey||'').slice(0,120),name=String(req.body?.regionName||key).slice(0,100);
 if(!Number.isInteger(count)||count<1||count>100)return fail(res,400,'Кількість таранів має бути від 1 до 100.');if(!key)return fail(res,400,'Спочатку обери регіон.');
 const wallet=activeWallet(req.player.id,key,name),cost=count*2;if(wallet.gold<cost)return fail(res,409,'Недостатньо золота для покупки таранів.');
 const now=new Date().toISOString();const tx=db.transaction(()=>{const debit=db.prepare('UPDATE player_region_wallets SET gold=gold-? WHERE player_id=? AND region_key=? AND gold>=?').run(cost,req.player.id,key,cost);if(debit.changes!==1)throw new Error('NO_GOLD');db.prepare('INSERT INTO player_inventory(player_id,battering_rams,updated_at) VALUES(?,?,?) ON CONFLICT(player_id) DO UPDATE SET battering_rams=battering_rams+excluded.battering_rams,updated_at=excluded.updated_at').run(req.player.id,count,now);});
 try{tx();}catch(e){if(e.message==='NO_GOLD')return fail(res,409,'Недостатньо золота.');throw e;}res.json({ok:true,bought:count,cost,gold:activeWallet(req.player.id,key,name).gold,inventory:ensurePlayerInventory(req.player.id)});
});
app.post('/api/game/swords/create',auth,(req,res)=>{
 const key=String(req.body?.regionKey||'').slice(0,120),name=String(req.body?.regionName||key).slice(0,100);if(!key)return fail(res,400,'Спочатку обери регіон.');const wallet=activeWallet(req.player.id,key,name);if(wallet.gold<25)return fail(res,409,'Створення меча коштує 25 золота.');
 const id=randomBytes(12).toString('hex'),now=new Date().toISOString();const tx=db.transaction(()=>{const debit=db.prepare('UPDATE player_region_wallets SET gold=gold-25 WHERE player_id=? AND region_key=? AND gold>=25').run(req.player.id,key);if(debit.changes!==1)throw new Error('NO_GOLD');db.prepare("INSERT INTO player_swords(id,owner_id,status,region_key,created_at) VALUES(?,?,'owned',?,?)").run(id,req.player.id,key,now);});try{tx();}catch(e){if(e.message==='NO_GOLD')return fail(res,409,'Недостатньо золота.');throw e;}res.status(201).json({ok:true,swordId:id,gold:activeWallet(req.player.id,key,name).gold,swords:db.prepare("SELECT COUNT(*) n FROM player_swords WHERE owner_id=? AND status IN ('owned','listed')").get(req.player.id).n});
});
app.get('/api/game/swords/mine',auth,(req,res)=>{const swords=db.prepare("SELECT s.id,s.status,s.created_at,l.id listing_id FROM player_swords s LEFT JOIN sword_auction_listings l ON l.sword_id=s.id AND l.status='active' WHERE s.owner_id=? AND s.status IN ('owned','listed') ORDER BY s.created_at DESC").all(req.player.id);res.json({swords});});
app.get('/api/game/auction',auth,(req,res)=>{const rows=db.prepare(`SELECT l.id,l.price,l.created_at,p.nickname seller,s.id sword_id FROM sword_auction_listings l JOIN players p ON p.id=l.seller_id JOIN player_swords s ON s.id=l.sword_id WHERE l.status='active' ORDER BY l.created_at DESC LIMIT 100`).all();res.json({listings:rows});});
app.post('/api/game/auction/list',auth,(req,res)=>{const swordId=String(req.body?.swordId||''),price=Number(req.body?.price);if(!Number.isInteger(price)||price<5||price>20)return fail(res,400,'Ціна меча має бути від 5 до 20 золота.');const sword=db.prepare('SELECT * FROM player_swords WHERE id=? AND owner_id=?').get(swordId,req.player.id);if(!sword||sword.status!=='owned')return fail(res,404,'Власний вільний меч не знайдено.');const id=randomBytes(12).toString('hex'),now=new Date().toISOString();const tx=db.transaction(()=>{db.prepare("UPDATE player_swords SET status='listed' WHERE id=? AND owner_id=? AND status='owned'").run(swordId,req.player.id);db.prepare("INSERT INTO sword_auction_listings(id,sword_id,seller_id,price,status,created_at,seller_region_key) VALUES(?,?,?,?,'active',?,?)").run(id,swordId,req.player.id,price,now,sword.region_key);});tx();res.status(201).json({ok:true,id});});
app.post('/api/game/auction/:id/buy',auth,(req,res)=>{const key=String(req.body?.regionKey||'').slice(0,120),name=String(req.body?.regionName||key).slice(0,100);if(!key)return fail(res,400,'Обери регіон для оплати.');const listing=db.prepare("SELECT * FROM sword_auction_listings WHERE id=? AND status='active'").get(req.params.id);if(!listing)return fail(res,404,'Оголошення вже недоступне.');if(listing.seller_id===req.player.id)return fail(res,400,'Не можна купити власний меч.');const wallet=activeWallet(req.player.id,key,name);if(wallet.gold<listing.price)return fail(res,409,'Недостатньо золота.');const now=new Date().toISOString();const tx=db.transaction(()=>{const lock=db.prepare("UPDATE sword_auction_listings SET status='sold',buyer_id=?,sold_at=? WHERE id=? AND status='active'").run(req.player.id,now,listing.id);if(lock.changes!==1)throw new Error('SOLD');const debit=db.prepare('UPDATE player_region_wallets SET gold=gold-? WHERE player_id=? AND region_key=? AND gold>=?').run(listing.price,req.player.id,key,listing.price);if(debit.changes!==1)throw new Error('NO_GOLD');db.prepare("UPDATE player_swords SET owner_id=?,status='owned',region_key=?,sold_at=? WHERE id=? AND status='listed'").run(req.player.id,key,now,listing.sword_id);const sellerKey=listing.seller_region_key||'marketplace';db.prepare('INSERT OR IGNORE INTO player_region_wallets(player_id,region_key,region_name,gold,last_refill_at) VALUES(?,?,?,0,?)').run(listing.seller_id,sellerKey,sellerKey,Date.now());db.prepare('UPDATE player_region_wallets SET gold=gold+? WHERE player_id=? AND region_key=?').run(listing.price,listing.seller_id,sellerKey);});try{tx();}catch(e){if(e.message==='SOLD')return fail(res,409,'Меч уже придбали.');if(e.message==='NO_GOLD')return fail(res,409,'Недостатньо золота.');throw e;}res.json({ok:true,bought:true,gold:activeWallet(req.player.id,key,name).gold});});
app.post('/api/game/auction/:id/cancel',auth,(req,res)=>{const listing=db.prepare("SELECT * FROM sword_auction_listings WHERE id=? AND seller_id=? AND status='active'").get(req.params.id,req.player.id);if(!listing)return fail(res,404,'Активне оголошення не знайдено.');const tx=db.transaction(()=>{db.prepare("UPDATE sword_auction_listings SET status='cancelled' WHERE id=? AND status='active'").run(listing.id);db.prepare("UPDATE player_swords SET status='owned' WHERE id=? AND owner_id=?").run(listing.sword_id,req.player.id);});tx();res.json({ok:true});});
app.post('/api/game/party/:id/invite',auth,(req,res)=>{const nickname=String(req.body?.nickname||'').trim();const party=db.prepare('SELECT id,name,player_id FROM regional_parties WHERE id=?').get(req.params.id);if(!party)return fail(res,404,'Партію не знайдено.');const member=db.prepare('SELECT role FROM regional_party_members WHERE party_id=? AND player_id=?').get(party.id,req.player.id);if(!member||!['leader','admin'].includes(member.role))return fail(res,403,'Запрошувати можуть лише лідер або адміністратор партії.');const target=db.prepare('SELECT id,nickname FROM players WHERE nickname=? COLLATE NOCASE').get(nickname);if(!target)return fail(res,404,'Гравця не знайдено.');if(target.id===req.player.id)return fail(res,400,'Не можна запросити себе.');if(db.prepare('SELECT 1 FROM regional_party_members WHERE party_id=? AND player_id=?').get(party.id,target.id))return fail(res,409,'Гравець уже в цій партії.');const id=randomBytes(12).toString('hex'),now=new Date().toISOString();try{db.prepare("INSERT INTO party_invites(id,party_id,inviter_id,invitee_id,status,created_at,updated_at) VALUES(?,?,?,?,'pending',?,?)").run(id,party.id,req.player.id,target.id,now,now);}catch(e){return fail(res,409,'Запрошення вже надсилали.');}cwNotify(target.id,'party_invite','Запрошення до партії',req.player.nickname+' запрошує тебе до партії «'+party.name+'».',{partyInviteId:id,partyId:party.id});res.status(201).json({ok:true,id});});
app.get('/api/game/my-parties',auth,(req,res)=>{const parties=db.prepare(`SELECT p.id,p.name,m.role FROM regional_party_members m JOIN regional_parties p ON p.id=m.party_id WHERE m.player_id=? ORDER BY p.created_at DESC`).all(req.player.id);res.json({parties});});
app.get('/api/game/party-invites',auth,(req,res)=>{const rows=db.prepare(`SELECT i.id,i.party_id,i.status,i.created_at,p.name party_name,u.nickname inviter FROM party_invites i JOIN regional_parties p ON p.id=i.party_id JOIN players u ON u.id=i.inviter_id WHERE i.invitee_id=? AND i.status='pending' ORDER BY i.created_at DESC`).all(req.player.id);res.json({invites:rows});});
app.post('/api/game/party-invites/:id/respond',auth,(req,res)=>{const invite=db.prepare("SELECT * FROM party_invites WHERE id=? AND invitee_id=? AND status='pending'").get(req.params.id,req.player.id);if(!invite)return fail(res,404,'Активне запрошення не знайдено.');const accept=req.body?.accept===true,now=new Date().toISOString();const tx=db.transaction(()=>{db.prepare('UPDATE party_invites SET status=?,updated_at=? WHERE id=? AND status=\'pending\'').run(accept?'accepted':'rejected',now,invite.id);if(accept)db.prepare("INSERT OR IGNORE INTO regional_party_members(party_id,player_id,role,joined_at) VALUES(?,?,'member',?)").run(invite.party_id,req.player.id,Date.now());});tx();res.json({ok:true,status:accept?'accepted':'rejected'});});

// Turn-based, non-graphic player duels. A battering-ram strike gives +500 account XP.
app.get('/api/game/duels',auth,(req,res)=>{const duels=db.prepare(`SELECT d.*,a.nickname challenger,b.nickname opponent,w.nickname winner FROM game_duels d JOIN players a ON a.id=d.challenger_id JOIN players b ON b.id=d.opponent_id LEFT JOIN players w ON w.id=d.winner_id WHERE d.challenger_id=? OR d.opponent_id=? ORDER BY d.updated_at DESC LIMIT 30`).all(req.player.id,req.player.id).map(d=>({...d,is_challenger:d.challenger_id===req.player.id,is_opponent:d.opponent_id===req.player.id,is_my_turn:d.current_turn_id===req.player.id}));res.json({duels});});
app.post('/api/game/duels/challenge',auth,(req,res)=>{if(!rateLimit('duel:'+req.player.id,5,60000))return fail(res,429,'Забагато викликів. Спробуй трохи пізніше.');const nickname=String(req.body?.nickname||'').trim();const target=db.prepare('SELECT id,nickname FROM players WHERE nickname=? COLLATE NOCASE').get(nickname);if(!target)return fail(res,404,'Гравця не знайдено.');if(target.id===req.player.id)return fail(res,400,'Не можна викликати самого себе.');if(db.prepare('SELECT 1 FROM player_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)').get(req.player.id,target.id,target.id,req.player.id))return fail(res,403,'Виклик недоступний.');const exists=db.prepare("SELECT 1 FROM game_duels WHERE status IN ('pending','active') AND ((challenger_id=? AND opponent_id=?) OR (challenger_id=? AND opponent_id=?))").get(req.player.id,target.id,target.id,req.player.id);if(exists)return fail(res,409,'Між вами вже є активний виклик або поєдинок.');const id=randomBytes(12).toString('hex'),now=new Date().toISOString();db.prepare("INSERT INTO game_duels(id,challenger_id,opponent_id,status,challenger_hp,opponent_hp,current_turn_id,created_at,updated_at) VALUES(?,?,?,'pending',100,100,NULL,?,?)").run(id,req.player.id,target.id,now,now);cwNotify(target.id,'duel_invite','Виклик на поєдинок',req.player.nickname+' викликає тебе на ігровий поєдинок.',{duelId:id});res.status(201).json({ok:true,id});});
app.post('/api/game/duels/:id/respond',auth,(req,res)=>{const duel=db.prepare("SELECT * FROM game_duels WHERE id=? AND opponent_id=? AND status='pending'").get(req.params.id,req.player.id);if(!duel)return fail(res,404,'Активний виклик не знайдено.');const accept=req.body?.accept===true,now=new Date().toISOString();db.prepare("UPDATE game_duels SET status=?,current_turn_id=?,updated_at=? WHERE id=? AND status='pending'").run(accept?'active':'declined',accept?duel.challenger_id:null,now,duel.id);cwNotify(duel.challenger_id,'duel_response',accept?'Виклик прийнято':'Виклик відхилено',req.player.nickname+(accept?' прийняв':' відхилив')+' твій виклик.');res.json({ok:true,status:accept?'active':'declined'});});
app.post('/api/game/duels/:id/attack',auth,(req,res)=>{const type=req.body?.type==='ram'?'ram':'normal',duel=db.prepare("SELECT * FROM game_duels WHERE id=? AND status='active'").get(req.params.id);if(!duel)return fail(res,404,'Активний поєдинок не знайдено.');if(duel.current_turn_id!==req.player.id)return fail(res,403,'Зараз не твій хід.');const isChallenger=duel.challenger_id===req.player.id;if(!isChallenger&&duel.opponent_id!==req.player.id)return fail(res,403,'Ти не учасник цього поєдинку.');const targetId=isChallenger?duel.opponent_id:duel.challenger_id;const knight=!!db.prepare("SELECT 1 FROM state_knights k JOIN state_government_settings g ON g.state_id=k.state_id WHERE k.player_id=? AND g.government_type='monarchy' LIMIT 1").get(req.player.id);const baseDamage=type==='ram'?25:10;const damage=knight?Math.ceil(baseDamage*1.2):baseDamage;const now=new Date().toISOString();const tx=db.transaction(()=>{if(type==='ram'){const used=db.prepare('UPDATE player_inventory SET battering_rams=battering_rams-1,updated_at=? WHERE player_id=? AND battering_rams>0').run(now,req.player.id);if(used.changes!==1)throw new Error('NO_RAM');db.prepare('UPDATE player_game_stats SET xp=xp+500 WHERE player_id=?').run(req.player.id);db.prepare('INSERT INTO player_ram_strikes(id,player_id,region_key,xp_awarded,created_at) VALUES(?,?,?,?,?)').run(randomBytes(12).toString('hex'),req.player.id,'duel:'+duel.id,500,now);}const hpCol=isChallenger?'opponent_hp':'challenger_hp';const current=isChallenger?duel.opponent_hp:duel.challenger_hp;const next=Math.max(0,current-damage);const changed=db.prepare(`UPDATE game_duels SET ${hpCol}=?,status=?,winner_id=?,current_turn_id=?,updated_at=? WHERE id=? AND status='active' AND current_turn_id=?`).run(next,next===0?'finished':'active',next===0?req.player.id:null,next===0?null:targetId,now,duel.id,req.player.id);if(changed.changes!==1)throw new Error('TURN_CHANGED');});try{tx();}catch(e){if(e.message==='NO_RAM')return fail(res,409,'Для тарана потрібен хоча б один таран в інвентарі.');if(e.message==='TURN_CHANGED')return fail(res,409,'Хід уже змінився. Онови поєдинок.');throw e;}const updated=db.prepare('SELECT * FROM game_duels WHERE id=?').get(duel.id);cwNotify(targetId,'duel_turn',updated.status==='finished'?'Поєдинок завершено':'Твій хід',updated.status==='finished'?'Переможець: '+req.player.nickname:'Суперник зробив хід.');res.json({ok:true,damage,type,knightBonus:knight?20:0,xpAwarded:type==='ram'?500:0,duel:updated,profile:gameProfile(req.player.id)});});

app.get('/api/achievements',auth,(req,res)=>{
 const stats=gameProfile(req.player.id);const owned=db.prepare('SELECT COUNT(*) n FROM game_states WHERE owner_id=?').get(req.player.id).n;const friendCount=db.prepare("SELECT COUNT(*) n FROM player_friends WHERE status='accepted' AND (requester_id=? OR addressee_id=?)").get(req.player.id,req.player.id).n;const articleCount=db.prepare('SELECT COUNT(*) n FROM game_articles WHERE author_id=?').get(req.player.id).n;
 const checks=[['first_steps','Перші кроки','Зареєструватися у світі',1],['level_1','Перший рівень','Набрати 1000 HP',stats.xp>=1000],['state_founder','Засновник держави','Створити власну державу',owned>0],['social','Соціальний гравець','Знайти першого друга',friendCount>0],['author','Автор','Опублікувати першу статтю',articleCount>0]];
 const put=db.prepare('INSERT OR IGNORE INTO player_achievements(player_id,achievement_key,unlocked_at) VALUES(?,?,?)');const tx=db.transaction(()=>checks.forEach(c=>{if(c[3]===1||c[3]===true)put.run(req.player.id,c[0],new Date().toISOString());}));tx();
 const unlocked=db.prepare('SELECT achievement_key,unlocked_at FROM player_achievements WHERE player_id=?').all(req.player.id);const map=new Map(unlocked.map(x=>[x.achievement_key,x.unlocked_at]));res.json({achievements:checks.map(c=>({key:c[0],title:c[1],description:c[2],unlocked:map.has(c[0]),unlockedAt:map.get(c[0])||null}))});
});
app.get('/api/events',auth,(req,res)=>{const events=db.prepare('SELECT e.id,e.scope,e.title,e.body,e.created_at,p.nickname actor FROM world_events e LEFT JOIN players p ON p.id=e.actor_id ORDER BY e.created_at DESC LIMIT 100').all();res.json({events});});

// Chemis World 5.0.0: political career API.
const CW_OFFICES={
 president:'Президент',prime_minister:'Прем’єр-міністр',minister:'Міністр',
 governor:'Губернатор',mayor:'Мер',deputy:'Депутат'
};
function ownsPoliticalState(stateId,playerId){return !!db.prepare('SELECT 1 FROM game_states WHERE id=? AND owner_id=?').get(stateId,playerId);}
app.get('/api/career',auth,(req,res)=>{
 const offices=db.prepare(`SELECT o.*,s.name state_name,p.nickname appointed_by_name
 FROM political_offices o JOIN game_states s ON s.id=o.state_id
 LEFT JOIN players p ON p.id=o.appointed_by
 WHERE o.player_id=? ORDER BY o.started_at DESC LIMIT 100`).all(req.player.id);
 const states=db.prepare('SELECT id,name,capital FROM game_states WHERE owner_id=? ORDER BY created_at DESC').all(req.player.id);
 const reputation=db.prepare('SELECT r.state_id,s.name state_name,r.score,r.updated_at FROM political_reputation r JOIN game_states s ON s.id=r.state_id WHERE r.player_id=?').all(req.player.id);
 res.json({offices,states,reputation,officeTypes:CW_OFFICES});
});
app.get('/api/states/:id/career',auth,(req,res)=>{
 const state=db.prepare('SELECT id,name,owner_id FROM game_states WHERE id=?').get(req.params.id);
 if(!state)return fail(res,404,'Державу не знайдено.');
 const offices=db.prepare(`SELECT o.id,o.player_id,p.nickname,o.office_key,o.office_title,o.territory_key,o.source_type,o.started_at,o.ends_at,o.status,o.notes
 FROM political_offices o JOIN players p ON p.id=o.player_id WHERE o.state_id=? AND o.status='active' ORDER BY o.started_at DESC`).all(state.id);
 const history=db.prepare(`SELECT o.id,o.player_id,p.nickname,o.office_key,o.office_title,o.territory_key,o.started_at,o.ends_at,o.ended_at,o.status,o.source_type
 FROM political_offices o JOIN players p ON p.id=o.player_id WHERE o.state_id=? ORDER BY o.started_at DESC LIMIT 100`).all(state.id);
 res.json({state:{id:state.id,name:state.name},offices,history,canManage:state.owner_id===req.player.id});
});
app.post('/api/states/:id/career/appoint',auth,(req,res)=>{
 const stateId=req.params.id;
 if(!ownsPoliticalState(stateId,req.player.id))return fail(res,403,'Призначення може робити лише керівник держави.');
 const officeKey=String(req.body?.officeKey||'');
 const targetId=String(req.body?.playerId||'');
 const territoryKey=String(req.body?.territoryKey||'').slice(0,100);
 const notes=String(req.body?.notes||'').trim().slice(0,500);
 if(!Object.hasOwn(CW_OFFICES,officeKey))return fail(res,400,'Невідома державна посада.');
 const target=db.prepare('SELECT id,nickname FROM players WHERE id=?').get(targetId);
 if(!target)return fail(res,404,'Гравця не знайдено.');
 if(['governor','mayor'].includes(officeKey)&&!territoryKey)return fail(res,400,'Для регіональної посади вкажи код території.');
 if(territoryKey&&!db.prepare('SELECT 1 FROM state_territories WHERE state_id=? AND territory_key=?').get(stateId,territoryKey))return fail(res,400,'Територія не належить цій державі.');
 const now=new Date().toISOString(),id=randomBytes(12).toString('hex');
 const tx=db.transaction(()=>{
  db.prepare("UPDATE political_offices SET status='dismissed',ended_at=? WHERE state_id=? AND office_key=? AND territory_key=? AND status='active'").run(now,stateId,officeKey,territoryKey);
  db.prepare(`INSERT INTO political_offices(id,state_id,player_id,office_key,office_title,territory_key,appointed_by,source_type,started_at,notes)
   VALUES(?,?,?,?,?,?,?,'appointment',?,?)`).run(id,stateId,targetId,officeKey,CW_OFFICES[officeKey],territoryKey,req.player.id,now,notes);
  db.prepare('INSERT OR IGNORE INTO political_reputation(player_id,state_id,score,updated_at) VALUES(?,?,0,?)').run(targetId,stateId,now);
 });tx();
 cwNotify(targetId,'political_appointment','Нове призначення','Тебе призначено на посаду: '+CW_OFFICES[officeKey]+'.',{stateId,officeId:id});
 cwEvent(req.player.id,'politics','Нове державне призначення',target.nickname+' — '+CW_OFFICES[officeKey]);
 res.status(201).json({ok:true,office:{id,playerId:targetId,nickname:target.nickname,officeKey,officeTitle:CW_OFFICES[officeKey],startedAt:now,status:'active'}});
});
app.post('/api/career/offices/:id/resign',auth,(req,res)=>{
 const office=db.prepare('SELECT * FROM political_offices WHERE id=? AND player_id=? AND status=\'active\'').get(req.params.id,req.player.id);
 if(!office)return fail(res,404,'Активну посаду не знайдено.');
 const now=new Date().toISOString();db.prepare("UPDATE political_offices SET status='resigned',ended_at=? WHERE id=?").run(now,office.id);
 cwEvent(req.player.id,'politics','Відставка з посади',office.office_title);
 res.json({ok:true,status:'resigned',endedAt:now});
});
app.post('/api/states/:id/career/offices/:officeId/end',auth,(req,res)=>{
 if(!ownsPoliticalState(req.params.id,req.player.id))return fail(res,403,'Завершити повноваження може лише керівник держави.');
 const office=db.prepare("SELECT * FROM political_offices WHERE id=? AND state_id=? AND status='active'").get(req.params.officeId,req.params.id);
 if(!office)return fail(res,404,'Активну посаду не знайдено.');
 const now=new Date().toISOString();db.prepare("UPDATE political_offices SET status='dismissed',ended_at=? WHERE id=?").run(now,office.id);
 cwNotify(office.player_id,'political_dismissal','Повноваження завершено','Твої повноваження на посаді «'+office.office_title+'» завершено.');
 cwEvent(req.player.id,'politics','Завершено державні повноваження',office.office_title);
 res.json({ok:true,status:'dismissed',endedAt:now});
});
app.post('/api/states/:id/career/reputation',auth,(req,res)=>{
 if(!ownsPoliticalState(req.params.id,req.player.id))return fail(res,403,'Змінювати репутацію може лише керівник держави.');
 const playerId=String(req.body?.playerId||'');const delta=Number(req.body?.delta);
 if(!Number.isInteger(delta)||delta===0||Math.abs(delta)>10)return fail(res,400,'Зміна репутації має бути цілим числом від -10 до 10.');
 if(!db.prepare('SELECT 1 FROM players WHERE id=?').get(playerId))return fail(res,404,'Гравця не знайдено.');
 const now=new Date().toISOString();db.prepare('INSERT OR IGNORE INTO political_reputation(player_id,state_id,score,updated_at) VALUES(?,?,0,?)').run(playerId,req.params.id,now);
 db.prepare('UPDATE political_reputation SET score=MAX(-100,MIN(100,score+?)),updated_at=? WHERE player_id=? AND state_id=?').run(delta,now,playerId,req.params.id);
 const row=db.prepare('SELECT score FROM political_reputation WHERE player_id=? AND state_id=?').get(playerId,req.params.id);
 res.json({ok:true,playerId,reputation:row.score});
});

// 5.1.0 player account expansion: public profile, settings, follows, privacy, blocks and reports.
function ensureAccountProfile(playerId){
 const now=new Date().toISOString();
 db.prepare('INSERT OR IGNORE INTO player_profile_settings(player_id,updated_at) VALUES(?,?)').run(playerId,now);
 db.prepare('INSERT OR IGNORE INTO player_game_stats(player_id,created_at) SELECT id,created_at FROM players WHERE id=?').run(playerId);
 return db.prepare(`SELECT p.id,p.nickname,p.bio,p.home_region,p.created_at,
  s.avatar,s.cover_color,s.status,s.visibility,COALESCE(g.xp,0) xp,
  CAST(COALESCE(g.xp,0)/1000 AS INTEGER)+1 level
  FROM players p JOIN player_profile_settings s ON s.player_id=p.id
  LEFT JOIN player_game_stats g ON g.player_id=p.id WHERE p.id=?`).get(playerId);
}
function accountActivity(playerId,type,title,details=''){
 db.prepare('INSERT INTO player_activity(id,player_id,activity_type,title,details,created_at) VALUES(?,?,?,?,?,?)')
 .run(randomBytes(12).toString('hex'),playerId,type,title,String(details).slice(0,240),new Date().toISOString());
}
app.get('/api/account/profile',auth,(req,res)=>{
 const profile=ensureAccountProfile(req.player.id);
 const counts={friends:db.prepare("SELECT COUNT(*) n FROM player_friends WHERE status='accepted' AND (requester_id=? OR addressee_id=?)").get(req.player.id,req.player.id).n,
 followers:db.prepare('SELECT COUNT(*) n FROM player_follows WHERE followed_id=?').get(req.player.id).n,
 following:db.prepare('SELECT COUNT(*) n FROM player_follows WHERE follower_id=?').get(req.player.id).n,
 articles:db.prepare('SELECT COUNT(*) n FROM game_articles WHERE author_id=?').get(req.player.id).n,
 offices:db.prepare("SELECT COUNT(*) n FROM political_offices WHERE player_id=?").get(req.player.id).n};
 const achievements=db.prepare('SELECT achievement_key,unlocked_at FROM player_achievements WHERE player_id=? ORDER BY unlocked_at DESC').all(req.player.id);
 const activity=db.prepare('SELECT activity_type,title,details,created_at FROM player_activity WHERE player_id=? ORDER BY created_at DESC LIMIT 20').all(req.player.id);
 const game=ensurePlayerGame(req.player.id);
 const swords=db.prepare("SELECT COUNT(*) n FROM player_swords WHERE owner_id=? AND status IN ('owned','listed')").get(req.player.id).n;
 const party=db.prepare('SELECT p.id,p.name FROM regional_party_members m JOIN regional_parties p ON p.id=m.party_id WHERE m.player_id=? ORDER BY m.joined_at DESC LIMIT 1').get(req.player.id)||null;
 const rank=db.prepare('SELECT COUNT(*)+1 rank FROM player_game_stats WHERE xp>(SELECT xp FROM player_game_stats WHERE player_id=?)').get(req.player.id)?.rank||1;
 const days=Math.max(0,Math.floor((Date.now()-new Date(req.player.created_at).getTime())/86400000));
 res.json({profile,counts,game:{xp:game.xp,level:Math.floor(game.xp/1000)+1,energy:game.energy,days,rank},swords,party,achievements,activity});
});
app.patch('/api/account/profile',auth,(req,res)=>{
 const avatar=String(req.body?.avatar||'👤').trim(),cover=String(req.body?.coverColor||'#183153'),status=String(req.body?.status||'').trim(),visibility=String(req.body?.visibility||'public');const avatarImage=/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(avatar);const avatarBytes=avatarImage?Buffer.byteLength(avatar.split(',')[1]||'','base64'):0;
 const bio=String(req.body?.bio??req.player.bio??'').trim(),home=String(req.body?.homeRegion??req.player.home_region??'').trim();
 if((!avatarImage&&[...avatar].length>8)||(avatarImage&&avatarBytes>420000)||status.length>48||bio.length>120||home.length>60||!/^#[0-9a-f]{6}$/i.test(cover)||!['public','friends','private'].includes(visibility))return fail(res,400,'Перевір аватар (фото до 420 КБ або символ), статус, опис, колір чи приватність профілю.');
 const now=new Date().toISOString();
 db.prepare('UPDATE players SET bio=?,home_region=? WHERE id=?').run(bio,home,req.player.id);
 db.prepare(`INSERT INTO player_profile_settings(player_id,avatar,cover_color,status,visibility,updated_at) VALUES(?,?,?,?,?,?)
 ON CONFLICT(player_id) DO UPDATE SET avatar=excluded.avatar,cover_color=excluded.cover_color,status=excluded.status,visibility=excluded.visibility,updated_at=excluded.updated_at`).run(req.player.id,avatar,cover,status,visibility,now);
 accountActivity(req.player.id,'profile','Оновлено профіль','Змінено персональні дані та оформлення профілю.');
 res.json({ok:true,profile:ensureAccountProfile(req.player.id)});
});
app.get('/api/account/players/:id',auth,(req,res)=>{
 const target=ensureAccountProfile(req.params.id);if(!target)return fail(res,404,'Гравця не знайдено.');
 const blocked=db.prepare('SELECT 1 FROM player_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)').get(req.player.id,target.id,target.id,req.player.id);
 if(blocked)return fail(res,404,'Профіль недоступний.');
 const isFriend=!!db.prepare("SELECT 1 FROM player_friends WHERE status='accepted' AND ((requester_id=? AND addressee_id=?) OR (requester_id=? AND addressee_id=?))").get(req.player.id,target.id,target.id,req.player.id);
 if(target.visibility==='private'&&target.id!==req.player.id)return fail(res,403,'Цей профіль приватний.');
 if(target.visibility==='friends'&&!isFriend&&target.id!==req.player.id)return fail(res,403,'Профіль доступний лише друзям.');
 const counts={followers:db.prepare('SELECT COUNT(*) n FROM player_follows WHERE followed_id=?').get(target.id).n,following:db.prepare('SELECT COUNT(*) n FROM player_follows WHERE follower_id=?').get(target.id).n};
 const game=ensurePlayerGame(target.id);
 const swords=db.prepare("SELECT COUNT(*) n FROM player_swords WHERE owner_id=? AND status IN ('owned','listed')").get(target.id).n;
 const party=db.prepare(`SELECT p.id,p.name FROM regional_party_members m JOIN regional_parties p ON p.id=m.party_id WHERE m.player_id=? ORDER BY m.joined_at DESC LIMIT 1`).get(target.id)||null;
 const rank=db.prepare('SELECT COUNT(*)+1 rank FROM player_game_stats WHERE xp>(SELECT xp FROM player_game_stats WHERE player_id=?)').get(target.id)?.rank||1;
 res.json({profile:target,counts,game:{xp:game.xp,level:Math.floor(game.xp/1000)+1,rank},swords,party,isFollowing:!!db.prepare('SELECT 1 FROM player_follows WHERE follower_id=? AND followed_id=?').get(req.player.id,target.id),isSelf:target.id===req.player.id});
});
app.post('/api/account/players/:id/follow',auth,(req,res)=>{
 const target=db.prepare('SELECT id,nickname FROM players WHERE id=?').get(req.params.id);if(!target)return fail(res,404,'Гравця не знайдено.');if(target.id===req.player.id)return fail(res,400,'Не можна підписатися на власний профіль.');
 if(db.prepare('SELECT 1 FROM player_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)').get(req.player.id,target.id,target.id,req.player.id))return fail(res,403,'Дія недоступна.');
 const exists=db.prepare('SELECT 1 FROM player_follows WHERE follower_id=? AND followed_id=?').get(req.player.id,target.id);
 if(exists)db.prepare('DELETE FROM player_follows WHERE follower_id=? AND followed_id=?').run(req.player.id,target.id);
 else{db.prepare('INSERT INTO player_follows(follower_id,followed_id,created_at) VALUES(?,?,?)').run(req.player.id,target.id,new Date().toISOString());cwNotify(target.id,'new_follower','Новий підписник',req.player.nickname+' підписався на твій профіль.');}
 res.json({ok:true,following:!exists});
});
app.post('/api/account/players/:id/block',auth,(req,res)=>{
 const target=db.prepare('SELECT id FROM players WHERE id=?').get(req.params.id);if(!target)return fail(res,404,'Гравця не знайдено.');if(target.id===req.player.id)return fail(res,400,'Не можна заблокувати себе.');
 const exists=db.prepare('SELECT 1 FROM player_blocks WHERE blocker_id=? AND blocked_id=?').get(req.player.id,target.id);
 if(exists)db.prepare('DELETE FROM player_blocks WHERE blocker_id=? AND blocked_id=?').run(req.player.id,target.id);
 else{db.prepare('INSERT INTO player_blocks(blocker_id,blocked_id,created_at) VALUES(?,?,?)').run(req.player.id,target.id,new Date().toISOString());db.prepare('DELETE FROM player_follows WHERE (follower_id=? AND followed_id=?) OR (follower_id=? AND followed_id=?)').run(req.player.id,target.id,target.id,req.player.id);}
 res.json({ok:true,blocked:!exists});
});
app.post('/api/account/players/:id/report',auth,(req,res)=>{
 const target=db.prepare('SELECT id FROM players WHERE id=?').get(req.params.id);if(!target)return fail(res,404,'Гравця не знайдено.');if(target.id===req.player.id)return fail(res,400,'Не можна поскаржитися на себе.');
 const reason=String(req.body?.reason||'').trim(),details=String(req.body?.details||'').trim();if(!['spam','harassment','impersonation','cheating','other'].includes(reason)||details.length>500)return fail(res,400,'Оберіть причину та перевірте опис.');
 const id=randomBytes(12).toString('hex');db.prepare('INSERT INTO player_reports(id,reporter_id,reported_id,reason,details,created_at) VALUES(?,?,?,?,?,?)').run(id,req.player.id,target.id,reason,details,new Date().toISOString());
 res.status(201).json({ok:true,reportId:id});
});
app.get('/api/account/followers',auth,(req,res)=>{
 const followers=db.prepare('SELECT p.id,p.nickname,p.bio,f.created_at FROM player_follows f JOIN players p ON p.id=f.follower_id WHERE f.followed_id=? ORDER BY f.created_at DESC LIMIT 100').all(req.player.id);
 const following=db.prepare('SELECT p.id,p.nickname,p.bio,f.created_at FROM player_follows f JOIN players p ON p.id=f.followed_id WHERE f.follower_id=? ORDER BY f.created_at DESC LIMIT 100').all(req.player.id);
 res.json({followers,following});
});

// Browser edition: serve the same HTML/CSS/JS client used by the Android WebView.
// The API remains on this origin, so browser users do not need to configure a server URL.
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const webRoot = path.resolve(__dirname, '../public');
app.use(express.static(webRoot, {
  extensions: ['html'],
  setHeaders(res, filePath) {
    // Keep browser clients on the same release as the deployed server.
    if (/\.(html|css|js)$/i.test(filePath)) {
      res.setHeader('Cache-Control', 'no-cache, must-revalidate');
    }
  }
}));

app.use((err,req,res,next)=>{console.error(err.message);res.status(500).json({error:'Внутрішня помилка сервера.'});});
app.listen(PORT,'0.0.0.0',()=>console.log(`Chemis World API listening on ${PORT}`));
