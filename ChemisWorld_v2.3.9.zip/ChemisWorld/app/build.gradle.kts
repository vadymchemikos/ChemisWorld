plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.chemisworld.game"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.chemisworld.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 25
        versionName = "2.3.9"
    }
}
