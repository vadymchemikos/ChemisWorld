const toast=document.getElementById('toast');
let toastTimer;
function notify(message){
  toast.textContent=message;toast.classList.add('show');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2600);
}
// Quick-access tiles are routed to their real game sections below.

const mapButton=document.getElementById('mapBtn');
mapButton.addEventListener('click',()=>{
  document.getElementById('worldMap').scrollIntoView({behavior:'smooth',block:'center'});
  notify('Обирай країну на карті, щоб перейти до областей.');
});

const mapStatus=document.getElementById('mapStatus');

let map, regionLayer;
let currentCountry=null, currentAdmin1=null, currentLevel='regions';
let countryFeatures=[], allRegionFeatures=[];
let selectedMapTerritory=null;
function setStatus(text){if(mapStatus)mapStatus.textContent=text;}
function safeText(value){
  return String(value??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
}
function featureName(feature){
  const p=feature.properties||{};
  return p.shapeName||p.shapeName_en||p.NAME_2||p.NAME_1||p.NAME||p.ADMIN||p.name||p.admin||p.name_en||'Невідомий регіон';
}
function featureCode(feature){
  const p=feature.properties||{};
  return p.shapeISO||p.shapeID||p.GID_1||p.ADM1_CODE||p.REGION_ID||p.id||'';
}
const mapPalette=['#f0ed00','#3478df','#b00000','#00a56a','#777d80','#00c99a','#5a6398','#8a0050','#202020','#6d2600','#007c9b'];
function mapColor(feature){
  const p=feature.properties||{};
  const key=(p.CW_ISO||'')+':'+(featureCode(feature)||featureName(feature));
  let hash=0;for(let i=0;i<key.length;i++)hash=(hash*31+key.charCodeAt(i))>>>0;
  return mapPalette[hash%mapPalette.length];
}
function layerStyle(feature){return {color:'#080808',weight:1.65,fillColor:mapColor(feature),fillOpacity:.98};}
function selectedStyle(){return {color:'#ffffff',weight:2.5,fillColor:'#d7d700',fillOpacity:1};}
async function fetchGeoBoundaries(iso,adm){
  const urls=[
    `https://www.geoboundaries.org/api/current/gbOpen/${encodeURIComponent(iso)}/${adm}/`,
    `https://www.geoboundaries.org/api/current/gbOpen/${encodeURIComponent(iso)}/${adm}/`
  ];
  let lastError;
  for(const url of urls){
    try{
      const response=await fetch(url,{cache:'no-store'});
      if(!response.ok)throw new Error('metadata HTTP '+response.status);
      const metadata=await response.json();
      if(metadata.type==='FeatureCollection'&&Array.isArray(metadata.features))return metadata;
      const geoUrl=metadata.simplifiedGeometryGeoJSON||metadata.gjDownloadURLSimplified||metadata.gjDownloadURL||metadata.geojson;
      if(!geoUrl)throw new Error('У відповіді немає посилання на GeoJSON');
      const geoResponse=await fetch(geoUrl,{cache:'force-cache'});
      if(!geoResponse.ok)throw new Error('GeoJSON HTTP '+geoResponse.status);
      const data=await geoResponse.json();
      if(data.type!=='FeatureCollection'||!Array.isArray(data.features))throw new Error('Некоректний GeoJSON');
      return data;
    }catch(error){lastError=error;}
  }
  throw lastError||new Error('Administrative boundaries unavailable');
}
async function fetchUkraineRegions(){
  const urls=[
    'https://cdn.jsdelivr.net/gh/EugeneBorshch/ukraine_geojson@master/UA_FULL_Ukraine.geojson',
    'https://raw.githubusercontent.com/EugeneBorshch/ukraine_geojson/master/UA_FULL_Ukraine.geojson',
    'https://cdn.jsdelivr.net/gh/darmat1/ukraine-geo-data@main/geodata/Ukraine.geojson'
  ];
  let lastError;
  for(const url of urls){try{const r=await fetch(url,{cache:'force-cache'});if(!r.ok)throw new Error('HTTP '+r.status);const d=await r.json();if(d.type==='FeatureCollection'&&d.features?.length)return d;}catch(e){lastError=e;}}
  throw lastError||new Error('Українські області недоступні');
}


function cwFeatureEdges(feature){
 const geom=feature?.geometry;if(!geom)return [];
 const polygons=geom.type==='Polygon'?[geom.coordinates]:geom.type==='MultiPolygon'?geom.coordinates:[];
 const edges=[];
 const keyPoint=p=>Number(p[0]).toFixed(4)+','+Number(p[1]).toFixed(4);
 for(const poly of polygons)for(const ring of poly){
  for(let i=1;i<ring.length;i++){
   const a=keyPoint(ring[i-1]),b=keyPoint(ring[i]);
   edges.push(a<b?a+'|'+b:b+'|'+a);
  }
 }
 return edges;
}
function cwFindNeighborRegions(feature){
 const selected=new Set(cwFeatureEdges(feature));
 if(!selected.size)return [];
 return (allRegionFeatures||[]).filter(other=>other!==feature).map(other=>{
  const edges=cwFeatureEdges(other);let shared=0;
  for(const edge of edges)if(selected.has(edge))shared++;
  return {feature:other,shared};
 }).filter(x=>x.shared>=2).sort((a,b)=>b.shared-a.shared).map(x=>x.feature);
}
async function cwVerifiedCoat(regionName,country){
 try{
  const query=encodeURIComponent(regionName+' '+country);
  const search=await fetch('https://www.wikidata.org/w/api.php?action=wbsearchentities&search='+query+'&language=en&uselang=en&type=item&limit=8&format=json&origin=*');
  if(!search.ok)return null;
  const hits=(await search.json()).search||[];
  const candidate=hits.find(x=>/region|voivodeship|county|province|administrative|land|district/i.test((x.description||'')));
  if(!candidate)return null;
  const er=await fetch('https://www.wikidata.org/w/api.php?action=wbgetentities&ids='+encodeURIComponent(candidate.id)+'&props=claims|labels&languages=en&format=json&origin=*');
  if(!er.ok)return null;
  const entity=(await er.json()).entities?.[candidate.id];
  const file=entity?.claims?.P94?.[0]?.mainsnak?.datavalue?.value;
  if(!file||typeof file!=='string')return null;
  const title='File:'+file;
  const cr=await fetch('https://commons.wikimedia.org/w/api.php?action=query&titles='+encodeURIComponent(title)+'&prop=imageinfo&iiprop=url|extmetadata&iiurlwidth=120&format=json&origin=*');
  if(!cr.ok)return null;
  const page=Object.values((await cr.json()).query?.pages||{})[0];
  const info=page?.imageinfo?.[0];
  if(!info?.thumburl&&!info?.url)return null;
  return {src:info.thumburl||info.url,title:candidate.label||regionName,description:candidate.description||'',license:info.extmetadata?.LicenseShortName?.value||'ліцензія вказана на Wikimedia Commons'};
 }catch(e){return null;}
}
async function cwShowRegionProfile(name, country, feature){
 const old=document.getElementById('cwRegionProfile');if(old)old.remove();
 const modal=document.createElement('div');modal.id='cwRegionProfile';modal.className='cw-region-overlay';
 modal.innerHTML='<div class="cw-region-sheet"><div class="cw-region-head"><h2></h2><button type="button" aria-label="Закрити">✕</button></div><div class="cw-region-media"><div class="cw-region-coat">🏛️</div><img class="cw-region-photo" alt="Фото регіону" hidden></div><p class="cw-region-country"></p><p class="cw-region-summary">Завантаження інформації…</p><div class="cw-region-game"><h3>Показники регіону</h3><div class="cw-region-stats"><span>Мешканці-гравці<b id="cwRegPopulation">—</b></span><span>Губернатор<b id="cwRegGovernor">—</b></span><span>Бюджет<b id="cwRegBudget">—</b></span><span>Партії<b id="cwRegParties">—</b></span><span>Академії<b id="cwRegAcademies">—</b></span></div><p id="cwRegIndexes"></p><div id="cwRegDecree"></div><h3>Прикордонні регіони</h3><div id="cwRegNeighbors">Визначаємо спільні кордони…</div></div><div class="cw-region-facts"></div><button type="button" class="primary cw-region-select">Обрати регіон</button></div>';
 const sheet=modal.querySelector('.cw-region-sheet');sheet.querySelector('h2').textContent=name;
 sheet.querySelector('.cw-region-country').textContent='Країна: '+country;
 const close=()=>modal.remove();sheet.querySelector('.cw-region-head button').onclick=close;
 sheet.querySelector('.cw-region-select').onclick=()=>{close();document.getElementById('regionCard')?.scrollIntoView({behavior:'smooth'});};
 modal.addEventListener('click',e=>{if(e.target===modal)close();});document.body.append(modal);
 const props=feature?.properties||{};
 const key=props.CW_REGION_KEY||props.REGION_ID||props.NUTS_ID||((props.CW_ISO||'EU')+':'+name);
 try{
  const r=await fetch('https://en.wikipedia.org/api/rest_v1/page/summary/'+encodeURIComponent(name),{headers:{accept:'application/json'}});
  if(r.ok){const d=await r.json();sheet.querySelector('.cw-region-summary').textContent=d.extract||'Опис у Вікіпедії відсутній.';
   if(d.thumbnail?.source){const im=sheet.querySelector('.cw-region-photo');im.src=d.thumbnail.source;im.hidden=false;}
   if(d.content_urls?.desktop?.page){const a=document.createElement('a');a.href=d.content_urls.desktop.page;a.target='_blank';a.rel='noopener noreferrer';a.textContent='Відкрити статтю у Вікіпедії';sheet.querySelector('.cw-region-facts').append(a);}
  }else sheet.querySelector('.cw-region-summary').textContent='Довідкова стаття недоступна.';
 }catch(e){sheet.querySelector('.cw-region-summary').textContent='Не вдалося завантажити довідкову статтю.';}
 try{
  const d=await cwApi('/api/game/region/'+encodeURIComponent(key)+'/profile?name='+encodeURIComponent(name)+'&country='+encodeURIComponent(country));
  document.getElementById('cwRegPopulation').textContent=Number(d.residents||0).toLocaleString('uk-UA');
  document.getElementById('cwRegGovernor').textContent=d.governor||'Не призначений';
  document.getElementById('cwRegBudget').textContent=Number(d.profile?.budget||0).toLocaleString('uk-UA')+' зол.';
  document.getElementById('cwRegParties').textContent=String(d.parties||0);
  document.getElementById('cwRegAcademies').textContent=String(d.academies||0);
  const p=d.profile||{};document.getElementById('cwRegIndexes').textContent='Медицина '+p.health_index+'/10 · Оборона '+p.defense_index+'/10 · Освіта '+p.education_index+'/10 · Розвиток '+p.development_index+'/10';
  const decree=document.getElementById('cwRegDecree');
  if((d.presidentStates||[]).length){
   decree.innerHTML='<h3>Указ Президента</h3><label>Держава</label><select id="cwDecreeState"></select><label>Нікнейм нового губернатора</label><input id="cwDecreeGovernor" maxlength="24" placeholder="Нікнейм гравця"><button id="cwIssueDecree" class="primary" type="button">Видати указ про призначення</button>';
   const sel=decree.querySelector('#cwDecreeState');d.presidentStates.forEach(st=>{const o=document.createElement('option');o.value=st.id;o.textContent=st.name;sel.append(o);});
   decree.querySelector('#cwIssueDecree').onclick=async()=>{try{const result=await cwApi('/api/game/region/'+encodeURIComponent(key)+'/decree',{method:'POST',body:JSON.stringify({stateId:sel.value,nickname:decree.querySelector('#cwDecreeGovernor').value,decreeText:'Указ Президента про призначення губернатора регіону «'+name+'»'})});notify('Указ видано. Губернатор: '+result.decree.governor);cwShowRegionProfile(name,country,feature);}catch(e){notify(e.message);}};
  }else if(d.latestDecree){decree.textContent='Останній указ: '+d.latestDecree.decree_text+' · '+d.latestDecree.governor;}
  else decree.textContent='Призначати губернатора може Президент держави, до складу якої входить цей регіон.';
 }catch(e){console.warn('Region profile API',e);document.getElementById('cwRegDecree').textContent='Не вдалося завантажити ігрові показники. Перевір підключення до сервера.';}
 const neighbors=cwFindNeighborRegions(feature).slice(0,8),box=document.getElementById('cwRegNeighbors');box.replaceChildren();
 if(!neighbors.length){box.textContent='Для цього регіону не знайдено спільних меж серед завантажених регіонів.';return;}
 const rows=await Promise.all(neighbors.map(async f=>({f,coat:await cwVerifiedCoat(featureName(f),f.properties?.CW_COUNTRY||'Європа')})));
 rows.forEach(({f,coat})=>{const row=document.createElement('div');row.className='cw-neighbor-row';const img=document.createElement('img');img.alt=coat?'Герб за Wikidata P94':'Офіційний герб не підтверджено';img.src=coat?.src||'';if(!coat)img.hidden=true;const info=document.createElement('div');const title=document.createElement('b');title.textContent=featureName(f);const sub=document.createElement('small');sub.textContent=f.properties?.CW_COUNTRY||'Європа';info.append(title,sub);if(coat){const lic=document.createElement('small');lic.textContent='Герб: '+coat.title+' · '+coat.license;info.append(lic);}else{const no=document.createElement('small');no.textContent='Перевірений герб не знайдено';info.append(no);}row.append(img,info);box.append(row);});
}
function showSelectedRegion(name,level){
  const p=window.cwSelectedFeature?.properties||{};
  const iso=p.CW_ISO||'EU';
  const country=p.CW_COUNTRY||'Європа';
  const key=p.CW_REGION_KEY||`${iso}:${featureCode(window.cwSelectedFeature||{})||name}`;
  selectedRegionLabel=`${country} / ${name}`;
  selectedRegionKey=selectedRegionLabel;
  window.cwSelectedRegion={key,name};
  const flightName=document.getElementById('cwFlightRegionName');if(flightName)flightName.value=name;
  const flightKey=document.getElementById('cwFlightRegionKey');if(flightKey)flightKey.value=key;
  selectedMapTerritory={name,key,level};
  if(window.cwRefreshRegionalPolitics)window.cwRefreshRegionalPolitics();
  const card=document.getElementById('regionCard');
  document.getElementById('regionTitle').textContent=name;
  document.getElementById('regionLevel').textContent='Адміністративний регіон';
  document.getElementById('regionDescription').textContent=selectedRegionLabel;
  document.getElementById('createPartyBtn').disabled=false;
  document.getElementById('electionBtn').disabled=false;
  renderParties();
  card.scrollIntoView({behavior:'smooth',block:'nearest'});
  cwShowRegionProfile(name,p.CW_COUNTRY||'Європа',window.cwSelectedFeature);
  if(window.cwRefreshMine)window.cwRefreshMine();
}
function addRegionMap(data){
  if(regionLayer)map.removeLayer(regionLayer);
  allRegionFeatures=data.features||[];
  regionLayer=L.geoJSON(data,{
    style:layerStyle,
    onEachFeature:(feature,layer)=>{
      const p=feature.properties||{};
      const name=featureName(feature);
      const country=p.CW_COUNTRY||'Європа';
      layer.bindTooltip(name,{sticky:true,direction:'auto'});
      layer.bindPopup(`<b>${safeText(name)}</b><br><small>${safeText(country)}</small><br><button class="map-popup-action" data-name="${safeText(name)}">Обрати регіон</button>`);
      layer.on('click',()=>{
        window.cwSelectedFeature=feature;
        currentLevel='regions';
        if(regionLayer)regionLayer.resetStyle();
        layer.setStyle(selectedStyle());
        setStatus(`${country} / ${name}`);
        showSelectedRegion(name,'Регіон');
      });
    }
  }).addTo(map);
  if(regionLayer.getLayers().length)map.fitBounds(regionLayer.getBounds(),{padding:[4,4]});
}
async function loadEuropeRegions(){
  setStatus('Європа · завантаження регіонів…');
  const source='https://raw.githubusercontent.com/datasets/geo-nuts-administrative-boundaries/main/data/NUTS_RG_60M_2024_4326_LEVL_2.geojson';
  const regionIds=new Set([
    'PL21','PL22','PL41','PL42','PL43','PL51','PL52','PL61','PL62','PL63','PL71','PL72','PL81','PL82','PL84','PL91','PL92',
    'RO11','RO12','RO21','RO22','RO31','RO32','RO41','RO42',
    'BG31','BG32','BG33','BG34','BG41','BG42',
    'CZ01','CZ02','CZ03','CZ04','CZ05','CZ06','CZ07','CZ08',
    'HU11','HU12','HU21','HU22','HU23','HU31','HU32','HU33',
    'SK01','SK02','SK03','SK04','HR02','HR03','HR05','SI03','SI04','EE00','LV00','LT01','LT02'
  ]);
  try{
    const response=await fetch(source,{cache:'force-cache'});
    if(!response.ok)throw new Error('Regional dataset unavailable');
    const dataset=await response.json();
    const countries={PL:'Польща',RO:'Румунія',BG:'Болгарія',CZ:'Чехія',HU:'Угорщина',SK:'Словаччина',HR:'Хорватія',SI:'Словенія',EE:'Естонія',LV:'Латвія',LT:'Литва',IT:'Італія',AT:'Австрія',DE:'Німеччина'};
    const features=(dataset.features||[]).filter(f=>regionIds.has(f.properties?.NUTS_ID)||['IT','AT','DE'].includes(f.properties?.CNTR_CODE)).map(f=>{
      f.properties=f.properties||{};
      const id=f.properties.NUTS_ID;
      const iso=f.properties.CNTR_CODE;
      f.properties.NAME=f.properties.NAME_LATN||id;
      f.properties.CW_ISO=iso;
      f.properties.CW_COUNTRY=countries[iso]||iso;
      f.properties.CW_REGION_KEY='NUTS:'+id;
      f.properties.REGION_ID=id;
      return f;
    });
    if(features.length<60)throw new Error(`Недостатньо регіонів у наборі: ${features.length}`);
    addRegionMap({type:'FeatureCollection',features});
    setStatus(`Європа · ${features.length} регіонів · Італія, Австрія, Німеччина включені`);
    notify('Завантажено базові регіони Європи. Обирай область на карті.');
    // First-level administrative boundaries for Ukraine, Moldova and Belarus.
    // Load in parallel, then render once so the three countries appear together.
    const extraCountries=['UKR','MDA','BLR'];
    const labels={UKR:'Україна',MDA:'Молдова',BLR:'Білорусь'};
    const extraResults=await Promise.allSettled([fetchUkraineRegions(),fetchGeoBoundaries('MDA','ADM1'),fetchGeoBoundaries('BLR','ADM1')]);
    const extraCounts={};
    extraResults.forEach((result,index)=>{
      const iso=extraCountries[index];
      if(result.status!=='fulfilled'){
        console.warn(`${iso} administrative regions unavailable`,result.reason);
        return;
      }
      const countryFeatures=result.value.features||[];
      extraCounts[iso]=countryFeatures.length;
      for(const f of countryFeatures){
        f.properties=f.properties||{};
        const p=f.properties;
        const localName=p.shapeName||p.shapeName_en||p.NAME_1||p.NAME_2||p.name||p.name_uk||p.NAME||featureName(f);
        p.CW_ISO=iso;p.CW_COUNTRY=labels[iso];
        p.CW_REGION_KEY=`${iso}:${p.shapeID||p.shapeISO||p.GID_1||p.id||localName}`;
        p.NAME=localName;
        features.push(f);
      }
    });
    let missing=extraCountries.filter(iso=>!extraCounts[iso]);
    // Secondary static fallback for Moldova/Belarus if GeoBoundaries metadata/API is unavailable.
    // Use only real subnational polygons, never a country outline presented as an administrative region.
    if(missing.includes('MDA')||missing.includes('BLR')){
      try{
        const nr=await fetch('https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_1_states_provinces.geojson',{cache:'force-cache'});
        if(nr.ok){const nd=await nr.json();for(const iso of ['MDA','BLR']){if(!missing.includes(iso))continue;
          const matches=(nd.features||[]).filter(f=>String(f.properties?.adm0_a3||f.properties?.ADM0_A3||'').toUpperCase()===iso);
          if(matches.length>1){for(const f of matches){f.properties=f.properties||{};const p=f.properties;const nm=p.name||p.NAME||p.name_en||featureName(f);p.CW_ISO=iso;p.CW_COUNTRY=labels[iso];p.NAME=nm;p.CW_REGION_KEY=iso+':'+(p.iso_3166_2||p.postal||nm);features.push(f);}extraCounts[iso]=matches.length;}
        }}
      }catch(e){console.warn('Natural Earth fallback unavailable',e);}
    }
    missing=extraCountries.filter(iso=>!extraCounts[iso]);
    addRegionMap({type:'FeatureCollection',features});
    const added=extraCountries.filter(iso=>extraCounts[iso]).map(iso=>`${labels[iso]}: ${extraCounts[iso]}`).join(' · ');
    if(missing.length){
      setStatus(`Європа · ${features.length} регіонів · не завантажено: ${missing.map(iso=>labels[iso]).join(', ')}`);
      const regionStat=document.getElementById('cwStatRegions');if(regionStat)regionStat.textContent=features.length.toLocaleString('uk-UA');
      notify(`Додано ${added||'базові регіони'}. Частина нових меж недоступна — перевір інтернет.`);
    }else{
      setStatus(`Європа · ${features.length} регіонів · ${added}`);
      const regionStat=document.getElementById('cwStatRegions');if(regionStat)regionStat.textContent=features.length.toLocaleString('uk-UA');
      notify(`Мапа готова: ${features.length} регіонів, включно з Україною, Молдовою та Білоруссю.`);
    }
  }catch(error){
    console.error('Europe regions map:',error);
    setStatus('Не вдалося завантажити набір регіонів. Перевір підключення до інтернету.');
    notify('Не вдалося завантажити мапу. Спробуй оновити сторінку.');
  }
}
function startWorldMap(){
  map=L.map('worldMap',{worldCopyJump:false,minZoom:3,maxZoom:10,maxBounds:[[33,-25],[72,45]],maxBoundsViscosity:.85,zoomControl:false}).setView([53,15],3.6);
  loadEuropeRegions();
  setTimeout(()=>map.invalidateSize(),250);
}
let cwMapStarted=false;
window.cwStartMap=()=>{if(cwMapStarted||!window.L)return;cwMapStarted=true;startWorldMap();};
if(window.L)window.cwStartMap();else notify('Завантажується бібліотека карти…');
function searchMapCountry(){
  const input=document.getElementById('mapCountrySearch');
  const query=(input?.value||'').trim().toLocaleLowerCase('uk');
  if(!query){notify('Введи назву регіону.');return;}
  const match=allRegionFeatures.find(f=>featureName(f).toLocaleLowerCase('uk')===query)
    ||allRegionFeatures.find(f=>featureName(f).toLocaleLowerCase('uk').includes(query));
  if(!match){notify('Регіон не знайдено.');return;}
  window.cwSelectedFeature=match;
  const layer=regionLayer.getLayers().find(l=>l.feature===match);
  if(layer){map.fitBounds(layer.getBounds(),{padding:[20,20],maxZoom:7});layer.fire('click');}
}
document.getElementById('mapCountrySearchBtn')?.addEventListener('click',searchMapCountry);
document.getElementById('mapCountrySearch')?.addEventListener('keydown',event=>{if(event.key==='Enter')searchMapCountry();});
document.addEventListener('click',event=>{
  const button=event.target.closest('.map-popup-action');
  if(!button)return;
  const name=button.dataset.name;
  const match=allRegionFeatures.find(f=>featureName(f)===name);
  if(match){
    window.cwSelectedFeature=match;
    const layer=regionLayer.getLayers().find(l=>l.feature===match);
    if(layer)layer.fire('click');
  }
});
// Regional parties are stored on the shared server.
let selectedRegionKey='';
let selectedRegionLabel='';
async function renderParties(){
 const list=document.getElementById('partyList');if(!list||!selectedRegionKey)return;
 try{const d=await cwApi('/api/game/region/'+encodeURIComponent(selectedRegionKey)+'/politics');
  if(!d.parties?.length){list.innerHTML='<p class="empty-parties">У цьому регіоні ще немає створених партій.</p>';return;}
  list.replaceChildren();d.parties.forEach(p=>{const card=document.createElement('div');card.className='party-item';const name=document.createElement('b');name.textContent=p.name;const meta=document.createElement('small');meta.textContent=(p.members||0)+' учасників · '+(p.ideology||'Напрям не вказано');const open=document.createElement('button');open.className='secondary';open.textContent='Відкрити партію';open.addEventListener('click',()=>cwOpenParty(p.id));card.append(name,meta,open);list.append(card);});
 }catch(e){list.textContent='Не вдалося завантажити партії: '+e.message;}
}
async function cwOpenParty(id){
 try{
  if(!document.getElementById('page-party')?.classList.contains('active'))window.cwActivatePage?.('party');
  const d=await cwApi('/api/game/party/'+encodeURIComponent(id));const p=d.party;
  const host=document.getElementById('cwMyPartyContent');
  if(!host){notify('Сторінка партії ще завантажується.');return;}
  const date=new Date(p.created_at).toLocaleString('uk-UA',{dateStyle:'long',timeStyle:'short'});
  host.replaceChildren();
  const card=document.createElement('section');card.className='cw-card cw-my-party-detail';
  const top=document.createElement('div');top.className='cw-my-party-top';
  const emblem=document.createElement('div');emblem.className='cw-my-party-emblem';
  if(p.emblem_data){const img=document.createElement('img');img.src=p.emblem_data;img.alt='Емблема партії';emblem.append(img);}else emblem.textContent='⚑';
  const facts=document.createElement('div');facts.className='cw-my-party-facts';
  const title=document.createElement('h2');title.textContent=p.name;
  const meta=document.createElement('p');meta.textContent=Number(p.members||0)+' учасників · '+(p.region_name||'Регіон не вказано');
  const leader=document.createElement('p');leader.textContent='Лідер: '+p.leader;
  const ideology=document.createElement('p');ideology.textContent='Ідеологія: '+(p.ideology||'Не вказана');
  facts.append(title,meta,leader,ideology);top.append(emblem,facts);card.append(top);
  const description=document.createElement('p');description.className='cw-my-party-description';description.textContent=p.program||'Опис партії ще не додано.';card.append(description);
  const dateLine=document.createElement('small');dateLine.className='cw-muted';dateLine.textContent='Заснована: '+date;card.append(dateLine);
  const actions=document.createElement('div');actions.className='cw-my-party-actions';
  const isManager=p.isLeader||['leader','admin'].includes(p.myRole);
  const membersBtn=document.createElement('button');membersBtn.className='secondary';membersBtn.textContent='Учасники';
  membersBtn.onclick=async()=>{try{const data=await cwApi('/api/game/party/'+encodeURIComponent(id)+'/members');const box=card.querySelector('.cw-my-party-members');box.replaceChildren();data.members.forEach(m=>{const row=document.createElement('div');row.className='cw-list-item';const name=document.createElement('b');name.textContent=m.nickname;const role=document.createElement('small');role.textContent=m.role==='leader'?'Лідер':(m.role==='admin'?'Адміністратор':'Учасник');row.append(name,role);box.append(row);});if(!data.members.length)box.textContent='Учасників поки немає.';box.hidden=false;}catch(e){notify(e.message);}};
  actions.append(membersBtn);
  if(isManager){
   const invite=document.createElement('button');invite.className='secondary';invite.textContent='Запросити гравця';invite.onclick=async()=>{const nickname=prompt('Введи точний нікнейм гравця:');if(!nickname||!nickname.trim())return;try{await cwApi('/api/game/party/'+encodeURIComponent(id)+'/invite',{method:'POST',body:JSON.stringify({nickname:nickname.trim()})});notify('Запрошення надіслано.');}catch(e){notify(e.message);}};actions.append(invite);
   const emblemBtn=document.createElement('button');emblemBtn.className='secondary';emblemBtn.textContent='Додати / змінити емблему';emblemBtn.onclick=()=>{const input=document.createElement('input');input.type='file';input.accept='image/png,image/jpeg,image/webp';input.setAttribute('aria-label','Обрати емблему з галереї телефону');input.onchange=async()=>{const file=input.files?.[0];if(!file)return;if(!/^image\/(png|jpeg|webp)$/.test(file.type)){notify('Обери PNG, JPG або WebP.');return;}if(file.size>1200000){notify('Файл має бути не більшим за 1,2 МБ.');return;}try{const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file);});await cwApi('/api/game/party/'+encodeURIComponent(id)+'/emblem',{method:'POST',body:JSON.stringify({emblem:data})});notify('Емблему оновлено.');await cwOpenParty(id);}catch(e){notify(e.message);}};input.click();};actions.append(emblemBtn);
   if(p.isLeader){const edit=document.createElement('button');edit.className='secondary';edit.textContent='Редагувати партію';edit.onclick=()=>{const form=card.querySelector('.cw-my-party-edit');form.hidden=!form.hidden;};actions.append(edit);}
  }
  const leave=document.createElement('button');leave.className='secondary cw-my-party-leave';leave.textContent=(p.isLeader&&Number(p.members||0)<=1)?'Розпустити партію':'Вийти з партії';leave.onclick=async()=>{const disband=p.isLeader&&Number(p.members||0)<=1;const message=disband?'Точно розпустити партію? Її буде видалено для всіх.':'Вийти з партії?';if(!confirm(message))return;try{await cwApi('/api/game/party/'+encodeURIComponent(id)+(disband?'/disband':'/leave'),{method:'POST',body:'{}'});notify(disband?'Партію розпущено.':'Ти вийшов із партії.');await cwRenderMyParties();}catch(e){notify(e.message);}};actions.append(leave);card.append(actions);
  const membersBox=document.createElement('div');membersBox.className='cw-my-party-members';membersBox.hidden=true;card.append(membersBox);
  if(isManager){
   const form=document.createElement('div');form.className='cw-my-party-edit';form.hidden=true;
   const nameLabel=document.createElement('label');nameLabel.textContent='Назва партії';const name=document.createElement('input');name.className='economy-select';name.maxLength=50;name.value=p.name;
   const ideologyLabel=document.createElement('label');ideologyLabel.textContent='Ідеологія';const ide=document.createElement('input');ide.className='economy-select';ide.maxLength=60;ide.value=p.ideology||'';
   const descLabel=document.createElement('label');descLabel.textContent='Опис партії';const desc=document.createElement('textarea');desc.className='economy-select';desc.rows=4;desc.maxLength=1000;desc.value=p.program||'';
   const save=document.createElement('button');save.className='primary';save.textContent='Зберегти зміни';save.onclick=async()=>{try{await cwApi('/api/game/party/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify({name:name.value,ideology:ide.value,program:desc.value})});notify('Дані партії збережено.');await cwOpenParty(id); }catch(e){notify(e.message);}};
   form.append(nameLabel,name,ideologyLabel,ide,descLabel,desc,save);card.append(form);
  }
  host.append(card);
  host.scrollIntoView({behavior:'smooth',block:'start'});
 }catch(e){notify(e.message);}
}
async function cwRenderMyParties(){
 const host=document.getElementById('cwMyPartyContent');if(!host)return;
 host.replaceChildren();
 try{
  const d=await cwApi('/api/game/my-parties');
  if(!d.parties?.length){const empty=document.createElement('section');empty.className='cw-card';const h=document.createElement('h2');h.textContent='Ти поки не перебуваєш у партії';const p=document.createElement('p');p.className='cw-muted';p.textContent='Перейди до розділу «Огляд» і обери партію в списку, щоб вступити до неї, або створи власну.';const go=document.createElement('button');go.className='primary';go.textContent='Перейти до партій';go.onclick=()=>{document.querySelector('[data-tab="overview"]')?.click();document.getElementById('regionCard')?.scrollIntoView({behavior:'smooth'});};empty.append(h,p,go);host.append(empty);return;}
  d.parties.forEach(p=>{const row=document.createElement('section');row.className='cw-card cw-my-party-list-item';const h=document.createElement('h3');h.textContent=p.name;const role=document.createElement('small');role.textContent=p.role==='leader'?'Лідер':(p.role==='admin'?'Адміністратор':'Учасник');const open=document.createElement('button');open.className='secondary';open.textContent='Відкрити кабінет партії';open.onclick=()=>cwOpenParty(p.id);row.append(h,role,open);host.append(row);});
 }catch(e){const error=document.createElement('p');error.className='cw-muted';error.textContent='Не вдалося завантажити партії: '+e.message;host.append(error);}
}
const partyModal=document.getElementById('partyModal');
document.getElementById('createPartyBtn').addEventListener('click',()=>{
  if(!selectedRegionKey)return;
  partyModal.classList.add('open');partyModal.setAttribute('aria-hidden','false');
  document.getElementById('partyName').focus();
});
function closePartyModal(){partyModal.classList.remove('open');partyModal.setAttribute('aria-hidden','true');}
document.getElementById('closePartyModal').addEventListener('click',closePartyModal);
partyModal.addEventListener('click',e=>{if(e.target===partyModal)closePartyModal();});
document.getElementById('savePartyBtn').addEventListener('click',async()=>{
 const name=document.getElementById('partyName').value.trim();
 const ideology=document.getElementById('partyIdeology').value;
 const program=document.getElementById('partyProgram').value.trim();
 if(name.length<3){notify('Введи назву партії (від 3 символів).');return;}
 const r=window.cwSelectedRegion;if(!r)return notify('Спочатку обери регіон.');
 try{
  await cwApi('/api/game/region/'+encodeURIComponent(r.key)+'/party',{method:'POST',body:JSON.stringify({name,ideology,program,regionName:r.name})});
  closePartyModal();document.getElementById('partyName').value='';document.getElementById('partyProgram').value='';
  notify('Партію створено за 25 золота.');await cwRefreshMine();if(window.cwRefreshRegionalPolitics)await window.cwRefreshRegionalPolitics();
 }catch(e){notify(e.message);}
});
document.getElementById('electionBtn').addEventListener('click',async()=>{
 const r=window.cwSelectedRegion;if(!r)return notify('Спочатку обери регіон.');
 try{await cwApi('/api/game/region/'+encodeURIComponent(r.key)+'/election',{method:'POST',body:JSON.stringify({name:r.name})});notify('Вибори заплановано.');}
 catch(e){notify(e.message);}
});


// Independent regional economy prototype. Every region has its own separate treasury.
const economyDefaults={
 'Вінницька область':{balance:1000,tax:10,infrastructure:1,turn:0},
 'Київська область':{balance:1400,tax:10,infrastructure:2,turn:0},
 'Львівська область':{balance:1150,tax:10,infrastructure:1,turn:0}
};
let economyData={};
try{economyData=JSON.parse(localStorage.getItem('cw_independent_economy_v1')||'{}')||{};}catch(e){economyData={};}
let activeEconomyRegion='Вінницька область';
function economyFor(name){
 if(!economyData[name])economyData[name]={...economyDefaults[name]||{balance:1000,tax:10,infrastructure:1,turn:0}};
 return economyData[name];
}
function saveEconomy(){try{localStorage.setItem('cw_independent_economy_v1',JSON.stringify(economyData));}catch(e){notify('Не вдалося зберегти економіку на пристрої.');}}
function money(n){return Math.round(n).toLocaleString('uk-UA');}
function incomeFor(e){return Math.round(80+e.infrastructure*40+(e.tax-10)*5);}
function renderEconomy(){
 const e=economyFor(activeEconomyRegion);
 document.getElementById('economyRegion').value=activeEconomyRegion;
 document.getElementById('economyBalance').textContent=money(e.balance);
 document.getElementById('economyIncome').textContent=`Дохід за хід: ${money(incomeFor(e))} CW₵`;
 document.getElementById('taxValue').textContent=e.tax+'%';
 document.getElementById('taxSelect').value=String(e.tax);
 document.getElementById('infraValue').textContent=e.infrastructure+' рівень';
 document.getElementById('econValue').textContent=e.infrastructure>=4?'Розвинена':e.infrastructure>=2?'Зростає':'Початкова';
 document.getElementById('investBtn').disabled=e.balance<250;
}
document.getElementById('economyRegion').addEventListener('change',e=>{
 activeEconomyRegion=e.target.value;renderEconomy();
});
document.getElementById('taxSelect').addEventListener('change',e=>{
 const state=economyFor(activeEconomyRegion);state.tax=Number(e.target.value);saveEconomy();renderEconomy();
 document.getElementById('economyLog').textContent=`Ставку податку для «${activeEconomyRegion}» змінено на ${state.tax}%. Інші регіони не зачеплено.`;
});
document.getElementById('investBtn').addEventListener('click',()=>{
 const e=economyFor(activeEconomyRegion);
 if(e.balance<250){notify('У регіональному бюджеті недостатньо коштів.');return;}
 e.balance-=250;e.infrastructure+=1;saveEconomy();renderEconomy();
 document.getElementById('economyLog').textContent=`${activeEconomyRegion}: інвестиція 250 CW₵. Інфраструктура тепер ${e.infrastructure} рівень.`;
 notify('Інвестицію проведено.');
});
document.getElementById('turnBtn').addEventListener('click',()=>{
 const e=economyFor(activeEconomyRegion);const income=incomeFor(e);
 e.balance+=income;e.turn+=1;saveEconomy();renderEconomy();
 document.getElementById('economyLog').textContent=`Хід №${e.turn}: бюджет «${activeEconomyRegion}» отримав +${money(income)} CW₵.`;
 notify('Економічний хід завершено.');
});
renderEconomy();


// Local state founding and territorial ownership prototype.
const STATE_STORE_KEY='chemis_world_states_v1';
let stateData=[];
try{stateData=JSON.parse(localStorage.getItem(STATE_STORE_KEY)||'[]');if(!Array.isArray(stateData))stateData=[];}catch(e){stateData=[];}
function saveStates(){try{localStorage.setItem(STATE_STORE_KEY,JSON.stringify(stateData));}catch(e){notify('Не вдалося зберегти держави на пристрої.');}}
function territoryKey(){return selectedRegionKey||'';}
function stateForTerritory(key){return stateData.find(s=>s.territories.includes(key));}
function renderStates(){
 const list=document.getElementById('stateList');
 if(!stateData.length)list.innerHTML='<p class="empty-parties">Поки що держав не створено.</p>';
 else list.innerHTML=stateData.map(s=>`<div class="state-item"><div class="state-flag" style="background:${safeText(s.color)}">${safeText(s.symbol)}</div><div><b>${safeText(s.name)}</b><small>Столиця: ${safeText(s.capital)} · Територій: ${s.territories.length}</small></div></div>`).join('');
 const select=document.getElementById('joinStateSelect');
 select.innerHTML=stateData.length?'<option value="">Обери державу</option>'+stateData.map(s=>`<option value="${safeText(s.id)}">${safeText(s.name)}</option>`).join(''):'<option value="">Спочатку створи державу</option>';
 const key=territoryKey(), owned=key?stateForTerritory(key):null;
 document.getElementById('createStateBtn').disabled=!key||!!owned;
 document.getElementById('joinStateBtn').disabled=!key||!!owned||!stateData.length;
 document.getElementById('stateStatus').textContent=owned?`Обрана територія вже входить до держави «${owned.name}».`:(key?'Обрана територія вільна та може стати основою нової держави або приєднатися до наявної.':'Спочатку обери область або район на карті.');
}
function openStateModal(){document.getElementById('stateModal').classList.add('open');document.getElementById('stateModal').setAttribute('aria-hidden','false');}
function closeStateModal(){document.getElementById('stateModal').classList.remove('open');document.getElementById('stateModal').setAttribute('aria-hidden','true');}
document.getElementById('createStateBtn').addEventListener('click',openStateModal);
document.getElementById('closeStateModal').addEventListener('click',closeStateModal);
document.getElementById('saveStateBtn').addEventListener('click',()=>{
 const name=document.getElementById('stateName').value.trim();
 const capital=document.getElementById('stateCapital').value.trim();
 const symbol=document.getElementById('stateSymbol').value.trim()||'★';
 if(!name||!capital){notify('Вкажи назву держави та столицю.');return;}
 if(!territoryKey()){notify('Спочатку обери територію на карті.');return;}
 if(stateForTerritory(territoryKey())){notify('Ця територія вже належить іншій державі.');return;}
 stateData.push({id:'state_'+Date.now(),name,capital,symbol,color:document.getElementById('stateFlag').value,territories:[territoryKey()],createdAt:new Date().toISOString()});
 saveStates();renderStates();closeStateModal();
 document.getElementById('stateName').value='';document.getElementById('stateCapital').value='';
 notify(`Державу «${name}» засновано в ігровому прототипі.`);
});
document.getElementById('joinStateBtn').addEventListener('click',()=>{
 const key=territoryKey(),id=document.getElementById('joinStateSelect').value;
 const target=stateData.find(s=>s.id===id);
 if(!key||!target)return;
 if(stateForTerritory(key)){notify('Територія вже має власника.');return;}
 target.territories.push(key);saveStates();renderStates();
 document.getElementById('stateStatus').textContent=`Територію додано до «${target.name}».`;
 notify('Територію приєднано до держави.');
});
const previousShowSelectedRegion=showSelectedRegion;
showSelectedRegion=function(name,level){previousShowSelectedRegion(name,level);renderStates();};
renderStates();


// Local governance prototype: one cabinet and parliament record per player-created state.
let activeGovStateId='';
function selectedGovState(){return stateData.find(s=>s.id===activeGovStateId)||null;}
function ensureGovernance(s){
 if(!s.governance)s.governance={leader:'',seats:30,ministers:{},laws:[]};
 if(!s.governance.ministers)s.governance.ministers={};
 if(!s.governance.laws)s.governance.laws=[];
 return s.governance;
}
function renderGovernment(){
 const select=document.getElementById('govStateSelect');
 const prior=activeGovStateId;
 select.innerHTML=stateData.length?'<option value="">Обери державу</option>'+stateData.map(s=>`<option value="${safeText(s.id)}">${safeText(s.name)}</option>`).join(''):'<option value="">Спочатку створи державу</option>';
 if(stateData.some(s=>s.id===prior))select.value=prior;else activeGovStateId='';
 const s=selectedGovState(),empty=document.getElementById('govEmpty'),work=document.getElementById('govWorkspace');
 empty.hidden=!!s;work.hidden=!s;
 if(!s)return;
 const g=ensureGovernance(s);
 document.getElementById('govLeaderName').textContent=g.leader||'Не призначено';
 document.getElementById('leaderInput').value=g.leader||'';
 document.getElementById('parliamentSeats').textContent=g.seats;
 document.getElementById('lawCount').textContent=g.laws.filter(l=>l.status==='Ухвалено').length;
 document.getElementById('seatsInput').value=g.seats;
 document.getElementById('ministryList').innerHTML=Object.keys(g.ministers).length?Object.entries(g.ministers).map(([m,n])=>`<div class="ministry-item"><b>Міністерство ${safeText(m)}</b><small>Міністр: ${safeText(n)}</small></div>`).join(''):'<div class="data-note">Міністрів ще не призначено.</div>';
 document.getElementById('lawList').innerHTML=g.laws.length?g.laws.map((l,i)=>`<div class="law-item"><b>${safeText(l.title)}</b><small>Статус: ${safeText(l.status)}</small><p>${safeText(l.description)}</p>${l.status==='На розгляді'?`<div class="law-actions"><button data-law-action="pass" data-law-index="${i}">Ухвалити</button><button data-law-action="reject" data-law-index="${i}">Відхилити</button></div>`:''}</div>`).join(''):'<div class="data-note">Законопроєктів поки немає.</div>';
 saveStates();
}
document.getElementById('govStateSelect').addEventListener('change',e=>{activeGovStateId=e.target.value;renderGovernment();});
document.getElementById('saveLeaderBtn').addEventListener('click',()=>{
 const s=selectedGovState();if(!s)return;const value=document.getElementById('leaderInput').value.trim();
 if(!value){notify('Вкажи ім’я глави держави.');return;}
 ensureGovernance(s).leader=value;saveStates();renderGovernment();notify('Главу держави збережено.');
});
document.getElementById('saveSeatsBtn').addEventListener('click',()=>{
 const s=selectedGovState();if(!s)return;const n=Number(document.getElementById('seatsInput').value);
 if(!Number.isInteger(n)||n<10||n>500){notify('Парламент має мати від 10 до 500 місць.');return;}
 ensureGovernance(s).seats=n;saveStates();renderGovernment();notify('Склад парламенту оновлено.');
});
document.getElementById('appointMinisterBtn').addEventListener('click',()=>{
 const s=selectedGovState();if(!s)return;const name=document.getElementById('ministerInput').value.trim();
 if(!name){notify('Вкажи ім’я міністра.');return;}
 const g=ensureGovernance(s);g.ministers[document.getElementById('ministrySelect').value]=name;
 saveStates();renderGovernment();document.getElementById('ministerInput').value='';notify('Міністра призначено.');
});
document.getElementById('proposeLawBtn').addEventListener('click',()=>{
 const s=selectedGovState();if(!s)return;
 const title=document.getElementById('lawTitleInput').value.trim(),description=document.getElementById('lawTextInput').value.trim();
 if(title.length<3||description.length<5){notify('Додай назву та короткий опис законопроєкту.');return;}
 ensureGovernance(s).laws.push({title,description,status:'На розгляді',createdAt:new Date().toISOString()});
 saveStates();renderGovernment();document.getElementById('lawTitleInput').value='';document.getElementById('lawTextInput').value='';
 notify('Законопроєкт внесено на розгляд.');
});
document.getElementById('lawList').addEventListener('click',e=>{
 const b=e.target.closest('[data-law-action]');if(!b)return;
 const s=selectedGovState();if(!s)return;
 const g=ensureGovernance(s),law=g.laws[Number(b.dataset.lawIndex)];if(!law||law.status!=='На розгляді')return;
 law.status=b.dataset.lawAction==='pass'?'Ухвалено':'Відхилено';
 saveStates();renderGovernment();notify(law.status==='Ухвалено'?'Законопроєкт ухвалено в демоверсії.':'Законопроєкт відхилено.');
});
const oldRenderStates=renderStates;
renderStates=function(){oldRenderStates();renderGovernment();};
renderGovernment();


// Local diplomacy prototype: agreements are records between two player-created states.
const DIPLOMACY_KEY='chemis_world_diplomacy_v1';
let diplomacyData={relations:[],reputation:{}};
try{const saved=JSON.parse(localStorage.getItem(DIPLOMACY_KEY)||'null');if(saved&&typeof saved==='object')diplomacyData={...diplomacyData,...saved};}catch(e){}
function saveDiplomacy(){try{localStorage.setItem(DIPLOMACY_KEY,JSON.stringify(diplomacyData));}catch(e){notify('Не вдалося зберегти дипломатичні дані.');}}
function reputationFor(id){if(diplomacyData.reputation[id]===undefined)diplomacyData.reputation[id]=50;return diplomacyData.reputation[id];}
function stateNameById(id){return stateData.find(s=>s.id===id)?.name||'Невідома держава';}
function renderDiplomacy(){
 const from=document.getElementById('diplomacyFrom'),to=document.getElementById('diplomacyTo');
 const options=stateData.map(s=>`<option value="${safeText(s.id)}">${safeText(s.name)}</option>`).join('');
 const oldFrom=from.value,oldTo=to.value;
 from.innerHTML=stateData.length?'<option value="">Обери державу</option>'+options:'<option value="">Створи держави</option>';
 to.innerHTML=stateData.length>1?'<option value="">Обери іншу державу</option>'+options:'<option value="">Потрібні дві держави</option>';
 if(stateData.some(s=>s.id===oldFrom))from.value=oldFrom;
 if(stateData.some(s=>s.id===oldTo))to.value=oldTo;
 updateDiplomacyPair();
 const list=document.getElementById('diplomacyList');
 if(!diplomacyData.relations.length)list.innerHTML='<p class="empty-parties">Поки що міжнародних угод немає.</p>';
 else list.innerHTML=diplomacyData.relations.slice().reverse().map((r,i)=>{
  const realIndex=diplomacyData.relations.length-1-i;
  const status=r.status==='Пропозиція'?'Очікує відповіді':r.status;
  const controls=r.status==='Пропозиція'?`<button data-dip-action="accept" data-dip-index="${realIndex}">Прийняти</button><button data-dip-action="decline" data-dip-index="${realIndex}">Відхилити</button>`:'';
  return `<div class="diplomacy-item"><b>${safeText(r.label)}</b><small>${safeText(stateNameById(r.from))} → ${safeText(stateNameById(r.to))} · ${safeText(status)}</small><p>${safeText(r.description)}</p>${controls}</div>`;
 }).join('');
 saveDiplomacy();
}
function updateDiplomacyPair(){
 const a=document.getElementById('diplomacyFrom').value,b=document.getElementById('diplomacyTo').value;
 document.getElementById('repFromName').textContent=a?stateNameById(a):'Держава 1';
 document.getElementById('repToName').textContent=b?stateNameById(b):'Держава 2';
 document.getElementById('repFromValue').textContent=a?`${reputationFor(a)} / 100`:'—';
 document.getElementById('repToValue').textContent=b?`${reputationFor(b)} / 100`:'—';
 document.querySelectorAll('[data-diplomacy]').forEach(btn=>btn.disabled=!a||!b||a===b);
}
document.getElementById('diplomacyFrom').addEventListener('change',updateDiplomacyPair);
document.getElementById('diplomacyTo').addEventListener('change',updateDiplomacyPair);
const diplomacyTypes={
 relations:{label:'Дипломатичні відносини',description:'Сторони започаткували офіційний дипломатичний діалог.'},
 trade:{label:'Торговельна угода',description:'Пропозиція про взаємну торгівлю та економічну співпрацю. Угода не об’єднує регіональні бюджети.'},
 alliance:{label:'Міждержавний союз',description:'Пропозиція про довгострокову політичну співпрацю та консультації.'},
 recognition:{label:'Визнання держави',description:'Держава-ініціатор визнає незалежність і державний статус партнера.'}
};
document.querySelectorAll('[data-diplomacy]').forEach(btn=>btn.addEventListener('click',()=>{
 const from=document.getElementById('diplomacyFrom').value,to=document.getElementById('diplomacyTo').value;
 if(!from||!to||from===to){notify('Обери дві різні держави.');return;}
 const type=btn.dataset.diplomacy,meta=diplomacyTypes[type];
 if(type==='relations'&&diplomacyData.relations.some(r=>r.type===type&&((r.from===from&&r.to===to)||(r.from===to&&r.to===from))&&r.status==='Діють')){
  notify('Дипломатичні відносини вже встановлені.');return;
 }
 diplomacyData.relations.push({id:'dip_'+Date.now(),type,from,to,label:meta.label,description:meta.description,status:'Пропозиція',createdAt:new Date().toISOString()});
 saveDiplomacy();renderDiplomacy();notify('Дипломатичну пропозицію створено.');
}));
document.getElementById('diplomacyList').addEventListener('click',e=>{
 const btn=e.target.closest('[data-dip-action]');if(!btn)return;
 const r=diplomacyData.relations[Number(btn.dataset.dipIndex)];if(!r||r.status!=='Пропозиція')return;
 if(btn.dataset.dipAction==='accept'){
  r.status='Діють';
  if(r.type==='recognition')diplomacyData.reputation[r.to]=Math.min(100,reputationFor(r.to)+5);
  if(r.type==='trade') {diplomacyData.reputation[r.from]=Math.min(100,reputationFor(r.from)+2);diplomacyData.reputation[r.to]=Math.min(100,reputationFor(r.to)+2);}
  if(r.type==='alliance'){diplomacyData.reputation[r.from]=Math.min(100,reputationFor(r.from)+3);diplomacyData.reputation[r.to]=Math.min(100,reputationFor(r.to)+3);}
  notify('Пропозицію прийнято.');
 }else{r.status='Відхилено';notify('Пропозицію відхилено.');}
 saveDiplomacy();renderDiplomacy();
});
const oldRenderStatesForDip=renderStates;
renderStates=function(){oldRenderStatesForDip();renderDiplomacy();};
renderDiplomacy();
// v0.9.0 local player profile foundation. No server accounts or real online directory yet.
const PLAYER_KEY='chemis_world_player_profile_v1';
function makePlayerCode(){return 'CW-'+Math.random().toString(36).slice(2,8).toUpperCase();}
let playerProfile={nick:'',bio:'',region:'',code:makePlayerCode(),createdAt:new Date().toISOString()};
try{const p=JSON.parse(localStorage.getItem(PLAYER_KEY)||'null');if(p&&typeof p==='object')playerProfile={...playerProfile,...p};}catch(e){}
function renderPlayerProfile(){
 document.getElementById('accountNick').value=playerProfile.nick||'';
 document.getElementById('accountBio').value=playerProfile.bio||'';
 document.getElementById('accountRegion').value=playerProfile.region||'';
 document.getElementById('accountNickView').textContent=playerProfile.nick||'Новий гравець';
 document.getElementById('accountCodeView').textContent='Код: '+playerProfile.code;
 document.getElementById('accountBioView').textContent=playerProfile.bio||'Профіль ще не налаштовано';
 document.getElementById('accountAvatar').textContent=(playerProfile.nick||'?').trim().charAt(0).toUpperCase()||'?';
 document.getElementById('playerCode').textContent=playerProfile.code;
}
document.getElementById('saveAccountBtn').addEventListener('click',async()=>{
 const nick=document.getElementById('accountNick').value.trim();
 if(nick.length<3){notify('Нікнейм має містити щонайменше 3 символи.');return;}
 playerProfile.nick=nick;playerProfile.bio=document.getElementById('accountBio').value.trim();
 playerProfile.region=document.getElementById('accountRegion').value.trim();
 try{localStorage.setItem(PLAYER_KEY,JSON.stringify(playerProfile));renderPlayerProfile();
  if(localStorage.getItem(CW_SESSION_TOKEN_KEY)){await cwApi('/api/me',{method:'PATCH',body:JSON.stringify({nickname:nick,bio:playerProfile.bio,homeRegion:playerProfile.region})});document.getElementById('accountNickView').textContent=nick;}
  notify('Профіль збережено. Нікнейм безкоштовний.');
 }catch(e){notify('Не вдалося зберегти профіль: '+e.message);}
});
document.getElementById('copyPlayerCode').addEventListener('click',()=>{
 const code=playerProfile.code;
 if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(code).then(()=>notify('Код скопійовано.')).catch(()=>notify('Код гравця: '+code));
 else notify('Код гравця: '+code);
});
document.querySelectorAll('[data-name="Профіль"]').forEach(el=>el.addEventListener('click',()=>document.getElementById('accountCard').scrollIntoView({behavior:'smooth',block:'center'})));
document.querySelectorAll('[data-name="Гравці"]').forEach(el=>el.addEventListener('click',()=>document.getElementById('accountCard').scrollIntoView({behavior:'smooth',block:'center'})));
renderPlayerProfile();

// v1.0.0 online API client. Requires a deployed HTTPS backend; no secrets are embedded here.
const CW_API_URL_KEY='cw_api_base_url_v1';
const CW_SESSION_TOKEN_KEY='cw_guest_session_token_v1';
const CW_GUEST_KEY='cw_guest_device_key_v1';
const cwApiInput=document.getElementById('apiBaseUrl');
const cwOnlineStatus=document.getElementById('onlineStatus');
const cwOnlinePanel=document.getElementById('onlinePlayerPanel');
cwApiInput.value=localStorage.getItem(CW_API_URL_KEY)||(location.protocol==='https:'||location.protocol==='http:'?location.origin:'https://chemisworld.onrender.com');
function cwApiBase(){
 const value=cwApiInput.value.trim().replace(/\/+$/,'');
 if(!/^https:\/\/[a-z0-9.-]+(?::\d+)?$/i.test(value))throw new Error('Вкажи коректну HTTPS-адресу сервера.');
 localStorage.setItem(CW_API_URL_KEY,value);return value;
}
function cwSetOnlineStatus(message){cwOnlineStatus.textContent=message;}
let cwGuestInitPromise=null;
function cwGuestDeviceKey(){
 let key=localStorage.getItem(CW_GUEST_KEY);
 if(!key){key=(window.crypto&&crypto.randomUUID)?crypto.randomUUID().replace(/-/g,''):Array.from({length:4},()=>Math.random().toString(16).slice(2,10)).join('');localStorage.setItem(CW_GUEST_KEY,key);}
 return key;
}
async function cwEnsureGuestSession(){
 if(cwGuestInitPromise)return cwGuestInitPromise;
 cwGuestInitPromise=(async()=>{
  const savedToken=localStorage.getItem(CW_SESSION_TOKEN_KEY);
  if(savedToken){
   const check=await fetch(cwApiBase()+'/api/me',{headers:{Authorization:'Bearer '+savedToken}});
   if(check.ok){const data=await check.json();cwOnlinePanel.hidden=false;const nick=document.getElementById('accountNick');if(nick&&!nick.value)nick.value=data.player.nickname;const view=document.getElementById('accountNickView');if(view&&!playerProfile.nick)view.textContent=data.player.nickname;cwSetOnlineStatus('Акаунт активний · '+data.player.nickname+'.');return data;}
   localStorage.removeItem(CW_SESSION_TOKEN_KEY);
  }
  const response=await fetch(cwApiBase()+'/api/auth/guest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({guestKey:cwGuestDeviceKey()})});
  const data=await response.json().catch(()=>({}));
  if(!response.ok||!data.token)throw new Error(data.error||'Не вдалося створити гостьовий профіль.');
  localStorage.setItem(CW_SESSION_TOKEN_KEY,data.token);
  cwOnlinePanel.hidden=false;
  const nick=document.getElementById('accountNick');if(nick&&!nick.value)nick.value=data.player.nickname;
  const view=document.getElementById('accountNickView');if(view&&!playerProfile.nick)view.textContent=data.player.nickname;
  cwSetOnlineStatus('Гостьовий режим активний · '+data.player.nickname+'. Реєстрація не потрібна.');
  const gold=document.getElementById('cwGold');if(gold&&gold.textContent==='—')gold.textContent='500';
  return data;
 })().catch(error=>{cwGuestInitPromise=null;cwSetOnlineStatus('Не вдалося під’єднатися до сервера: '+error.message);throw error;});
 return cwGuestInitPromise;
}
async function cwAccountAction(mode){
 const nickname=document.getElementById('cwAccountName')?.value.trim()||'';
 const password=document.getElementById('cwAccountPassword')?.value||'';
 try{
  let data;
  if(mode==='upgrade'){
   await cwEnsureGuestSession();
   const token=localStorage.getItem(CW_SESSION_TOKEN_KEY);
   const r=await fetch(cwApiBase()+'/api/auth/upgrade',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:JSON.stringify({nickname,password})});
   data=await r.json();if(!r.ok)throw new Error(data.error||'Не вдалося створити акаунт.');
  }else{
   const r=await fetch(cwApiBase()+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nickname,password})});
   data=await r.json();if(!r.ok)throw new Error(data.error||'Не вдалося увійти.');
  }
  localStorage.setItem(CW_SESSION_TOKEN_KEY,data.token);
  cwGuestInitPromise=Promise.resolve(data);
  const v=document.getElementById('accountNickView');if(v)v.textContent=data.player.nickname;
  const n=document.getElementById('accountNick');if(n)n.value=data.player.nickname;
  const status=document.getElementById('onlineStatus');if(status)status.textContent='Акаунт активний: '+data.player.nickname;
  notify(mode==='upgrade'?'Акаунт створено. Прогрес гостьового профілю збережено.':'Вхід виконано.');
  await cwRefreshPlayers();await cwRefreshGameProfile();
 }catch(e){notify(e.message);}
}
async function cwPublicApi(path,options={}){
 const response=await fetch(cwApiBase()+path,{...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});
 const data=await response.json().catch(()=>({}));
 if(!response.ok)throw new Error(data.error||'Помилка сервера ('+response.status+').');
 return data;
}
document.getElementById('cwCreateAccountBtn')?.addEventListener('click',()=>cwAccountAction('upgrade'));
document.getElementById('cwLoginBtn')?.addEventListener('click',()=>cwAccountAction('login'));
async function cwApi(path,options={}){
 await cwEnsureGuestSession();
 const token=localStorage.getItem(CW_SESSION_TOKEN_KEY);
 const headers={'Content-Type':'application/json',...(options.headers||{})};
 if(token)headers.Authorization='Bearer '+token;
 const response=await fetch(cwApiBase()+path,{...options,headers});
 const data=await response.json().catch(()=>({}));
 if(!response.ok)throw new Error(data.error||'Помилка сервера ('+response.status+').');
 return data;
}
document.getElementById('playerSearchBtn').addEventListener('click',async()=>{
 try{
  const q=encodeURIComponent(document.getElementById('playerSearchInput').value.trim());
  const data=await cwApi('/api/players?q='+q);
  const list=document.getElementById('onlinePlayersList');
  list.replaceChildren();
  if(!data.players.length){list.textContent='Гравців не знайдено.';return;}
  data.players.forEach(player=>{
   const item=document.createElement('div');item.className='online-player';
   const name=document.createElement('b');name.textContent=player.nickname;
   const meta=document.createElement('small');meta.textContent=player.home_region||'Регіон не вказано';
   const bio=document.createElement('small');bio.textContent=player.bio||'';
   item.append(name,meta,bio);list.append(item);
  });
 }catch(e){cwSetOnlineStatus(e.message);}
});
cwOnlinePanel.hidden=false;cwEnsureGuestSession().then(()=>{if(window.cwRefreshGameProfile)window.cwRefreshGameProfile();}).catch(()=>{});

async function cwRefreshOnlineStates(){
 const data=await cwApi('/api/states');
 const list=document.getElementById('onlineStatesList');list.replaceChildren();
 if(!data.states.length){list.textContent='У спільному реєстрі поки немає держав.';return;}
 data.states.forEach(state=>{
  const item=document.createElement('div');item.className='online-player';
  const title=document.createElement('b');title.textContent=(state.symbol||'★')+' '+state.name;
  const meta=document.createElement('small');meta.textContent='Столиця: '+state.capital+' · Власник: '+state.owner_nickname;
  const count=document.createElement('small');count.textContent='Територій: '+state.territories.length;
  item.append(title,meta,count);list.append(item);
 });
}
document.getElementById('refreshStatesBtn').addEventListener('click',async()=>{
 try{await cwRefreshOnlineStates();cwSetOnlineStatus('Спільний реєстр держав оновлено.');}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('syncStatesBtn').addEventListener('click',async()=>{
 try{
  const [existing,me]=await Promise.all([cwApi('/api/states'),cwApi('/api/me')]);
  const mine=new Set(existing.states.filter(s=>s.owner_id===me.player.id).map(s=>s.name.toLocaleLowerCase()));
  const local=JSON.parse(localStorage.getItem('chemis_world_states_v1')||'[]');
  let published=0,skipped=0;
  for(const s of local){
   if(mine.has(String(s.name).toLocaleLowerCase())){skipped++;continue;}
   await cwApi('/api/states',{method:'POST',body:JSON.stringify({
    name:s.name,capital:s.capital,color:s.color,symbol:s.symbol,territories:s.territories
   })});
   published++;
  }
  await cwRefreshOnlineStates();
  cwSetOnlineStatus(`Публікацію завершено: ${published} держав опубліковано, ${skipped} уже були у твоєму списку.`);
 }catch(e){cwSetOnlineStatus(e.message);}
});

async function cwLoadOnlineStatesIntoPolitics(){
 const data=await cwApi('/api/states');
 const select=document.getElementById('politicsStateSelect'),prior=select.value;
 select.replaceChildren();
 const empty=document.createElement('option');empty.value='';empty.textContent='Обери державу';select.append(empty);
 data.states.forEach(s=>{const o=document.createElement('option');o.value=s.id;o.textContent=s.name+' — '+s.owner_nickname;select.append(o);});
 if(data.states.some(s=>s.id===prior))select.value=prior;
}
async function cwRenderOnlinePolitics(){
 const stateId=document.getElementById('politicsStateSelect').value;
 const list=document.getElementById('onlinePoliticsList');list.replaceChildren();
 if(!stateId){list.textContent='Обери державу для перегляду політичного життя.';return;}
 const data=await cwApi('/api/states/'+encodeURIComponent(stateId)+'/politics');
 const heading=document.createElement('b');heading.textContent='Партії';list.append(heading);
 if(!data.parties.length){const p=document.createElement('p');p.textContent='Партій поки немає.';list.append(p);}
 data.parties.forEach(p=>{
  const item=document.createElement('div');item.className='online-player';
  const name=document.createElement('b');name.textContent=p.name;
  const meta=document.createElement('small');meta.textContent=(p.ideology||'Без зазначеної ідеології')+' · автор: '+p.creator;
  const desc=document.createElement('small');desc.textContent=p.platform||'Програму не додано';
  item.append(name,meta,desc);list.append(item);
 });
 data.elections.forEach(e=>{
  const block=document.createElement('div');block.className='online-player';
  const title=document.createElement('b');title.textContent='Вибори · '+(e.status==='open'?'голосування відкрите':'завершено');block.append(title);
  e.results.forEach(r=>{
   const line=document.createElement('div');line.style.display='flex';line.style.gap='8px';line.style.alignItems='center';
   const label=document.createElement('small');label.textContent=r.party_name+' — '+r.votes+' голосів'+(e.status==='closed'?' · '+(r.seats||0)+' місць':'');line.append(label);
   if(e.status==='open'){
    const btn=document.createElement('button');btn.className='secondary';btn.textContent='Голосувати';
    btn.addEventListener('click',async()=>{try{await cwApi('/api/elections/'+e.id+'/vote',{method:'POST',body:JSON.stringify({partyId:r.party_id})});cwSetOnlineStatus('Голос зараховано.');await cwRenderOnlinePolitics();}catch(err){cwSetOnlineStatus(err.message);}});
    line.append(btn);
   }
   block.append(line);
  });
  if(e.status==='open'){
   const closeBtn=document.createElement('button');closeBtn.className='secondary';closeBtn.textContent='Завершити вибори (власник)';
   closeBtn.addEventListener('click',async()=>{try{await cwApi('/api/elections/'+e.id+'/close',{method:'POST',body:'{}'});cwSetOnlineStatus('Вибори завершено.');await cwRenderOnlinePolitics();}catch(err){cwSetOnlineStatus(err.message);}});
   block.append(closeBtn);
  }
  list.append(block);
 });
 if(data.parliament){
  const ph=document.createElement('b');ph.textContent='Парламент · розподіл 100 місць';list.append(ph);
  data.parliament.seats.forEach(s=>{const line=document.createElement('small');line.textContent=s.party_name+' — '+s.seats+' місць';list.append(line);});
 }else{const p=document.createElement('small');p.textContent='Парламент ще не сформовано: заверши вибори.';list.append(p);}
 if(data.government){
  const gh=document.createElement('b');gh.textContent='Уряд · прем’єр-міністр: '+data.government.prime_minister;list.append(gh);
  data.ministers.forEach(m=>{const line=document.createElement('small');line.textContent=m.portfolio+': '+m.minister_name;list.append(line);});
 }
 const lawsHead=document.createElement('b');lawsHead.textContent='Законопроєкти';list.append(lawsHead);
 data.laws.forEach(l=>{
  const item=document.createElement('div');item.className='online-player';
  const title=document.createElement('b');title.textContent=l.title;
  const desc=document.createElement('small');desc.textContent=l.description+' · '+(l.status==='proposed'?'на розгляді':l.status==='adopted'?'ухвалено':'відхилено');
  item.append(title,desc);
  if(l.status==='proposed'){
   const tally=document.createElement('small');const yes=l.tally.find(x=>x.decision==='yes')?.votes||0,no=l.tally.find(x=>x.decision==='no')?.votes||0;tally.textContent='Голоси парламенту: за — '+yes+', проти — '+no;item.append(tally);
   for(const [decision,label] of [['yes','Голосувати за'],['no','Голосувати проти']]){
    const btn=document.createElement('button');btn.className='secondary';btn.textContent=label;
    btn.addEventListener('click',async()=>{try{await cwApi('/api/laws/'+l.id+'/vote',{method:'POST',body:JSON.stringify({decision})});cwSetOnlineStatus('Голос враховано.');await cwRenderOnlinePolitics();}catch(err){cwSetOnlineStatus(err.message);}});
    item.append(btn);
   }
   const finalBtn=document.createElement('button');finalBtn.className='secondary';finalBtn.textContent='Підтвердити результат (власник)';
   finalBtn.addEventListener('click',async()=>{try{await cwApi('/api/laws/'+l.id+'/finalize',{method:'POST',body:'{}'});await cwRenderOnlinePolitics();}catch(err){cwSetOnlineStatus(err.message);}});
   item.append(finalBtn);
  }
  list.append(item);
 });
}
document.getElementById('refreshStatesBtn').addEventListener('click',async()=>{
 try{await cwRefreshOnlineStates();await cwLoadOnlineStatesIntoPolitics();await cwRenderOnlinePolitics();await cwRenderRegionalManagement();cwSetOnlineStatus('Спільний реєстр держав оновлено.');}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('politicsStateSelect').addEventListener('change',()=>Promise.all([cwRenderOnlinePolitics(),cwRenderRegionalManagement()]).catch(e=>cwSetOnlineStatus(e.message)));
document.getElementById('createOnlinePartyBtn').addEventListener('click',async()=>{
 try{
  const id=document.getElementById('politicsStateSelect').value;
  await cwApi('/api/states/'+encodeURIComponent(id)+'/parties',{method:'POST',body:JSON.stringify({
   name:document.getElementById('onlinePartyName').value,
   ideology:document.getElementById('onlinePartyIdeology').value,
   platform:document.getElementById('onlinePartyPlatform').value
  })});
  cwSetOnlineStatus('Партію зареєстровано на сервері.');await cwRenderOnlinePolitics();
 }catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('createOnlineElectionBtn').addEventListener('click',async()=>{
 try{const id=document.getElementById('politicsStateSelect').value;await cwApi('/api/states/'+encodeURIComponent(id)+'/elections',{method:'POST',body:'{}'});cwSetOnlineStatus('Вибори оголошено.');await cwRenderOnlinePolitics();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('submitOnlineLawBtn').addEventListener('click',async()=>{
 try{
  const id=document.getElementById('politicsStateSelect').value;
  await cwApi('/api/states/'+encodeURIComponent(id)+'/laws',{method:'POST',body:JSON.stringify({title:document.getElementById('onlineLawTitle').value,description:document.getElementById('onlineLawDescription').value})});
  cwSetOnlineStatus('Законопроєкт подано.');await cwRenderOnlinePolitics();
 }catch(e){cwSetOnlineStatus(e.message);}
});

document.getElementById('formOnlineGovernmentBtn').addEventListener('click',async()=>{
 try{
  const id=document.getElementById('politicsStateSelect').value;
  const raw=document.getElementById('onlineMinisters').value.split('\n').map(x=>x.trim()).filter(Boolean);
  const ministers=raw.map(line=>{const parts=line.split(':');return {portfolio:(parts.shift()||'').trim(),name:parts.join(':').trim()};});
  await cwApi('/api/states/'+encodeURIComponent(id)+'/government',{method:'POST',body:JSON.stringify({primeMinister:document.getElementById('onlinePrimeMinister').value,ministers})});
  cwSetOnlineStatus('Уряд сформовано на сервері.');await cwRenderOnlinePolitics();
 }catch(e){cwSetOnlineStatus(e.message);}
});

async function cwRenderRegionalManagement(){
 const stateId=document.getElementById('politicsStateSelect').value;
 const list=document.getElementById('onlineRegionalList');list.replaceChildren();
 if(!stateId){list.textContent='Обери державу.';return;}
 const data=await cwApi('/api/states/'+encodeURIComponent(stateId)+'/regions');
 const heading=document.createElement('b');heading.textContent='Території та керівники';list.append(heading);
 data.regions.forEach(r=>{
  const line=document.createElement('div');line.className='online-player';
  const name=document.createElement('b');name.textContent=r.territory_key;
  const governor=document.createElement('small');governor.textContent='Керівник: '+(r.governor||'не призначений');
  line.append(name,governor);list.append(line);
 });
 const eh=document.createElement('b');eh.textContent='Місцеві вибори';list.append(eh);
 for(const e of data.elections){
  const block=document.createElement('div');block.className='online-player';
  const title=document.createElement('b');title.textContent=e.territory_key+' · '+(e.status==='open'?'голосування відкрите':'завершено')+' · явка '+e.turnout;block.append(title);
  const ballot=await cwApi('/api/regions/elections/'+encodeURIComponent(e.id));
  ballot.candidates.forEach(candidate=>{
   const row=document.createElement('div');row.style.display='flex';row.style.gap='8px';row.style.alignItems='center';
   const label=document.createElement('small');label.textContent=candidate.candidate_name+' — '+candidate.votes+' голосів'+(e.status==='closed'?' · '+candidate.seats+' місць':'');row.append(label);
   if(e.status==='open'){
    const vote=document.createElement('button');vote.className='secondary';vote.textContent='Голосувати';
    vote.addEventListener('click',async()=>{try{await cwApi('/api/regions/elections/'+e.id+'/vote',{method:'POST',body:JSON.stringify({candidateName:candidate.candidate_name})});cwSetOnlineStatus('Голос зараховано.');await cwRenderRegionalManagement();}catch(err){cwSetOnlineStatus(err.message);}});
    row.append(vote);
   }
   block.append(row);
  });
  if(e.status==='open'){
   const close=document.createElement('button');close.className='secondary';close.textContent='Завершити місцеві вибори (власник)';
   close.addEventListener('click',async()=>{try{await cwApi('/api/regions/elections/'+e.id+'/close',{method:'POST',body:'{}'});cwSetOnlineStatus('Місцеві вибори завершено.');await cwRenderRegionalManagement();}catch(err){cwSetOnlineStatus(err.message);}});
   block.append(close);
  }
  list.append(block);
 }
 const ch=document.createElement('b');ch.textContent='Склад місцевих рад';list.append(ch);
 data.councils.forEach(s=>{const row=document.createElement('small');row.textContent=s.territory_key+' · '+s.candidate_name+': '+s.seats+' місць ('+s.votes+' голосів)';list.append(row);});
}
document.getElementById('appointRegionalGovernorBtn').addEventListener('click',async()=>{
 try{
  const id=document.getElementById('politicsStateSelect').value;
  await cwApi('/api/states/'+encodeURIComponent(id)+'/regions/governor',{method:'POST',body:JSON.stringify({
   territoryKey:document.getElementById('regionalTerritoryKey').value,
   nickname:document.getElementById('regionalGovernorNick').value
  })});
  cwSetOnlineStatus('Керівника регіону призначено.');await cwRenderRegionalManagement();
 }catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('createRegionalElectionBtn').addEventListener('click',async()=>{
 try{
  const id=document.getElementById('politicsStateSelect').value;
  const candidates=document.getElementById('regionalCandidates').value.split('\n').map(x=>x.trim()).filter(Boolean);
  await cwApi('/api/states/'+encodeURIComponent(id)+'/regions/elections',{method:'POST',body:JSON.stringify({territoryKey:document.getElementById('regionalTerritoryKey').value,candidates})});
  cwSetOnlineStatus('Місцеві вибори оголошено.');await cwRenderRegionalManagement();
 }catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('refreshRegionalBtn').addEventListener('click',()=>cwRenderRegionalManagement().catch(e=>cwSetOnlineStatus(e.message)));

async function cwRenderRegionalEconomy(){
 const stateId=document.getElementById('politicsStateSelect').value;
 const key=document.getElementById('regionalEconomyKey').value.trim();
 const panel=document.getElementById('regionalEconomyPanel');panel.replaceChildren();
 if(!stateId||!key){panel.textContent='Обери державу та введи точний ключ її території.';return;}
 const data=await cwApi('/api/states/'+encodeURIComponent(stateId)+'/regions/'+encodeURIComponent(key)+'/economy');
 const e=data.economy;
 const summary=document.createElement('div');summary.className='online-player';
 const text=document.createElement('b');text.textContent='Бюджет: '+e.treasury+' CW₵';
 const meta=document.createElement('small');meta.textContent='Податок: '+e.tax_rate+'% · рівень інфраструктури: '+e.infrastructure_level+' · економічний цикл: '+e.turn_number;
 const mayor=document.createElement('small');mayor.textContent='Мер: '+(data.mayor||'не обраний');
 summary.append(text,meta,mayor);panel.append(summary);
 const bh=document.createElement('b');bh.textContent='Об’єкти інфраструктури';panel.append(bh);
 data.buildings.forEach(b=>{const line=document.createElement('small');line.textContent=b.building_type+' · рівень '+b.level;panel.append(line);});
 const lh=document.createElement('b');lh.textContent='Місцеві законопроєкти';panel.append(lh);
 data.laws.forEach(l=>{
  const item=document.createElement('div');item.className='online-player';
  const title=document.createElement('b');title.textContent=l.title;
  const desc=document.createElement('small');desc.textContent=l.description+' · '+l.status+' · за: '+l.yes+' · проти: '+l.no;item.append(title,desc);
  if(l.status==='proposed'){
   for(const [decision,label] of [['yes','За'],['no','Проти']]){
    const btn=document.createElement('button');btn.className='secondary';btn.textContent=label;
    btn.addEventListener('click',async()=>{try{await cwApi('/api/regions/local-laws/'+l.id+'/vote',{method:'POST',body:JSON.stringify({decision})});await cwRenderRegionalEconomy();}catch(err){cwSetOnlineStatus(err.message);}});
    item.append(btn);
   }
   const final=document.createElement('button');final.className='secondary';final.textContent='Підтвердити результат (керівник)';
   final.addEventListener('click',async()=>{try{await cwApi('/api/regions/local-laws/'+l.id+'/finalize',{method:'POST',body:'{}'});await cwRenderRegionalEconomy();}catch(err){cwSetOnlineStatus(err.message);}});
   item.append(final);
  }
  panel.append(item);
 });
 const mh=document.createElement('b');mh.textContent='Вибори мера';panel.append(mh);
 for(const election of data.elections){
  const block=document.createElement('div');block.className='online-player';
  const title=document.createElement('b');title.textContent='Вибори мера · '+(election.status==='open'?'відкриті':'завершені')+(election.winner?' · переможець: '+election.winner:'');block.append(title);
  const ballot=await cwApi('/api/mayor-elections/'+election.id);
  ballot.candidates.forEach(candidate=>{
   const row=document.createElement('div');row.style.display='flex';row.style.gap='8px';
   const label=document.createElement('small');label.textContent=candidate.candidate_name+' — '+candidate.votes+' голосів';row.append(label);
   if(election.status==='open'){
    const vote=document.createElement('button');vote.className='secondary';vote.textContent='Голосувати';
    vote.addEventListener('click',async()=>{try{await cwApi('/api/mayor-elections/'+election.id+'/vote',{method:'POST',body:JSON.stringify({candidateName:candidate.candidate_name})});await cwRenderRegionalEconomy();}catch(err){cwSetOnlineStatus(err.message);}});
    row.append(vote);
   }
   block.append(row);
  });
  if(election.status==='open'){
   const close=document.createElement('button');close.className='secondary';close.textContent='Завершити вибори мера (власник)';
   close.addEventListener('click',async()=>{try{await cwApi('/api/mayor-elections/'+election.id+'/close',{method:'POST',body:'{}'});await cwRenderRegionalEconomy();}catch(err){cwSetOnlineStatus(err.message);}});
   block.append(close);
  }
  panel.append(block);
 }
}
document.getElementById('saveRegionalTaxBtn').addEventListener('click',async()=>{
 try{const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('regionalEconomyKey').value.trim(),taxRate=Number(document.getElementById('regionalTaxRate').value);
 await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/economy/tax',{method:'POST',body:JSON.stringify({taxRate})});cwSetOnlineStatus('Місцевий податок оновлено.');await cwRenderRegionalEconomy();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('collectRegionalIncomeBtn').addEventListener('click',async()=>{
 try{const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('regionalEconomyKey').value.trim();
 const result=await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/economy/collect',{method:'POST',body:'{}'});cwSetOnlineStatus('Дохід регіону: +'+result.income+' CW₵.');await cwRenderRegionalEconomy();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('buildRegionalBtn').addEventListener('click',async()=>{
 try{const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('regionalEconomyKey').value.trim(),buildingType=document.getElementById('regionalBuildingType').value;
 await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/buildings',{method:'POST',body:JSON.stringify({buildingType})});cwSetOnlineStatus('Об’єкт збудовано.');await cwRenderRegionalEconomy();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('createMayorElectionBtn').addEventListener('click',async()=>{
 try{const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('regionalEconomyKey').value.trim(),candidates=document.getElementById('mayorCandidates').value.split('\n').map(x=>x.trim()).filter(Boolean);
 await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/mayor-elections',{method:'POST',body:JSON.stringify({candidates})});cwSetOnlineStatus('Вибори мера оголошено.');await cwRenderRegionalEconomy();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('createRegionalLawBtn').addEventListener('click',async()=>{
 try{const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('regionalEconomyKey').value.trim();
 await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/laws',{method:'POST',body:JSON.stringify({title:document.getElementById('regionalLawTitle').value,description:document.getElementById('regionalLawDescription').value})});cwSetOnlineStatus('Місцевий законопроєкт подано.');await cwRenderRegionalEconomy();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('refreshRegionalEconomyBtn').addEventListener('click',()=>cwRenderRegionalEconomy().catch(e=>cwSetOnlineStatus(e.message)));

// Region-first map controls: no country layer or country-to-region drilldown.
document.getElementById('mapWorldBtn')?.addEventListener('click',()=>{
  if(!map)return;
  if(regionLayer)map.fitBounds(regionLayer.getBounds(),{padding:[4,4]});
  setStatus(`Європа · ${allRegionFeatures.length} адміністративних регіонів`);
});
document.getElementById('mapCountryBtn')?.addEventListener('click',()=>{
  notify('Карта працює лише в режимі адміністративних регіонів.');
});
document.getElementById('mapDistrictBtn')?.addEventListener('click',()=>{
  notify('Обирай регіон безпосередньо на карті.');
});
document.getElementById('mapAddTerritoryBtn')?.addEventListener('click',()=>{
  notify('Регіон обрано. Керування територіями доступне в профілі регіону.');
});
// v1.7.0 city registry and municipal development.
async function cwRenderCities(){
 const state=document.getElementById('politicsStateSelect').value;
 const key=document.getElementById('cityRegionKey').value.trim();
 const panel=document.getElementById('citiesPanel');panel.replaceChildren();
 if(!state||!key){panel.textContent='Обери онлайн-державу та введи точний ключ її регіону.';return;}
 const data=await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/cities');
 if(!data.cities.length){panel.textContent='У цьому регіоні ще немає зареєстрованих міст.';return;}
 for(const city of data.cities){
  const card=document.createElement('div');card.className='online-player';
  const title=document.createElement('b');title.textContent=city.name;
  const details=document.createElement('small');details.textContent='Населення: '+city.population.toLocaleString('uk-UA')+' · рівень міста: '+city.urban_level+' · міський голова: '+(city.mayor||'не призначений');
  card.append(title,details);
  const projects=data.projects.filter(p=>p.city_id===city.id);
  projects.forEach(p=>{const line=document.createElement('small');line.textContent=p.project_type+' · рівень '+p.level;card.append(line);});
  const develop=document.createElement('button');develop.className='secondary';develop.textContent='Розвинути місто: побудувати проєкт';
  develop.addEventListener('click',async()=>{
   try{const projectType=document.getElementById('cityProjectType').value;
    await cwApi('/api/cities/'+city.id+'/projects',{method:'POST',body:JSON.stringify({projectType})});
    notify('Міський проєкт реалізовано.');await cwRenderCities();
   }catch(e){notify(e.message);}
  });
  const mayor=document.createElement('button');mayor.className='secondary';mayor.textContent='Призначити міського голову';
  mayor.addEventListener('click',async()=>{
   try{const nickname=document.getElementById('cityMayorNick').value.trim();
    await cwApi('/api/cities/'+city.id+'/mayor',{method:'POST',body:JSON.stringify({nickname})});
    notify('Міського голову призначено.');await cwRenderCities();
   }catch(e){notify(e.message);}
  });
  const growth=document.createElement('button');growth.className='secondary';growth.textContent='Розрахувати приріст населення';
  growth.addEventListener('click',async()=>{
   try{const result=await cwApi('/api/cities/'+city.id+'/growth',{method:'POST',body:'{}'});
    notify('Приріст населення: +'+result.growth+'.');await cwRenderCities();
   }catch(e){notify(e.message);}
  });
  const manage=document.createElement('button');manage.className='secondary';manage.textContent='Відкрити міське управління';
  manage.addEventListener('click',async()=>{cwSelectedCityId=city.id;try{await cwRenderCityGovernance(city.id);}catch(err){notify(err.message);}});
  card.append(develop,mayor,growth,manage);panel.append(card);
 }
}
document.getElementById('createCityBtn').addEventListener('click',async()=>{
 try{
  const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('cityRegionKey').value.trim();
  const name=document.getElementById('cityName').value.trim(),population=Number(document.getElementById('cityPopulation').value);
  await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/cities',{method:'POST',body:JSON.stringify({name,population})});
  notify('Місто засновано.');await cwRenderCities();
 }catch(e){notify(e.message);}
});
document.getElementById('refreshCitiesBtn').addEventListener('click',()=>cwRenderCities().catch(e=>notify(e.message)));

// v1.8.0: municipal elections, council, budget and proposals.
async function cwRenderCityGovernance(cityId){
 const panel=document.getElementById('cityGovernancePanel');panel.replaceChildren();
 if(!cityId){panel.textContent='Спочатку онови список міст і обери місто.';return;}
 const data=await cwApi('/api/cities/'+cityId+'/governance');
 const e=data.economy,c=data.city;
 const head=document.createElement('div');head.className='online-player';
 const title=document.createElement('b');title.textContent=c.name+' · міський бюджет: '+e.treasury+' CW₵';
 const meta=document.createElement('small');meta.textContent='Міський податок: '+e.tax_rate+'% · цикл: '+e.turn_number+' · міський голова: '+(c.mayor||'не обраний');
 head.append(title,meta);panel.append(head);
 const councilTitle=document.createElement('b');councilTitle.textContent='Міська рада · 15 місць';panel.append(councilTitle);
 data.council.forEach(x=>{const line=document.createElement('small');line.textContent=x.nickname+' — '+x.seats+' місць ('+x.votes+' голосів)';panel.append(line);});
 const electionTitle=document.createElement('b');electionTitle.textContent='Міські вибори';panel.append(electionTitle);
 for(const election of data.elections){
  const block=document.createElement('div');block.className='online-player';
  const label=document.createElement('b');label.textContent=(election.election_type==='mayor'?'Вибори мера':'Вибори міської ради')+' · '+election.status+(election.winner_nickname?' · переможець: '+election.winner_nickname:'');block.append(label);
  const ballot=await cwApi('/api/city-elections/'+election.id);
  ballot.candidates.forEach(candidate=>{
   const row=document.createElement('div');row.style.display='flex';row.style.gap='8px';
   const text=document.createElement('small');text.textContent=candidate.nickname+' — '+candidate.votes;row.append(text);
   if(election.status==='open'){
    const vote=document.createElement('button');vote.className='secondary';vote.textContent='Голосувати';
    vote.addEventListener('click',async()=>{try{await cwApi('/api/city-elections/'+election.id+'/vote',{method:'POST',body:JSON.stringify({candidateId:candidate.player_id})});await cwRenderCityGovernance(cityId);}catch(err){notify(err.message);}});
    row.append(vote);
   }block.append(row);
  });
  if(election.status==='open'){
   const close=document.createElement('button');close.className='secondary';close.textContent='Підбити підсумки (мер/керівник)';
   close.addEventListener('click',async()=>{try{await cwApi('/api/city-elections/'+election.id+'/close',{method:'POST',body:'{}'});await cwRenderCityGovernance(cityId);}catch(err){notify(err.message);}});
   block.append(close);
  }panel.append(block);
 }
 const proposals=document.createElement('b');proposals.textContent='Міські ініціативи';panel.append(proposals);
 data.proposals.forEach(p=>{
  const item=document.createElement('div');item.className='online-player';
  const t=document.createElement('b');t.textContent=p.title;
  const d=document.createElement('small');d.textContent=p.description+' · '+p.status+' · за '+p.yes+' · проти '+p.no;item.append(t,d);
  if(p.status==='proposed'){
   for(const [decision,label] of [['yes','За'],['no','Проти']]){
    const btn=document.createElement('button');btn.className='secondary';btn.textContent=label;
    btn.addEventListener('click',async()=>{try{await cwApi('/api/city-proposals/'+p.id+'/vote',{method:'POST',body:JSON.stringify({decision})});await cwRenderCityGovernance(cityId);}catch(err){notify(err.message);}});
    item.append(btn);
   }
   const finish=document.createElement('button');finish.className='secondary';finish.textContent='Підтвердити результат';
   finish.addEventListener('click',async()=>{try{await cwApi('/api/city-proposals/'+p.id+'/finalize',{method:'POST',body:'{}'});await cwRenderCityGovernance(cityId);}catch(err){notify(err.message);}});
   item.append(finish);
  }panel.append(item);
 });
}
let cwSelectedCityId=null;

document.getElementById('createCityElectionBtn').addEventListener('click',async()=>{
 try{if(!cwSelectedCityId)throw new Error('Спочатку обери місто.');
 const electionType=document.getElementById('cityElectionType').value;
 const candidates=document.getElementById('cityElectionCandidates').value.split('\n').map(x=>x.trim()).filter(Boolean);
 await cwApi('/api/cities/'+cwSelectedCityId+'/elections',{method:'POST',body:JSON.stringify({electionType,candidates})});
 notify('Міські вибори оголошено.');await cwRenderCityGovernance(cwSelectedCityId);
 }catch(e){notify(e.message);}
});
document.getElementById('saveMunicipalTaxBtn').addEventListener('click',async()=>{
 try{if(!cwSelectedCityId)throw new Error('Спочатку обери місто.');
 const taxRate=Number(document.getElementById('municipalTaxRate').value);
 await cwApi('/api/cities/'+cwSelectedCityId+'/municipal-tax',{method:'POST',body:JSON.stringify({taxRate})});
 notify('Міський податок оновлено.');await cwRenderCityGovernance(cwSelectedCityId);
 }catch(e){notify(e.message);}
});
document.getElementById('collectMunicipalIncomeBtn').addEventListener('click',async()=>{
 try{if(!cwSelectedCityId)throw new Error('Спочатку обери місто.');
 const r=await cwApi('/api/cities/'+cwSelectedCityId+'/municipal-income',{method:'POST',body:'{}'});
 notify('Міський бюджет отримав +'+r.income+' CW₵.');await cwRenderCityGovernance(cwSelectedCityId);
 }catch(e){notify(e.message);}
});
document.getElementById('buildMunicipalProjectBtn').addEventListener('click',async()=>{
 try{if(!cwSelectedCityId)throw new Error('Спочатку обери місто.');
 const projectType=document.getElementById('municipalProjectType').value;
 await cwApi('/api/cities/'+cwSelectedCityId+'/municipal-projects',{method:'POST',body:JSON.stringify({projectType})});
 notify('Муніципальний проєкт оплачено.');await cwRenderCityGovernance(cwSelectedCityId);
 }catch(e){notify(e.message);}
});
document.getElementById('createMunicipalProposalBtn').addEventListener('click',async()=>{
 try{if(!cwSelectedCityId)throw new Error('Спочатку обери місто.');
 const title=document.getElementById('municipalProposalTitle').value,description=document.getElementById('municipalProposalDescription').value;
 await cwApi('/api/cities/'+cwSelectedCityId+'/proposals',{method:'POST',body:JSON.stringify({title,description})});
 notify('Міську ініціативу подано.');await cwRenderCityGovernance(cwSelectedCityId);
 }catch(e){notify(e.message);}
});
document.getElementById('refreshCityGovernanceBtn').addEventListener('click',()=>cwSelectedCityId?cwRenderCityGovernance(cwSelectedCityId).catch(e=>notify(e.message)):notify('Спочатку обери місто.'));


// Lightweight Ukrainian / English interface localization.
const cwTranslations={
 'Огляд':'Overview','Статті':'Articles','Робота':'Work','Інвентар':'Inventory','Війни':'World','Моя партія':'My Party','Профіль':'Profile','Карти':'Map',
 'Мапа регіонів Європи':'Map of European Regions','Світова карта':'World Map','Відкрити карту':'Open Map','Обрана територія':'Selected Territory',
 'Профіль гравця':'Player Profile','Гравці та запрошення':'Players and Invitations','Список гравців':'Player List','Знайти':'Search','Оновити список':'Refresh List',
 'Золотоносна шахта регіону':'Regional Gold Mine','Працювати в шахті':'Work in Mine','Інвентар':'Inventory','Придбати енергетики':'Buy Energy Drinks',
 'Статті спільноти':'Community Articles','Публікація статті без акаунта':'Publish an Article Without an Account','Опублікувати статтю':'Publish Article',
 'Акаунт без пошти':'Account Without Email','Зберегти профіль':'Save Profile','Гостьовий режим':'Guest Mode','Нікнейм':'Nickname','Про себе':'About Me',
 'Регіон не обрано':'No region selected','Спочатку обери регіон на мапі.':'Select a region on the map first.','Пошук за нікнеймом':'Search by nickname',
 'ГРАВЦІ':'PLAYERS','РЕГІОНИ':'REGIONS','СТАТТІ':'ARTICLES','ЗОЛОТИЙ ЗАПАС':'GOLD RESERVE'
};
function cwApplyLanguage(lang){
 document.documentElement.lang=lang;
 document.querySelectorAll('[data-tab]').forEach(el=>{const key=el.dataset.tab;const uk={overview:'Огляд',articles:'Статті',work:'Робота',inventory:'Інвентар',wars:'Війни',party:'Моя партія',profile:'Профіль',map:'Карти'}[key];if(uk)el.lastChild.textContent=lang==='en'?(cwTranslations[uk]||uk):uk;});
 document.querySelectorAll('h1,h2,h3,button,label,small,p,option').forEach(el=>{if(el.children.length) return;const raw=el.textContent.trim();if(lang==='en'&&cwTranslations[raw])el.textContent=cwTranslations[raw];else if(lang==='uk'){const en=Object.entries(cwTranslations).find(([,v])=>v===raw);if(en)el.textContent=en[0];}});
 localStorage.setItem('cw_language',lang);
}
document.getElementById('cwLanguageSelect')?.addEventListener('change',e=>cwApplyLanguage(e.target.value));
const savedLang=localStorage.getItem('cw_language')||'uk';const langSelect=document.getElementById('cwLanguageSelect');if(langSelect){langSelect.value=savedLang;cwApplyLanguage(savedLang);}

/* Reference-style six-screen navigation. Existing feature sections are moved,
   not recreated, so their original IDs and event handlers remain intact. */
(function(){
 const main=document.querySelector('main');
 if(!main)return;
 const pages={};
 const labels={overview:'Огляд',articles:'Статті',work:'Робота',inventory:'Інвентар',wars:'Війни',party:'Моя партія',profile:'Профіль',map:'Карти'};
 Object.keys(labels).forEach(key=>{
   const page=document.createElement('div');
   page.className='cw-page'+(key==='overview'?' active':'');
   page.id='page-'+key;
   page.dataset.page=key;
   main.appendChild(page);pages[key]=page;
 });
 const partyPageHead=document.createElement('section');partyPageHead.className='cw-card cw-my-party-heading';partyPageHead.innerHTML='<div class="section-head"><div><small>ПОЛІТИЧНЕ УПРАВЛІННЯ</small><h2>Моя партія</h2></div><span class="live-dot">ONLINE</span></div><p class="cw-muted">Керування партією, учасниками та її публічним профілем.</p><button type="button" class="secondary" id="cwRefreshMyParties">Оновити список</button>';pages.party.append(partyPageHead);const partyContent=document.createElement('div');partyContent.id='cwMyPartyContent';pages.party.append(partyContent);document.getElementById('cwRefreshMyParties').addEventListener('click',cwRenderMyParties);
 const move=(selector,key)=>{
   document.querySelectorAll(selector).forEach(el=>pages[key].appendChild(el));
 };
 move('.welcome,.stats,.region-card,.state-card,.diplomacy-card,.gov-card,.quick','overview');
 move('.map-panel','map');
 move('.economy-card','work');
 const ops=document.createElement('section');ops.className='cw-card';ops.id='cwStateOps';ops.innerHTML='<h2>Державні механіки 6.0</h2><label class="economy-label">Моя держава</label><select id="cwOpsState" class="economy-select"><option value="">Завантаження…</option></select><label class="economy-label">Регіон держави</label><select id="cwOpsRegion" class="economy-select"><option value="">Обери державу</option></select><h3>Форма правління</h3><select id="cwOpsGovType" class="economy-select"><option value="democracy">Демократія · +20% швидкість будівництва</option><option value="monarchy">Монархія · лицарі +20% шкоди</option></select><button id="cwOpsGovSave" class="secondary">Зберегти форму правління</button><div id="cwOpsKnights" class="cw-list"></div><input id="cwOpsKnightNick" class="economy-select" maxlength="24" placeholder="Нікнейм гравця для лицарства"><button id="cwOpsKnightAdd" class="secondary">Призначити лицарем</button><hr><h3>Будівництво</h3><select id="cwOpsBuilding" class="economy-select"><option>Дорога</option><option>Школа</option><option>Лікарня</option><option>Культурний центр</option><option>Водопостачання</option></select><button id="cwOpsBuild" class="primary">Почати будівництво</button><div id="cwOpsConstruction" class="cw-list"></div><hr><h3>Державний банк</h3><p class="cw-muted">Курс: 100 CW₵ = 1 золото. До 10 золота одному гравцю за 24 години.</p><input id="cwOpsBankNick" class="economy-select" maxlength="24" placeholder="Нікнейм отримувача"><input id="cwOpsBankGold" class="economy-select" type="number" min="1" max="10" value="1"><button id="cwOpsBankPay" class="secondary">Виплатити з казни</button><div id="cwOpsBankLog" class="cw-list"></div><p id="cwOpsStatus" class="cw-muted">Керує власник держави. Обери державу й регіон.</p>';
 pages.work.append(ops);
 async function opsLoadStates(){try{const [me,d]=await Promise.all([cwApi('/api/me'),cwApi('/api/states')]);window.cwMyPlayerId=me.player.id;const owned=d.states.filter(x=>x.owner_id===me.player.id);const sel=document.getElementById('cwOpsState');sel.innerHTML='<option value="">Обери державу</option>'+owned.map(x=>'<option value="'+safeText(x.id)+'">'+safeText(x.name)+'</option>').join('');if(!owned.length)document.getElementById('cwOpsStatus').textContent='Спочатку створи онлайн-державу.';}catch(e){document.getElementById('cwOpsStatus').textContent='Не вдалося завантажити держави: '+e.message;}}
 async function opsLoadState(){const id=document.getElementById('cwOpsState').value,region=document.getElementById('cwOpsRegion');region.innerHTML='<option value="">Обери регіон</option>';if(!id)return;try{const [gov,bank]=await Promise.all([cwApi('/api/states/'+encodeURIComponent(id)+'/government'),cwApi('/api/states/'+encodeURIComponent(id)+'/bank')]);document.getElementById('cwOpsGovType').value=gov.governmentType;region.innerHTML+=((await cwApi('/api/states')).states.find(x=>x.id===id)?.territories||[]).map(k=>'<option value="'+safeText(k)+'">'+safeText(k)+'</option>').join('');const kb=document.getElementById('cwOpsKnights');kb.replaceChildren();gov.knights.forEach(k=>{const row=document.createElement('div');row.className='cw-list-item';row.textContent='♞ '+k.nickname+' · +20% шкоди';const remove=document.createElement('button');remove.className='secondary';remove.textContent='Зняти';remove.addEventListener('click',async()=>{try{await cwApi('/api/states/'+encodeURIComponent(id)+'/knights/'+encodeURIComponent(k.player_id),{method:'DELETE'});await opsLoadState();}catch(e){notify(e.message);}});row.append(remove);kb.append(row);});const bl=document.getElementById('cwOpsBankLog');bl.replaceChildren();bank.transfers.forEach(t=>{const row=document.createElement('div');row.className='cw-list-item';row.textContent=t.nickname+' · '+t.gold_amount+' золота · '+t.region_key;bl.append(row);});}catch(e){notify(e.message);}}
 async function opsLoadConstruction(){const id=document.getElementById('cwOpsState').value,key=document.getElementById('cwOpsRegion').value;if(!id||!key)return;try{const d=await cwApi('/api/states/'+encodeURIComponent(id)+'/regions/'+encodeURIComponent(key)+'/economy');const box=document.getElementById('cwOpsConstruction');box.replaceChildren();d.construction.filter(x=>x.status==='pending').forEach(c=>{const row=document.createElement('div');row.className='cw-list-item';const remaining=Math.max(0,c.completes_at-Date.now());row.textContent=c.building_type+' · завершення через '+Math.ceil(remaining/60000)+' хв';box.append(row);});d.construction.filter(x=>x.status==='completed').slice(0,5).forEach(c=>{const row=document.createElement('div');row.className='cw-list-item';row.textContent='✓ '+c.building_type+' · завершено';box.append(row);});if(!box.children.length)box.textContent='Черга будівництва порожня.';}catch(e){document.getElementById('cwOpsConstruction').textContent=e.message;}}
 document.getElementById('cwOpsState').addEventListener('change',opsLoadState);document.getElementById('cwOpsRegion').addEventListener('change',opsLoadConstruction);document.getElementById('cwOpsGovSave').addEventListener('click',async()=>{const id=document.getElementById('cwOpsState').value;if(!id)return;try{await cwApi('/api/states/'+encodeURIComponent(id)+'/government',{method:'POST',body:JSON.stringify({governmentType:document.getElementById('cwOpsGovType').value})});notify('Форму правління збережено.');await opsLoadState();}catch(e){notify(e.message);}});
 document.getElementById('cwOpsKnightAdd').addEventListener('click',async()=>{const id=document.getElementById('cwOpsState').value,nickname=document.getElementById('cwOpsKnightNick').value.trim();if(!id||!nickname)return;try{await cwApi('/api/states/'+encodeURIComponent(id)+'/knights',{method:'POST',body:JSON.stringify({nickname})});notify('Лицаря призначено.');document.getElementById('cwOpsKnightNick').value='';await opsLoadState();}catch(e){notify(e.message);}});
 document.getElementById('cwOpsBuild').addEventListener('click',async()=>{const id=document.getElementById('cwOpsState').value,key=document.getElementById('cwOpsRegion').value;if(!id||!key){notify('Обери державу й регіон.');return;}try{const d=await cwApi('/api/states/'+encodeURIComponent(id)+'/regions/'+encodeURIComponent(key)+'/buildings',{method:'POST',body:JSON.stringify({buildingType:document.getElementById('cwOpsBuilding').value})});notify('Будівництво почалося. Орієнтовно '+Math.ceil(d.durationMs/60000)+' хв.');await opsLoadConstruction();}catch(e){notify(e.message);}});
 document.getElementById('cwOpsBankPay').addEventListener('click',async()=>{const id=document.getElementById('cwOpsState').value,regionKey=document.getElementById('cwOpsRegion').value,nickname=document.getElementById('cwOpsBankNick').value.trim(),gold=Number(document.getElementById('cwOpsBankGold').value);if(!id||!regionKey||!nickname){notify('Обери державу, регіон отримувача й нікнейм.');return;}try{const d=await cwApi('/api/states/'+encodeURIComponent(id)+'/bank/transfer',{method:'POST',body:JSON.stringify({nickname,gold,regionKey,regionName:regionKey})});notify('Виплачено '+d.gold+' золота. Витрачено '+d.treasurySpent+' CW₵.');await opsLoadState();}catch(e){notify(e.message);}});
 document.querySelector('[data-tab="work"]')?.addEventListener('click',opsLoadStates);
 setInterval(()=>{if(document.getElementById('page-work')?.classList.contains('active'))opsLoadConstruction();},30000);
 const workResources=document.createElement('section');
 workResources.className='cw-card';
 workResources.innerHTML=`<h2>Золотоносна шахта регіону</h2>
 <p class="cw-muted" id="cwMineRegion">Спочатку обери регіон на мапі Європи.</p>
 <div class="cw-grid3"><div class="cw-stat"><small>Золото</small><b id="cwGold">—</b></div><div class="cw-stat"><small>Енергія</small><b id="cwEnergy">—</b></div><div class="cw-stat"><small>Досвід</small><b id="cwXp">—</b></div></div>
 <label class="economy-label" for="cwMineEnergy">Енергія за один видобуток</label>
 <select id="cwMineEnergy" class="economy-select"><option>10</option><option>50</option><option>100</option><option>200</option><option>300</option><option>400</option><option selected>500</option></select>
 <button class="primary" id="cwMineBtn">Працювати в шахті</button>
 <div class="cw-row"><input id="cwBuyEnergy" type="number" min="1" max="500" value="50" class="economy-select" style="flex:1;min-width:0"><button class="secondary" id="cwBuyEnergyBtn">Купити енергетики · 1 золото за 1</button></div>
 <p class="cw-muted" id="cwGoldRefill">Золото поповнюється автоматично кожні 12 годин: +100.</p><p class="cw-muted">1 енергія = 1 золото та 5 HP. Повна зміна (500 енергії) дає 500 золота й 2500 HP — 2,5 рівня.</p>`;
 workResources.insertAdjacentHTML('beforeend', `
  <hr><h2>Розвиток регіону</h2>
  <button class="secondary" id="cwBuildAcademy">Побудувати військову академію · нагорода 100 золота</button>
  <p class="cw-muted" id="cwAcademyStatus">Одна академія на регіон кожні 12 годин.</p>
  <h3>Політика регіону</h3>
  <input id="cwNewPartyName" class="economy-select" maxlength="60" placeholder="Назва партії">
  <input id="cwNewPartyIdeology" class="economy-select" maxlength="60" placeholder="Ідеологія">
  <textarea id="cwNewPartyProgram" class="economy-select" maxlength="1000" placeholder="Програма партії"></textarea>
  <button class="secondary" id="cwCreateRegionalParty">Створити партію · 25 золота</button>
  <div id="cwRegionalPartyList" class="cw-list"></div>
  <button class="secondary" id="cwRunRegionalElection">Провести вибори</button>
  <p class="cw-muted" id="cwElectionStatus">Вибори доступні через 3 години після створення першої партії.</p>
  <h3>Перельоти</h3>
  <input id="cwFlightRegionName" class="economy-select" maxlength="100" placeholder="Назва регіону призначення">
  <input id="cwFlightRegionKey" class="economy-select" maxlength="120" placeholder="Ключ регіону з карти">
  <button class="secondary" id="cwTravelRegion">Перелетіти в регіон · 50 золота</button>
  <p class="cw-muted" id="cwPresenceStatus"></p>
 `);
 pages.work.insertBefore(workResources,pages.work.firstChild);
 const inventory=document.createElement('section');inventory.className='cw-card';inventory.id='cwInventoryCard';
 inventory.innerHTML='<h2>Інвентар</h2><p class="cw-muted">Енергетики: 1 золото за 1 одиницю.</p><div class="cw-grid3"><div class="cw-stat"><small>Золото</small><b id="cwInventoryGold">—</b></div><div class="cw-stat"><small>Енергія</small><b id="cwInventoryEnergy">—</b></div><div class="cw-stat"><small>Тарани</small><b id="cwRamCount">0</b></div></div><label class="economy-label" for="cwInventoryAmount">Кількість енергетиків</label><input id="cwInventoryAmount" type="number" min="1" max="500" value="50" class="economy-select"><button class="primary" id="cwInventoryBuy">Придбати енергетики</button><hr><h3>Тарани для воєн</h3><p class="cw-muted">1 таран — 2 золота. У поєдинку удар тараном завдає 25 шкоди та додає 500 XP.</p><input id="cwRamBuyAmount" type="number" min="1" max="100" value="1" class="economy-select"><button class="secondary" id="cwRamBuy">Купити тарани</button><hr><h3>Мечі</h3><p class="cw-muted">Створення меча коштує 25 золота. Продаж — від 5 до 20 золота.</p><button class="secondary" id="cwSwordCreate">Створити меч · 25 золота</button><div id="cwMySwords" class="cw-list"></div><section id="cwAuctionPanel"><h3>Аукціон мечів</h3><div id="cwAuctionListings" class="cw-list">Завантаження…</div></section><p class="cw-muted">Покупки оплачуються золотом обраного регіону.</p>'
 pages.inventory.appendChild(inventory);

 move('#accountCard,#onlineAccountCard','profile');
 const chatPanel=document.createElement('section');
 chatPanel.className='cw-card';
 chatPanel.innerHTML='<div class="cw-row"><h2>Світовий чат</h2><span class="cw-live">ОНЛАЙН</span></div>'+
  '<div id="cwChatMessages" class="cw-chat-feed" aria-live="polite"><p class="cw-muted">Завантаження повідомлень…</p></div>'+
  '<div class="cw-row"><input id="cwChatInput" class="economy-select" maxlength="500" placeholder="Написати повідомлення" style="flex:1;min-width:0"><button class="secondary" id="cwChatImageBtn" style="width:auto;margin:0">▧</button><button class="primary" id="cwChatSend" style="width:auto;margin:0">Надіслати</button></div><input id="cwChatImage" type="file" accept="image/png,image/jpeg,image/webp" hidden><p class="cw-muted">Зображення JPG, PNG або WEBP до 3,5 МБ.</p>';
 pages.overview.appendChild(chatPanel);
 let cwChatImageData='';
 document.getElementById('cwChatImageBtn').addEventListener('click',()=>document.getElementById('cwChatImage').click());
 document.getElementById('cwChatImage').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;if(f.size>3.5*1024*1024){notify('Зображення має бути до 3,5 МБ.');e.target.value='';return;}if(!/^image\/(png|jpeg|webp)$/.test(f.type)){notify('Підтримуються JPG, PNG або WEBP.');return;}cwChatImageData=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=reject;r.readAsDataURL(f);});notify('Зображення додано до повідомлення.');});
 const dmPanel=document.createElement('section');dmPanel.className='cw-card';
 dmPanel.innerHTML='<div class="cw-row"><h2>Приватні повідомлення</h2><span class="cw-live">ОСОБИСТІ</span></div><input id="cwDmRecipient" class="economy-select" maxlength="32" placeholder="Нікнейм гравця"><textarea id="cwDmBody" class="economy-select" rows="2" maxlength="2000" placeholder="Твоє приватне повідомлення"></textarea><button class="primary" id="cwDmSend">Надіслати</button><div id="cwDmInbox" class="cw-list"><p class="cw-muted">Завантаження повідомлень…</p></div>';
 pages.overview.appendChild(dmPanel);
 async function cwLoadDM(){
  const token=localStorage.getItem(CW_SESSION_TOKEN_KEY);if(!token)return;
  try{const r=await fetch(cwApiBase()+'/api/messages',{headers:{Authorization:'Bearer '+token}});const d=await r.json();if(!r.ok)throw new Error(d.error||'Не вдалося завантажити повідомлення.');
   const box=document.getElementById('cwDmInbox');box.replaceChildren();
   (d.messages||[]).forEach(m=>{const row=document.createElement('div');row.className='cw-list-item';const main=document.createElement('div');main.className='cw-item-main';const head=document.createElement('b');head.textContent=(m.sender===((localStorage.getItem('cw_nickname')||'') )?'Ти → '+m.recipient:'Від '+m.sender);const body=document.createElement('p');body.textContent=m.body;const time=document.createElement('small');time.textContent=new Date(m.created_at).toLocaleString();main.append(head,body,time);row.append(main);box.append(row);});
   if(!box.children.length)box.textContent='Поки немає приватних повідомлень.';
  }catch(e){console.warn(e);}
 }
 document.getElementById('cwDmSend').addEventListener('click',async()=>{
  const token=localStorage.getItem(CW_SESSION_TOKEN_KEY);if(!token){notify('Спочатку дочекайся створення ігрового профілю.');return;}
  try{const r=await fetch(cwApiBase()+'/api/messages',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({recipient:document.getElementById('cwDmRecipient').value,body:document.getElementById('cwDmBody').value})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Не вдалося надіслати.');document.getElementById('cwDmBody').value='';notify('Повідомлення надіслано.');cwLoadDM();}catch(e){notify(e.message);}
 });
 cwLoadDM();setInterval(cwLoadDM,12000);
 let cwChatLastId=0;
 async function cwLoadChat(){
  try{
   const d=await cwPublicApi('/api/public/chat?after='+cwChatLastId);
   const feed=document.getElementById('cwChatMessages');
   (d.messages||[]).forEach(m=>{
    const row=document.createElement('div');row.className='cw-chat-message';
    const author=document.createElement('b');author.textContent=m.author||'Гість';
    const body=document.createElement('p');body.textContent=m.body||'';if(m.imageData){const im=document.createElement('img');im.src=m.imageData;im.alt='Зображення в чаті';im.className='cw-chat-image';body.append(im);}
    const time=document.createElement('small');time.textContent=new Date(m.created_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
    row.append(author,body,time);feed.append(row);cwChatLastId=Math.max(cwChatLastId,Number(m.id)||0);
   });
   if(!feed.children.length)feed.innerHTML='<p class="cw-muted">Поки немає повідомлень. Почни розмову!</p>';
   else feed.scrollTop=feed.scrollHeight;
  }catch(e){console.warn('World chat unavailable',e);}
 }
 async function cwSendChat(){
  const input=document.getElementById('cwChatInput'),body=input.value.trim();if(!body&&!cwChatImageData)return;
  try{await cwPublicApi('/api/public/chat',{method:'POST',body:JSON.stringify({author:localStorage.getItem('cw_nickname')||'Гість',body,imageData:cwChatImageData})});input.value='';cwChatImageData='';document.getElementById('cwChatImage').value='';await cwLoadChat();}
  catch(e){notify(e.message);}
 }
 document.getElementById('cwChatSend').addEventListener('click',cwSendChat);
 document.getElementById('cwChatInput').addEventListener('keydown',e=>{if(e.key==='Enter')cwSendChat();});
 cwLoadChat();setInterval(cwLoadChat,4000);


 // Add a compact map shortcut to the overview dashboard.
 const overviewMapShortcut=document.createElement('section');
 overviewMapShortcut.className='cw-card';
 overviewMapShortcut.innerHTML='<div class="cw-row"><div><h2>Світова карта</h2><small class="cw-muted">Країни та адміністративні території</small></div><span class="cw-avatar">🌍</span></div><button class="secondary" id="cwOpenMap">Відкрити карту</button>';
 pages.overview.insertBefore(overviewMapShortcut,pages.overview.children[2]||null);

 const wars=document.createElement('div');
 wars.innerHTML=`
  <section class="cw-card">
   <h2>Війни</h2>
   <div class="cw-list-item"><div class="cw-avatar">🕊</div><div class="cw-item-main"><b>Стан міжнародної ситуації</b><small>Немає активних конфліктів у твоїй державі</small></div></div>
  </section>
  <section class="cw-card">
   <div class="cw-list-item"><div class="cw-avatar">✊</div><div class="cw-item-main"><b>Повстання</b><small>Ігрова подія для зміни регіонального управління</small></div></div>
   <div class="cw-list-item"><div class="cw-avatar">♨</div><div class="cw-item-main"><b>Політична криза</b><small>Переговори, голосування та мирне врегулювання</small></div></div>
   <button class="primary" id="cwPeacefulTraining">Навчання та підготовка служб</button>
  </section>
  <section class="cw-card">
   <h2>Світові події</h2>
   <p class="cw-muted">Тут відображатимуться міжнародні події, дипломатичні суперечки та результати ігрових змагань.</p>
   <div class="cw-list-item"><div class="cw-avatar">🌐</div><div class="cw-item-main"><b>Міжнародна взаємодія</b><small>Угоди, визнання держав і спільні проєкти</small></div></div>
  </section>`;
 pages.wars.appendChild(wars);
 const duelPanel=document.createElement('section');duelPanel.className='cw-card';duelPanel.innerHTML='<h2>Ігрові поєдинки</h2><p class="cw-muted">Викликай інших гравців на покроковий поєдинок. Звичайний удар знімає 10 очок здоров’я, удар тараном — 25 та дає 500 XP.</p><input id="cwDuelNickname" class="economy-select" maxlength="24" placeholder="Нікнейм суперника"><button id="cwDuelChallenge" class="primary">Кинути виклик</button><div id="cwDuelList" class="cw-list">Завантаження поєдинків…</div>';
 pages.wars.append(duelPanel);
 async function refreshDuels(){const target=document.getElementById('cwDuelList');try{const d=await cwApi('/api/game/duels');target.replaceChildren();if(!d.duels.length){target.textContent='Поєдинків поки немає.';return;}d.duels.forEach(x=>{const row=document.createElement('div');row.className='cw-list-item';const meIsA=x.is_challenger;const enemy=meIsA?x.opponent:x.challenger;const myHp=meIsA?x.challenger_hp:x.opponent_hp,enemyHp=meIsA?x.opponent_hp:x.challenger_hp;const title=document.createElement('b');title.textContent=enemy+' · '+(x.status==='pending'?'очікує відповіді':x.status==='active'?'активний':'завершений');const meta=document.createElement('small');meta.textContent='Твоє здоров’я '+myHp+'/100 · суперник '+enemyHp+'/100'+(x.status==='finished'?' · переможець: '+(x.winner||'—'):'');row.append(title,meta);if(x.status==='pending'&&x.is_opponent){for(const accept of [true,false]){const b=document.createElement('button');b.className='secondary';b.textContent=accept?'Прийняти':'Відхилити';b.addEventListener('click',async()=>{try{await cwApi('/api/game/duels/'+encodeURIComponent(x.id)+'/respond',{method:'POST',body:JSON.stringify({accept})});await refreshDuels();}catch(e){notify(e.message);}});row.append(b);}}if(x.status==='active'&&x.is_my_turn){for(const type of ['normal','ram']){const b=document.createElement('button');b.className='secondary';b.textContent=type==='normal'?'Удар · 10':'Таран · 25 / +500 XP';b.addEventListener('click',async()=>{try{await cwApi('/api/game/duels/'+encodeURIComponent(x.id)+'/attack',{method:'POST',body:JSON.stringify({type})});await refreshDuels();await cwRefreshGameProfile();}catch(e){notify(e.message);}});row.append(b);}}if(x.status==='active'&&!x.is_my_turn){const wait=document.createElement('small');wait.textContent='Очікуємо хід суперника';row.append(wait);}target.append(row);});}catch(e){target.textContent='Не вдалося завантажити поєдинки: '+e.message;}}
 document.getElementById('cwDuelChallenge').addEventListener('click',async()=>{const nickname=document.getElementById('cwDuelNickname').value.trim();if(!nickname){notify('Введи нікнейм суперника.');return;}try{await cwApi('/api/game/duels/challenge',{method:'POST',body:JSON.stringify({nickname})});notify('Виклик надіслано.');document.getElementById('cwDuelNickname').value='';await refreshDuels();}catch(e){notify(e.message);}});
 document.querySelector('[data-tab="wars"]')?.addEventListener('click',refreshDuels);


 const articles=document.createElement('div');
 articles.innerHTML=`
  <section class="cw-card">
   <div class="cw-tabs" id="cwArticleTabs">
    <button class="active" data-filter="all">Всі</button><button data-filter="best">Найкращі</button>
    <button data-filter="guides">Гайди</button><button data-filter="subs">Підписки</button>
   </div>
   <button class="secondary" id="cwLanguage">Всі: всіма мовами</button>
  </section>
  <section class="cw-card" id="cwArticleList"><h3>Статті спільноти</h3><p class="cw-muted">Читай і публікуй статті без входу в акаунт.</p></section>
  <button class="cw-fab" id="cwCreateArticle" aria-label="Створити статтю">+</button>`;
 pages.articles.appendChild(articles);
 const articleEditor=document.createElement('section');
 articleEditor.className='cw-card';
 articleEditor.innerHTML=`<h2>Нова стаття</h2>
 <select id="cwArticleType" class="economy-select"><option value="post">Поза газетною (авторський пост)</option><option value="news">Новина</option><option value="guide">Посібник</option></select>
 <div class="cw-row"><select id="cwArticleLanguage" class="economy-select"><option value="uk">🇺🇦 Українська</option><option value="en">🇬🇧 English</option></select><select id="cwArticleCategory" class="economy-select"><option value="general">Без категорії</option><option value="guide">Гайди</option><option value="news">Ігрові події</option><option value="opinion">Думка</option></select></div>
 <div class="cw-editor-toolbar">
 <button type="button" data-cmd="bold" title="Жирний"><b>B</b></button><button type="button" data-cmd="italic" title="Курсив"><i>I</i></button><button type="button" data-cmd="underline" title="Підкреслення"><u>U</u></button><button type="button" data-cmd="insertUnorderedList" title="Список">☷</button><button type="button" data-cmd="formatBlock" data-value="blockquote" title="Цитата">❞</button><button type="button" data-cmd="justifyLeft" title="Ліворуч">≡</button><button type="button" data-cmd="justifyCenter" title="По центру">☰</button><button type="button" data-cmd="justifyRight" title="Праворуч">≣</button>
 <button type="button" id="cwEditorLink" title="Посилання">🔗</button><button type="button" id="cwEditorImage" title="Зображення за URL">▧ URL</button><button type="button" id="cwEditorGallery" title="Додати з галереї">▣ Галерея</button><button type="button" id="cwEditorVideo" title="Відео за URL">▶</button><button type="button" data-cmd="formatBlock" data-value="h2" title="Заголовок">H₂</button><button type="button" data-cmd="strikeThrough" title="Закреслення">S̶</button>
 </div>
 <input id="cwArticleTitle" class="economy-select" maxlength="100" placeholder="Заголовок">
 <div id="cwArticleBody" class="cw-rich-editor" contenteditable="true" data-placeholder="Текст статті…"></div><input id="cwArticleGallery" type="file" accept="image/png,image/jpeg,image/webp" hidden>
 <div class="cw-row"><button class="secondary" id="cwArticlePreview">Попередній перегляд</button><button class="primary" id="cwPublishArticle">Опублікувати</button></div>
 <div id="cwArticlePreviewBox" class="cw-article-preview" hidden></div><div id="cwMyArticles" class="cw-list"></div>`;
 pages.articles.appendChild(articleEditor);
 let cwEditingArticle=null;
 const cwArticleKeys=JSON.parse(localStorage.getItem('cw_article_edit_keys')||'{}');
 articleEditor.querySelectorAll('[data-cmd]').forEach(btn=>btn.addEventListener('click',()=>{
  const editor=document.getElementById('cwArticleBody');editor.focus();
  const cmd=btn.dataset.cmd;
  if(cmd==='formatBlock')document.execCommand(cmd,false,btn.dataset.value);
  else document.execCommand(cmd,false,null);
 }));
 document.getElementById('cwEditorLink').addEventListener('click',()=>{
  const url=prompt('Встав URL посилання (https://…)');if(url&&/^https:\/\//i.test(url)){document.getElementById('cwArticleBody').focus();document.execCommand('createLink',false,url);}
  else if(url)notify('Дозволені лише HTTPS-посилання.');
 });
 document.getElementById('cwEditorImage').addEventListener('click',()=>{
  const url=prompt('Встав HTTPS-посилання на зображення');if(url&&/^https:\/\//i.test(url)){document.getElementById('cwArticleBody').focus();document.execCommand('insertImage',false,url);}
  else if(url)notify('Потрібне HTTPS-посилання.');
 });
 document.getElementById('cwEditorGallery').addEventListener('click',()=>document.getElementById('cwArticleGallery').click());
 document.getElementById('cwArticleGallery').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;if(f.size>3*1024*1024){notify('Зображення для статті має бути до 3 МБ.');return;}if(!/^image\/(png|jpeg|webp)$/.test(f.type)){notify('Підтримуються JPG, PNG або WEBP.');return;}const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=reject;r.readAsDataURL(f);});const editor=document.getElementById('cwArticleBody');editor.focus();document.execCommand('insertImage',false,data);e.target.value='';});
 document.getElementById('cwEditorVideo').addEventListener('click',()=>{
  const url=prompt('Встав HTTPS-посилання на відео');if(url&&/^https:\/\//i.test(url)){const a=document.createElement('a');a.href=url;a.textContent='Відео';a.target='_blank';document.getElementById('cwArticleBody').append(a);}
  else if(url)notify('Потрібне HTTPS-посилання.');
 });
 document.getElementById('cwArticlePreview').addEventListener('click',()=>{
  const box=document.getElementById('cwArticlePreviewBox');box.hidden=false;
  box.innerHTML='<h3></h3>'+document.getElementById('cwArticleBody').innerHTML;
  box.querySelector('h3').textContent=document.getElementById('cwArticleTitle').value||'Попередній перегляд';
 });
 function cwArticleVoterKey(){let k=localStorage.getItem('cw_article_voter_key');if(!k){k=(crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random()).replace(/-/g,'');localStorage.setItem('cw_article_voter_key',k);}return k;}
 async function cwLoadArticles(){
  const list=document.getElementById('cwMyArticles');
  const feed=document.getElementById('cwArticleList');
  try{
   const d=await cwPublicApi('/api/public/articles');
   list.replaceChildren();
   if(feed){feed.replaceChildren();const heading=document.createElement('h3');heading.textContent='Статті спільноти';feed.append(heading);}
   d.articles.forEach(x=>{
    if(feed){
     const post=document.createElement('article');post.className='cw-article';
     const t=document.createElement('strong');t.textContent=x.title;
     const author=document.createElement('small');author.textContent=(x.author||'Гість')+' · '+x.category;
     const body=document.createElement('div');body.className='cw-article-body';body.innerHTML=x.body;
     post.append(t,author,body);
     const actions=document.createElement('div');actions.className='cw-article-actions';const up=document.createElement('button');up.className='secondary';up.textContent='＋ '+(x.score||0);const down=document.createElement('button');down.className='secondary';down.textContent='−';const commentsBtn=document.createElement('button');commentsBtn.className='secondary';commentsBtn.textContent='Коментарі ('+(x.comments||0)+')';actions.append(up,down,commentsBtn);post.append(actions);
     const vote=async value=>{try{const d=await cwPublicApi('/api/public/articles/'+x.id+'/vote',{method:'POST',body:JSON.stringify({voterKey:cwArticleVoterKey(),value})});up.textContent='＋ '+d.score;await cwLoadArticles();}catch(e){notify(e.message);}};up.onclick=()=>vote(1);down.onclick=()=>vote(-1);
     const commentBox=document.createElement('div');commentBox.className='cw-article-comments';commentBox.hidden=true;commentsBtn.onclick=async()=>{commentBox.hidden=!commentBox.hidden;if(!commentBox.hidden){try{const d=await cwPublicApi('/api/public/articles/'+x.id+'/comments');commentBox.replaceChildren();d.comments.forEach(c=>{const line=document.createElement('p');line.textContent=c.author+': '+c.body;commentBox.append(line);});const input=document.createElement('input');input.className='economy-select';input.maxLength=1000;input.placeholder='Написати коментар';const send=document.createElement('button');send.className='secondary';send.textContent='Надіслати';send.onclick=async()=>{try{await cwPublicApi('/api/public/articles/'+x.id+'/comments',{method:'POST',body:JSON.stringify({author:localStorage.getItem('cw_nickname')||'Гість',body:input.value})});const latest=await cwPublicApi('/api/public/articles/'+x.id+'/comments');commentBox.replaceChildren();latest.comments.forEach(c=>{const line=document.createElement('p');line.textContent=c.author+': '+c.body;commentBox.append(line);});input.value='';}catch(e){notify(e.message);}};commentBox.append(input,send);}catch(e){notify(e.message);}}};post.append(commentBox);feed.append(post);
    }
    const card=document.createElement('div');card.className='cw-list-item';
    const info=document.createElement('div');info.className='cw-item-main';
    const title=document.createElement('b');title.textContent=x.title;
    const meta=document.createElement('small');meta.textContent=(x.author||'Гість')+' · '+new Date(x.created_at).toLocaleDateString('uk-UA');
    info.append(title,meta);card.append(info);
    if(cwArticleKeys[x.id]){const edit=document.createElement('button');edit.className='secondary';edit.textContent='Редагувати';edit.addEventListener('click',()=>{
      cwEditingArticle={id:x.id,editKey:cwArticleKeys[x.id]};
      document.getElementById('cwArticleTitle').value=x.title;
      document.getElementById('cwArticleBody').innerHTML=x.body;
      document.getElementById('cwArticleCategory').value=x.category||'general';
      document.getElementById('cwPublishArticle').textContent='Зберегти зміни';
      articleEditor.scrollIntoView({behavior:'smooth'});
    });card.append(edit);}
    list.append(card);
   });
   if(!d.articles.length&&feed){const empty=document.createElement('p');empty.className='cw-muted';empty.textContent='Поки що статей немає. Можеш опублікувати першу без акаунта.';feed.append(empty);}
  }catch(e){if(feed)feed.textContent='Не вдалося завантажити статті: '+e.message;}
 }
 document.getElementById('cwPublishArticle').addEventListener('click',async()=>{
  const editKey=cwEditingArticle?.editKey||Array.from(crypto.getRandomValues(new Uint8Array(24))).map(x=>x.toString(16).padStart(2,'0')).join('');
  const payload={
   author:localStorage.getItem('cw_nickname')||'Гість',
   title:document.getElementById('cwArticleTitle').value,
   body:document.getElementById('cwArticleBody').innerHTML,
   category:document.getElementById('cwArticleCategory').value,
   editKey
  };
  try{
   if(cwEditingArticle){
    await cwPublicApi('/api/public/articles/'+cwEditingArticle.id,{method:'PUT',body:JSON.stringify(payload)});
   }else{
    const created=await cwPublicApi('/api/public/articles',{method:'POST',body:JSON.stringify(payload)});
    cwArticleKeys[created.id]=editKey;localStorage.setItem('cw_article_edit_keys',JSON.stringify(cwArticleKeys));
   }
   cwEditingArticle=null;document.getElementById('cwPublishArticle').textContent='Опублікувати';
   document.getElementById('cwArticleTitle').value='';
   document.getElementById('cwArticleBody').innerHTML='';
   await cwLoadArticles();
   notify('Статтю опубліковано без входу в акаунт.');
  }catch(e){notify(e.message);}
 });

 async function cwRefreshPublicStats(){
  try{
   const d=await cwPublicApi('/api/public/stats');
   const set=(id,value)=>{const el=document.getElementById(id);if(el)el.textContent=Number(value||0).toLocaleString('uk-UA');};
   set('cwStatPlayers',d.players);set('cwStatRegions',d.regions);set('cwStatArticles',d.articles);
  }catch(e){['cwStatPlayers','cwStatRegions','cwStatArticles'].forEach(id=>{const el=document.getElementById(id);if(el&&el.textContent.trim()==='—')el.textContent='0';});console.warn('Public stats unavailable',e);}
 }
 cwRefreshPublicStats();
 async function cwRefreshPlayers(){
 const target=document.getElementById('cwPlayersDirectory');if(!target)return;
 try{
  const q=document.getElementById('cwPlayersSearch')?.value||'';
  const d=await cwApi('/api/players?q='+encodeURIComponent(q));target.replaceChildren();
  if(!d.players.length){target.textContent='Поки що гравців немає.';return;}
  d.players.forEach(p=>{const row=document.createElement('div');row.className='cw-list-item';const avatar=document.createElement('button');avatar.type='button';avatar.className='cw-link-button';avatar.textContent=p.avatar||'👤';avatar.setAttribute('aria-label','Відкрити профіль '+p.nickname);avatar.addEventListener('click',()=>window.cwOpenPublicProfile?.(p.id));const name=document.createElement('button');name.type='button';name.className='cw-link-button';name.textContent=p.nickname;name.addEventListener('click',()=>window.cwOpenPublicProfile?.(p.id));const meta=document.createElement('small');meta.textContent=(p.home_region||'Регіон не вказано')+' · '+p.xp+' HP · рівень '+p.level+' · мечів '+(p.swords||0);row.append(avatar,name,meta);target.append(row);});
 }catch(e){target.textContent='Не вдалося завантажити гравців: '+e.message;}
}
async function cwRefreshGameProfile(){
  try{const d=await cwApi('/api/game/profile');const p=d.profile;const nick=document.getElementById('cwProfileNickname');if(nick)nick.textContent=document.getElementById('accountNickView')?.textContent||'Гравець';const meta=document.querySelector('#page-profile .cw-list-item small');if(meta)meta.textContent='Місце у рейтингу: '+d.rank+' із '+d.totalPlayers;const level=document.querySelector('#page-profile .cw-row b');if(level)level.textContent='Рівень: '+p.level+' · '+p.xp+' HP';const av=document.querySelector('#page-profile .cw-avatar');if(av)av.textContent=p.avatar||'👤';const xp=document.getElementById('cwPlayerXp');if(xp)xp.textContent=p.xp+' HP';const lv=document.getElementById('cwPlayerLevel');if(lv)lv.textContent='Рівень: '+p.level;const board=await cwApi('/api/game/leaderboard');const target=document.getElementById('cwLeaderboard');if(target){target.replaceChildren();board.players.slice(0,10).forEach(g=>{const row=document.createElement('div');row.className='cw-list-item';const label=document.createElement('button');label.type='button';label.className='cw-link-button';label.textContent='#'+g.rank+' '+g.nickname;label.addEventListener('click',()=>window.cwOpenPublicProfile?.(g.id));const meta=document.createElement('small');meta.textContent='Рівень '+g.level+' · '+g.xp+' HP · мечів '+(g.swords||0);row.append(label,meta);target.append(row);});}}catch(e){}
 }
 window.cwRefreshGameProfile=cwRefreshGameProfile;
 async function cwRefreshMine(){
  const r=window.cwSelectedRegion;if(!r){document.getElementById('cwMineRegion').textContent='Спочатку обери регіон на мапі.';return;}
  try{const d=await cwApi('/api/game/region/'+encodeURIComponent(r.key)+'?name='+encodeURIComponent(r.name));document.getElementById('cwMineRegion').textContent=r.name;document.getElementById('cwGold').textContent=d.region.gold;document.getElementById('cwEnergy').textContent=d.profile.energy+'/500';document.getElementById('cwXp').textContent=d.profile.xp+' HP · рівень '+d.profile.level;
  const refill=document.getElementById('cwGoldRefill');if(refill){const ms=Math.max(0,d.region.nextRefillAt-Date.now());const h=Math.floor(ms/3600000),m=Math.floor((ms%3600000)/60000);refill.textContent='Наступне поповнення: '+h+' год '+m+' хв · +100 золота';}
  window.cwMineWallet=d.region;}catch(e){notify(e.message);}
 }
 window.cwRefreshMine=cwRefreshMine;
 document.getElementById('cwMineBtn').addEventListener('click',async()=>{const r=window.cwSelectedRegion;if(!r){notify('Спочатку обери регіон на мапі.');return;}try{const d=await cwApi('/api/game/region/'+encodeURIComponent(r.key)+'/mine',{method:'POST',body:JSON.stringify({name:r.name,energy:Number(document.getElementById('cwMineEnergy').value)})});notify('Видобуто '+d.earnedGold+' золота та отримано '+d.earnedXp+' HP.');await cwRefreshMine();await cwRefreshGameProfile();}catch(e){notify(e.message);}});
 document.getElementById('cwBuyEnergyBtn').addEventListener('click',async()=>{const r=window.cwSelectedRegion;if(!r){notify('Спочатку обери регіон.');return;}try{const d=await cwApi('/api/game/energy/buy',{method:'POST',body:JSON.stringify({amount:Number(document.getElementById('cwBuyEnergy').value),regionKey:r.key,regionName:r.name})});notify('Придбано '+d.bought+' енергії.');await cwRefreshMine();}catch(e){notify(e.message);}});
 document.querySelector('[data-tab="work"]')?.addEventListener('click',cwRefreshMine);
 document.querySelector('[data-tab="inventory"]')?.addEventListener('click',async()=>{await cwRefreshMine();const g=document.getElementById('cwGold')?.textContent||'500';const e=document.getElementById('cwEnergy')?.textContent||'500/500';document.getElementById('cwInventoryGold').textContent=g;document.getElementById('cwInventoryEnergy').textContent=e;});
 document.getElementById('cwInventoryBuy')?.addEventListener('click',async()=>{const r=window.cwSelectedRegion;if(!r){notify('Спочатку обери регіон на карті.');return;}const amount=Number(document.getElementById('cwInventoryAmount').value);try{const d=await cwApi('/api/game/energy/buy',{method:'POST',body:JSON.stringify({amount,regionKey:r.key,regionName:r.name})});notify('Придбано '+d.bought+' енергетиків.');await cwRefreshMine();document.getElementById('cwInventoryGold').textContent=d.wallet.gold;document.getElementById('cwInventoryEnergy').textContent=d.profile.energy+'/500';}catch(e){notify(e.message);}});
 document.querySelector('[data-tab="profile"]')?.addEventListener('click',cwRefreshGameProfile);
 document.querySelector('[data-tab="profile"]')?.addEventListener('click',cwRefreshPlayers);
 document.getElementById('cwPlayersRefresh')?.addEventListener('click',cwRefreshPlayers);
 document.getElementById('cwPlayersSearchBtn')?.addEventListener('click',cwRefreshPlayers);
 document.querySelector('[data-tab="articles"]')?.addEventListener('click',cwLoadArticles);
  const profileExtra=document.createElement('section');
 profileExtra.className='cw-card';
 profileExtra.innerHTML=`
  <h2>Профіль гравця</h2>
  <div class="cw-list-item"><div class="cw-avatar">👤</div><div class="cw-item-main"><b id="cwProfileNickname">Гравець Chemis World</b><small>Місце у рейтингу: —</small><div class="cw-progress"><i></i></div></div></div>
  <div class="cw-row"><b id="cwPlayerLevel">Рівень: 1</b><b class="cw-yellow" id="cwPlayerXp">0 XP</b></div>
  <div class="cw-row"><input id="cwAvatarChoice" class="economy-select" value="🌟" maxlength="8" style="max-width:100px"><button class="secondary" id="cwBuyAvatar">Створити аватар · 50 золота</button></div>
  <button class="primary" id="cwGoAccount">Налаштувати онлайн-профіль</button>
  <h3>Персоналізація акаунта</h3>
  <label class="economy-label" for="cwAccountBio">Біографія · до 120 символів</label><textarea id="cwAccountBio" class="economy-select" maxlength="120" rows="2" placeholder="Розкажи про себе"></textarea>
  <label class="economy-label" for="cwAccountStatus">Статус · до 48 символів</label><input id="cwAccountStatus" class="economy-select" maxlength="48" placeholder="Твій статус">
  <label class="economy-label" for="cwAccountAvatar">Аватар (емодзі)</label><input id="cwAccountAvatar" class="economy-select" maxlength="8" value="👤">
  <label class="economy-label" for="cwAccountCover">Колір обкладинки</label><input id="cwAccountCover" type="color" value="#183153" style="width:100%;height:42px">
  <label class="economy-label" for="cwAccountPrivacy">Приватність профілю</label><select id="cwAccountPrivacy" class="economy-select"><option value="public">Публічний</option><option value="friends">Лише друзі</option><option value="private">Приватний</option></select>
  <button class="secondary" id="cwAccountSave">Зберегти профіль</button>
  <h3>Моя статистика</h3><div id="cwAccountStats" class="cw-world-stats"></div>
  <h3>Досягнення та відзнаки</h3><div id="cwAccountAchievements" class="cw-list"></div>
  <h3>Історія активності</h3><div id="cwAccountActivity" class="cw-list"></div>
  <h3>Підписники та підписки</h3><div id="cwAccountFollows" class="cw-list"></div>
  <div class="cw-list-item"><div class="cw-avatar">🏛</div><div class="cw-item-main"><b>Держави та регіони</b><small>Твої політичні й територіальні проєкти</small></div></div>
  <div class="cw-list-item"><div class="cw-avatar">📊</div><div class="cw-item-main"><b>Економіка</b><small>Регіональні та міські бюджети незалежні</small></div></div>
  <h3>Рейтинг гравців</h3><div id="cwLeaderboard" class="cw-list"><p class="cw-muted">Увійди через Google, щоб переглянути рейтинг.</p></div>`;
 pages.profile.insertBefore(profileExtra,pages.profile.firstChild);
 async function cwRefreshAccount51(){
  try{
   const d=await cwApi('/api/account/profile'),p=d.profile;
   const setValue=(id,v)=>{const el=document.getElementById(id);if(el&&document.activeElement!==el)el.value=v??'';};
   setValue('cwAccountBio',p.bio);setValue('cwAccountStatus',p.status);setValue('cwAccountAvatar',p.avatar);setValue('cwAccountCover',p.cover_color);setValue('cwAccountPrivacy',p.visibility);
   const stats=document.getElementById('cwAccountStats');if(stats){stats.replaceChildren();[['Днів у грі',d.game.days],['Друзі',d.counts.friends],['Підписники',d.counts.followers],['Підписки',d.counts.following],['Статті',d.counts.articles],['Посади',d.counts.offices],['Рівень',d.game.level],['Місце в рейтингу','#'+d.game.rank],['Мечі',d.swords],['Партія',d.party?.name||'Безпартійний'],['Досвід',d.game.xp+' XP']].forEach(([k,v])=>{const box=document.createElement('div');box.className='cw-stat';const b=document.createElement('b');b.textContent=v;const sm=document.createElement('small');sm.textContent=k;box.append(b,sm);stats.append(box);});}
   const ach=document.getElementById('cwAccountAchievements');if(ach){ach.replaceChildren();d.achievements.forEach(a=>{const row=document.createElement('div');row.className='cw-list-item';row.textContent='🏅 '+a.achievement_key+' · '+new Date(a.unlocked_at).toLocaleDateString('uk-UA');ach.append(row);});if(!d.achievements.length)ach.textContent='Досягнення з’являтимуться тут у міру гри.';}
   const act=document.getElementById('cwAccountActivity');if(act){act.replaceChildren();d.activity.forEach(a=>{const row=document.createElement('div');row.className='cw-list-item';const b=document.createElement('b');b.textContent=a.title;const sm=document.createElement('small');sm.textContent=(a.details||'')+' · '+new Date(a.created_at).toLocaleString('uk-UA');row.append(b,sm);act.append(row);});if(!d.activity.length)act.textContent='Історія активності поки порожня.';}
   const follows=await cwApi('/api/account/followers');const fb=document.getElementById('cwAccountFollows');if(fb){fb.replaceChildren();const line=document.createElement('div');line.className='cw-list-item';line.textContent='Підписники: '+follows.followers.length+' · Підписки: '+follows.following.length;fb.append(line);}
  }catch(e){console.warn('Account profile unavailable',e);}
 }
 document.getElementById('cwAccountSave')?.addEventListener('click',async()=>{try{await cwApi('/api/account/profile',{method:'PATCH',body:JSON.stringify({bio:document.getElementById('cwAccountBio').value,status:document.getElementById('cwAccountStatus').value,avatar:document.getElementById('cwAccountAvatar').value,coverColor:document.getElementById('cwAccountCover').value,visibility:document.getElementById('cwAccountPrivacy').value})});notify('Профіль збережено.');await cwRefreshAccount51();await cwRefreshGameProfile();}catch(e){notify(e.message);}});
 document.querySelector('[data-tab="profile"]')?.addEventListener('click',cwRefreshAccount51);
  // Bind avatar purchase only after its controls have been inserted into the DOM.
  const buyAvatarButton=document.getElementById('cwBuyAvatar');
  if(buyAvatarButton)buyAvatarButton.addEventListener('click',async()=>{
    const r=window.cwSelectedRegion;
    if(!r){notify('Обери регіон, щоб витратити золото.');return;}
    try{
      await cwApi('/api/game/avatar/buy',{method:'POST',body:JSON.stringify({
        avatar:document.getElementById('cwAvatarChoice')?.value||'🌟',
        regionKey:r.key,regionName:r.name
      })});
      notify('Аватар створено!');
      await cwRefreshMine();
      await cwRefreshGameProfile();
    }catch(e){notify(e.message);}
  });


 async function cwRefreshRegionalPolitics(){
  const r=window.cwSelectedRegion;if(!r)return;
  try{
   const d=await cwApi('/api/game/region/'+encodeURIComponent(r.key)+'/politics');
   const list=document.getElementById('cwRegionalPartyList');list.replaceChildren();
   d.parties.forEach(p=>{const item=document.createElement('div');item.className='cw-list-item';const b=document.createElement('b');b.textContent=p.name;const small=document.createElement('small');small.textContent=p.ideology||'Без ідеології';item.append(b,small);list.append(item);});
   if(!d.parties.length)list.textContent='У регіоні ще немає партій.';
   const e=d.election;document.getElementById('cwElectionStatus').textContent=e?('Вибори: '+e.status+' · доступність '+new Date(e.eligible_at).toLocaleString('uk-UA')):'Вибори можна ініціювати через 3 години після першої партії.';
   document.getElementById('cwPresenceStatus').textContent=d.presence?('Твоє місце перебування: '+d.presence.region_name):'Місце перебування ще не вибране.';
  }catch(e){console.warn('Regional politics:',e);}
 }
 window.cwRefreshRegionalPolitics=cwRefreshRegionalPolitics;
 document.getElementById('cwBuildAcademy')?.addEventListener('click',async()=>{
  const r=window.cwSelectedRegion;if(!r)return notify('Спочатку обери регіон на карті.');
  try{const d=await cwApi('/api/game/region/'+encodeURIComponent(r.key)+'/academy',{method:'POST',body:JSON.stringify({name:r.name})});
   notify('Академію побудовано. Нагорода: 100 золота.');
   document.getElementById('cwAcademyStatus').textContent='Наступне будівництво доступне: '+new Date(d.nextAvailableAt).toLocaleString('uk-UA');
   await cwRefreshMine();
  }catch(e){notify(e.message);}
 });
 document.getElementById('cwCreateRegionalParty')?.addEventListener('click',async()=>{
  const r=window.cwSelectedRegion;if(!r)return notify('Спочатку обери регіон на карті.');
  const payload={regionName:r.name,name:document.getElementById('cwNewPartyName').value,ideology:document.getElementById('cwNewPartyIdeology').value,program:document.getElementById('cwNewPartyProgram').value};
  try{await cwApi('/api/game/region/'+encodeURIComponent(r.key)+'/party',{method:'POST',body:JSON.stringify(payload)});
   notify('Партію створено за 25 золота.');document.getElementById('cwNewPartyName').value='';document.getElementById('cwNewPartyIdeology').value='';document.getElementById('cwNewPartyProgram').value='';
   await cwRefreshMine();await cwRefreshRegionalPolitics();
  }catch(e){notify(e.message);}
 });
 document.getElementById('cwRunRegionalElection')?.addEventListener('click',async()=>{
  const r=window.cwSelectedRegion;if(!r)return notify('Спочатку обери регіон на карті.');
  try{await cwApi('/api/game/region/'+encodeURIComponent(r.key)+'/election',{method:'POST',body:JSON.stringify({name:r.name})});notify('Вибори заплановано.');await cwRefreshRegionalPolitics();}
  catch(e){notify(e.message);}
 });
 document.getElementById('cwTravelRegion')?.addEventListener('click',async()=>{
  const name=document.getElementById('cwFlightRegionName').value.trim(),key=document.getElementById('cwFlightRegionKey').value.trim();
  if(!name||!key)return notify('Вкажи назву та ключ регіону призначення.');
  try{await cwApi('/api/game/travel',{method:'POST',body:JSON.stringify({regionName:name,regionKey:key})});notify('Переліт завершено за 50 золота.');await cwRefreshMine();await cwRefreshRegionalPolitics();}
  catch(e){notify(e.message);}
 });


 // 4.0.0 shared-world dashboard: friends, diplomacy, state treasury, trade, notices and achievements.
 const worldPanel=document.createElement('section');worldPanel.className='cw-card cw-world-panel';worldPanel.id='cwWorld31Panel';
 worldPanel.innerHTML=`<div class="cw-world-head"><div><small>СПІЛЬНИЙ ОНЛАЙН-СВІТ</small><h2>Світ Chemis World</h2></div><span class="live-dot">5.1.0</span></div>
 <div class="cw-world-stats"><div><b id="cwWorldPlayers">0</b><small>Гравців</small></div><div><b id="cwWorldStates">0</b><small>Держав</small></div><div><b id="cwWorldRegions">0</b><small>Регіонів</small></div><div><b id="cwWorldArticles">0</b><small>Статей</small></div></div>
 <h3>Друзі</h3><div class="cw-world-inline"><input id="cwFriendNick" class="economy-select" maxlength="24" placeholder="Нікнейм гравця"><button id="cwFriendSend" class="secondary">Додати</button></div><div id="cwFriendList" class="diplomacy-list">Завантаження друзів…</div>
 <h3>Дипломатія</h3><label class="economy-label" for="cwDiplomacyFrom">Моя держава</label><select id="cwDiplomacyFrom" class="economy-select"></select><label class="economy-label" for="cwDiplomacyTo">Держава-партнер</label><select id="cwDiplomacyTo" class="economy-select"></select><select id="cwTreatyType" class="economy-select"><option value="friendship">Договір про дружбу</option><option value="non_aggression">Пакт про ненапад</option><option value="trade">Торгова угода</option><option value="alliance">Союзний договір</option><option value="research">Наукове співробітництво</option></select><textarea id="cwTreatyTerms" class="economy-select" rows="2" maxlength="1000" placeholder="Умови договору (необов'язково)"></textarea><button id="cwTreatySend" class="secondary">Надіслати дипломатичну пропозицію</button><div id="cwTreatyList" class="diplomacy-list"></div>
 <h3>Державний бюджет</h3><select id="cwTreasuryState" class="economy-select"></select><div class="cw-treasury-balance">Баланс: <b id="cwTreasuryBalance">0 CW₵</b></div><label class="economy-label" for="cwStateTax">Податкова ставка</label><select id="cwStateTax" class="economy-select"><option value="0">0%</option><option value="5">5%</option><option value="10">10%</option><option value="15">15%</option><option value="20">20%</option><option value="25">25%</option></select><button id="cwStateTaxSave" class="secondary">Зберегти податок</button><button id="cwStateCollect" class="primary">Зібрати податки (раз на 6 годин)</button><select id="cwStateProject" class="economy-select"><option>Дороги</option><option>Школи</option><option>Лікарні</option><option>Енергетика</option><option>Цифрова інфраструктура</option></select><button id="cwStateProjectBuy" class="secondary">Фінансувати державний проєкт</button><div id="cwTreasuryLedger" class="diplomacy-list"></div>
 <h3>Економіка регіону</h3><input id="cwRegionKey" class="economy-select" maxlength="180" placeholder="Ключ регіону зі складу держави"><button id="cwRegionEconomyLoad" class="secondary">Завантажити економіку регіону</button><div id="cwRegionEconomyInfo" class="diplomacy-list">Обери свою державу та введи ключ її території.</div><select id="cwRegionTax" class="economy-select"><option value="0">0%</option><option value="5">5%</option><option value="10" selected>10%</option><option value="15">15%</option><option value="20">20%</option><option value="25">25%</option></select><button id="cwRegionTaxSave" class="secondary">Зберегти регіональний податок</button><button id="cwRegionCollect" class="primary">Зібрати регіональний дохід</button><select id="cwRegionBuilding" class="economy-select"><option>Школа</option><option>Лікарня</option><option>Дорога</option><option>Культурний центр</option><option>Водопостачання</option></select><button id="cwRegionBuild" class="secondary">Побудувати об’єкт</button><h3>Населення та добробут регіону</h3><div id="cwDemographicsInfo" class="diplomacy-list">Завантаж показники регіону.</div><h3>Торгівля між державами</h3><input id="cwTradeAmount" class="economy-select" type="number" min="1" max="10000000" placeholder="Сума CW₵"><input id="cwTradeNote" class="economy-select" maxlength="300" placeholder="Призначення платежу"><button id="cwTradeSend" class="secondary">Запропонувати переказ</button><div id="cwTradeList" class="diplomacy-list"></div>
 <h3>Сповіщення <span id="cwUnreadCount">0</span></h3><button id="cwNotificationsRead" class="secondary">Позначити всі прочитаними</button><div id="cwNotificationList" class="diplomacy-list"></div>
 <h3>Досягнення</h3><div id="cwAchievementList" class="diplomacy-list"></div><h3>Стрічка подій світу</h3><div id="cwWorldEventList" class="diplomacy-list"></div>`;
 pages.profile.append(worldPanel);
 const cwSetText=(id,value)=>{const el=document.getElementById(id);if(el)el.textContent=String(value??0);};
 async function cwRefreshWorld31(){
  try{
   const [me,dash,friends,diplomacy,notifications,achievements,trades]=await Promise.all([cwApi('/api/me'),cwApi('/api/v3/dashboard'),cwApi('/api/friends'),cwApi('/api/diplomacy'),cwApi('/api/notifications'),cwApi('/api/achievements'),cwApi('/api/trade/offers')]);
   const myNickname=me.player.nickname;
   cwSetText('cwWorldPlayers',dash.stats.players);cwSetText('cwWorldStates',dash.stats.states);cwSetText('cwWorldRegions',dash.stats.regions);cwSetText('cwWorldArticles',dash.stats.articles);
   const fbox=document.getElementById('cwFriendList');fbox.replaceChildren();friends.friends.forEach(f=>{const row=document.createElement('div');row.className='cw-list-item';const label=document.createElement('b');label.textContent=f.nickname;const meta=document.createElement('small');meta.textContent=f.status==='accepted'?'У друзях':(f.direction==='incoming'?'Вхідний запит':'Очікує відповіді');row.append(label,meta);if(f.status==='pending'&&f.direction==='incoming'){for(const [yes,txt] of [[true,'Прийняти'],[false,'Відхилити']]){const b=document.createElement('button');b.className='secondary';b.textContent=txt;b.onclick=async()=>{try{await cwApi('/api/friends/'+f.id+'/respond',{method:'POST',body:JSON.stringify({accept:yes})});await cwRefreshWorld31();}catch(e){notify(e.message);}};row.append(b);}}fbox.append(row);});if(!friends.friends.length)fbox.textContent='Поки що друзів немає.';
   const states=diplomacy.states;for(const id of ['cwDiplomacyFrom','cwTreasuryState']){const sel=document.getElementById(id),old=sel.value;sel.replaceChildren();states.filter(x=>x.owner===myNickname).forEach(st=>{const op=document.createElement('option');op.value=st.id;op.textContent=st.name+' · '+st.owner;sel.append(op);});if(old)sel.value=old;}
   const target=document.getElementById('cwDiplomacyTo');const oldTarget=target.value;target.replaceChildren();states.forEach(st=>{const op=document.createElement('option');op.value=st.id;op.textContent=st.name+' · '+st.owner;target.append(op);});if(oldTarget)target.value=oldTarget;
   const tbox=document.getElementById('cwTreatyList');tbox.replaceChildren();diplomacy.treaties.forEach(t=>{const row=document.createElement('div');row.className='cw-list-item';const b=document.createElement('b');b.textContent=t.title;const meta=document.createElement('small');meta.textContent=t.proposer_name+' → '+t.target_name+' · '+t.status;row.append(b,meta);if(t.status==='pending'&&states.some(st=>st.id===t.target_state_id&&st.owner===myNickname)){const accept=document.createElement('button');accept.className='secondary';accept.textContent='Прийняти';accept.onclick=async()=>{try{await cwApi('/api/diplomacy/'+t.id+'/respond',{method:'POST',body:JSON.stringify({accept:true})});await cwRefreshWorld31();}catch(e){notify(e.message);}};const reject=document.createElement('button');reject.className='secondary';reject.textContent='Відхилити';reject.onclick=async()=>{try{await cwApi('/api/diplomacy/'+t.id+'/respond',{method:'POST',body:JSON.stringify({accept:false})});await cwRefreshWorld31();}catch(e){notify(e.message);}};row.append(accept,reject);}tbox.append(row);});if(!diplomacy.treaties.length)tbox.textContent='Дипломатичних договорів поки немає.';
   const nbox=document.getElementById('cwNotificationList');nbox.replaceChildren();cwSetText('cwUnreadCount',notifications.unread);notifications.notifications.slice(0,15).forEach(n=>{const row=document.createElement('div');row.className='cw-list-item';const b=document.createElement('b');b.textContent=n.title;const meta=document.createElement('small');meta.textContent=n.body+' · '+new Date(n.created_at).toLocaleString('uk-UA');row.append(b,meta);if(n.kind==='party_invite'&&n.data?.partyInviteId){const yes=document.createElement('button');yes.className='secondary';yes.textContent='Прийняти';yes.addEventListener('click',async()=>{try{await cwApi('/api/game/party-invites/'+encodeURIComponent(n.data.partyInviteId)+'/respond',{method:'POST',body:JSON.stringify({accept:true})});notify('Ти приєднався до партії.');await cwRefreshWorld31();}catch(e){notify(e.message);}});const no=document.createElement('button');no.className='secondary';no.textContent='Відхилити';no.addEventListener('click',async()=>{try{await cwApi('/api/game/party-invites/'+encodeURIComponent(n.data.partyInviteId)+'/respond',{method:'POST',body:JSON.stringify({accept:false})});notify('Запрошення відхилено.');await cwRefreshWorld31();}catch(e){notify(e.message);}});row.append(yes,no);}if(n.kind==='friend_request'&&n.data?.friendRequestId){for(const accept of [true,false]){const b=document.createElement('button');b.className='secondary';b.textContent=accept?'Прийняти в друзі':'Відхилити';b.addEventListener('click',async()=>{try{await cwApi('/api/friends/'+encodeURIComponent(n.data.friendRequestId)+'/respond',{method:'POST',body:JSON.stringify({accept})});notify(accept?'Запит у друзі прийнято.':'Запит відхилено.');await cwRefreshWorld31();}catch(e){notify(e.message);}});row.append(b);}}if(n.kind==='duel_invite'&&n.data?.duelId){for(const accept of [true,false]){const b=document.createElement('button');b.className='secondary';b.textContent=accept?'Прийняти поєдинок':'Відхилити';b.addEventListener('click',async()=>{try{await cwApi('/api/game/duels/'+encodeURIComponent(n.data.duelId)+'/respond',{method:'POST',body:JSON.stringify({accept})});notify(accept?'Виклик прийнято.':'Виклик відхилено.');await cwRefreshWorld31();await refreshDuels();}catch(e){notify(e.message);}});row.append(b);}}nbox.append(row);});if(!notifications.notifications.length)nbox.textContent='Нових сповіщень немає.';
   const abox=document.getElementById('cwAchievementList');abox.replaceChildren();achievements.achievements.forEach(a=>{const row=document.createElement('div');row.className='cw-list-item';const b=document.createElement('b');b.textContent=(a.unlocked?'🏅 ':'🔒 ')+a.title;const meta=document.createElement('small');meta.textContent=a.description;row.append(b,meta);abox.append(row);});
   const ebox=document.getElementById('cwWorldEventList');ebox.replaceChildren();dash.events.forEach(e=>{const row=document.createElement('div');row.className='cw-list-item';const b=document.createElement('b');b.textContent=e.title;const meta=document.createElement('small');meta.textContent=(e.actor||'Світ')+' · '+e.body+' · '+new Date(e.created_at).toLocaleString('uk-UA');row.append(b,meta);ebox.append(row);});if(!dash.events.length)ebox.textContent='Подій поки немає.';
   const trbox=document.getElementById('cwTradeList');trbox.replaceChildren();trades.offers.forEach(o=>{const row=document.createElement('div');row.className='cw-list-item';const b=document.createElement('b');b.textContent=o.from_state_name+' → '+o.to_state_name+' · '+o.amount+' CW₵';const meta=document.createElement('small');meta.textContent=o.note+' · '+o.status;row.append(b,meta);if(o.status==='pending'&&states.some(st=>st.id===o.to_state_id&&st.owner===myNickname)){const btn=document.createElement('button');btn.className='secondary';btn.textContent='Прийняти переказ';btn.onclick=async()=>{try{await cwApi('/api/trade/offers/'+o.id+'/respond',{method:'POST',body:JSON.stringify({accept:true})});await cwRefreshWorld31();}catch(e){notify(e.message);}};row.append(btn);}trbox.append(row);});if(!trades.offers.length)trbox.textContent='Торгових пропозицій поки немає.';
   await cwRefreshTreasury31();
  }catch(e){notify('Онлайн-світ: '+e.message);}
 }
 async function cwRefreshTreasury31(){const id=document.getElementById('cwTreasuryState')?.value;if(!id)return;try{const d=await cwApi('/api/states/'+id+'/treasury');cwSetText('cwTreasuryBalance',Number(d.treasury.balance).toLocaleString('uk-UA')+' CW₵');document.getElementById('cwStateTax').value=d.treasury.tax_rate;const box=document.getElementById('cwTreasuryLedger');box.replaceChildren();d.ledger.forEach(x=>{const row=document.createElement('div');row.className='cw-list-item';const b=document.createElement('b');b.textContent=x.description+' · '+x.amount+' CW₵';const meta=document.createElement('small');meta.textContent=new Date(x.created_at).toLocaleString('uk-UA');row.append(b,meta);box.append(row);});if(!d.ledger.length)box.textContent='Фінансових операцій поки немає.';}catch(e){cwSetText('cwTreasuryBalance','—');}}
 document.getElementById('cwFriendSend').onclick=async()=>{try{await cwApi('/api/friends/request',{method:'POST',body:JSON.stringify({nickname:document.getElementById('cwFriendNick').value})});document.getElementById('cwFriendNick').value='';notify('Запит у друзі надіслано.');await cwRefreshWorld31();}catch(e){notify(e.message);}};
 document.getElementById('cwTreatySend').onclick=async()=>{try{await cwApi('/api/diplomacy/propose',{method:'POST',body:JSON.stringify({stateId:document.getElementById('cwDiplomacyFrom').value,targetStateId:document.getElementById('cwDiplomacyTo').value,treatyType:document.getElementById('cwTreatyType').value,terms:document.getElementById('cwTreatyTerms').value})});notify('Дипломатичну пропозицію надіслано.');await cwRefreshWorld31();}catch(e){notify(e.message);}};
 document.getElementById('cwTreasuryState').onchange=cwRefreshTreasury31;
 document.getElementById('cwStateTaxSave').onclick=async()=>{try{await cwApi('/api/states/'+document.getElementById('cwTreasuryState').value+'/treasury/tax',{method:'POST',body:JSON.stringify({taxRate:Number(document.getElementById('cwStateTax').value)})});notify('Податкову ставку збережено.');await cwRefreshTreasury31();}catch(e){notify(e.message);}};
 document.getElementById('cwStateCollect').onclick=async()=>{try{const d=await cwApi('/api/states/'+document.getElementById('cwTreasuryState').value+'/treasury/collect',{method:'POST'});notify('Бюджет отримав '+d.income+' CW₵.');await cwRefreshTreasury31();}catch(e){notify(e.message);}};
 document.getElementById('cwStateProjectBuy').onclick=async()=>{try{const d=await cwApi('/api/states/'+document.getElementById('cwTreasuryState').value+'/treasury/project',{method:'POST',body:JSON.stringify({projectType:document.getElementById('cwStateProject').value})});notify('Проєкт профінансовано: '+d.cost+' CW₵.');await cwRefreshTreasury31();}catch(e){notify(e.message);}};
 async function cwLoadRegionEconomy31(){const sid=document.getElementById('cwTreasuryState').value,key=document.getElementById('cwRegionKey').value.trim();if(!sid||!key)return notify('Обери державу та введи ключ регіону.');try{const [d,dem]=await Promise.all([cwApi('/api/states/'+sid+'/regions/'+encodeURIComponent(key)+'/economy'),cwApi('/api/states/'+sid+'/regions/'+encodeURIComponent(key)+'/demographics')]);const e=d.economy;document.getElementById('cwRegionTax').value=e.tax_rate;const box=document.getElementById('cwRegionEconomyInfo');box.replaceChildren();const line=document.createElement('p');line.textContent='Бюджет: '+e.treasury+' CW₵ · Податок: '+e.tax_rate+'% · Інфраструктура: '+e.infrastructure_level+' · Хід: '+e.turn_number;box.append(line);const b=document.createElement('p');b.textContent='Будівлі: '+(d.buildings.map(x=>x.building_type+' · рівень '+x.level).join(', ')||'немає');box.append(b);const x=dem.demographics,dbox=document.getElementById('cwDemographicsInfo');dbox.replaceChildren();[['Населення',x.population.toLocaleString('uk-UA')],['Приріст',x.growth_permille+'‰ на день'],['Охорона здоров’я',x.health_index+'/100'],['Освіта',x.education_index+'/100'],['Зайнятість',x.employment_index+'/100'],['Добробут',x.wellbeing_index+'/100']].forEach(([label,value])=>{const p=document.createElement('p');p.textContent=label+': '+value;dbox.append(p);});const note=document.createElement('small');note.textContent='Ігрова доба дорівнює 24 годинам. Показники розраховуються сервером.';dbox.append(note);}catch(e){notify(e.message);}}
 document.getElementById('cwRegionEconomyLoad').onclick=cwLoadRegionEconomy31;
 document.getElementById('cwRegionTaxSave').onclick=async()=>{const sid=document.getElementById('cwTreasuryState').value,key=document.getElementById('cwRegionKey').value.trim();try{await cwApi('/api/states/'+sid+'/regions/'+encodeURIComponent(key)+'/economy/tax',{method:'POST',body:JSON.stringify({taxRate:Number(document.getElementById('cwRegionTax').value)})});notify('Податок регіону оновлено.');await cwLoadRegionEconomy31();}catch(e){notify(e.message);}};
 document.getElementById('cwRegionCollect').onclick=async()=>{const sid=document.getElementById('cwTreasuryState').value,key=document.getElementById('cwRegionKey').value.trim();try{const d=await cwApi('/api/states/'+sid+'/regions/'+encodeURIComponent(key)+'/economy/collect',{method:'POST'});notify('Регіон отримав '+d.income+' CW₵.');await cwLoadRegionEconomy31();}catch(e){notify(e.message);}};
 document.getElementById('cwRegionBuild').onclick=async()=>{const sid=document.getElementById('cwTreasuryState').value,key=document.getElementById('cwRegionKey').value.trim();try{const d=await cwApi('/api/states/'+sid+'/regions/'+encodeURIComponent(key)+'/buildings',{method:'POST',body:JSON.stringify({buildingType:document.getElementById('cwRegionBuilding').value})});notify('Об’єкт побудовано. Вартість: '+d.cost+' CW₵.');await cwLoadRegionEconomy31();}catch(e){notify(e.message);}};
 document.getElementById('cwTradeSend').onclick=async()=>{try{await cwApi('/api/trade/offers',{method:'POST',body:JSON.stringify({fromStateId:document.getElementById('cwDiplomacyFrom').value,toStateId:document.getElementById('cwDiplomacyTo').value,amount:Number(document.getElementById('cwTradeAmount').value),note:document.getElementById('cwTradeNote').value})});notify('Торгову пропозицію надіслано.');await cwRefreshWorld31();}catch(e){notify(e.message);}};
 document.getElementById('cwNotificationsRead').onclick=async()=>{try{await cwApi('/api/notifications/read',{method:'POST',body:JSON.stringify({all:true})});await cwRefreshWorld31();}catch(e){notify(e.message);}};
 document.querySelector('[data-tab="profile"]')?.addEventListener('click',cwRefreshWorld31);
 document.querySelector('[data-tab="party"]')?.addEventListener('click',cwRenderMyParties);
 setInterval(()=>{if(document.getElementById('page-profile')?.classList.contains('active'))cwRefreshWorld31();},30000);

 // Place the online account controls after the profile overview card.
 const pageTitle=document.getElementById('pageTitle');
 function activate(key){
   if(!pages[key])return;
   Object.entries(pages).forEach(([name,node])=>node.classList.toggle('active',name===key));
   document.querySelectorAll('.cw-bottom [data-tab]').forEach(btn=>btn.classList.toggle('selected',btn.dataset.tab===key || (key==='map'&&btn.dataset.tab==='overview')));
   pageTitle.textContent=labels[key];
   window.scrollTo({top:0,behavior:'instant'});
   if(key==='map'&&typeof map!=='undefined'&&map&&typeof map.invalidateSize==='function'){
     setTimeout(()=>map.invalidateSize(true),80);
   }
   if(key==='profile'){
     const nick=document.getElementById('profileNickname')||document.getElementById('playerNickname');
     const target=document.getElementById('cwProfileNickname');
     if(nick&&target&&nick.value)target.textContent=nick.value;
   }
 }
 window.cwActivatePage=activate;

 // Functional routing for the four overview shortcuts.
 const quickTargets={
   'Політика':{page:'overview',target:'governmentCard',fallback:'stateCard'},
   'Економіка':{page:'work'},
   'Дипломатія':{page:'overview',target:'diplomacyCard'},
   'Профіль':{page:'profile'}
 };
 document.querySelectorAll('.tiles [data-name]').forEach(tile=>{
   tile.setAttribute('type','button');
   tile.addEventListener('click',()=>{
     const route=quickTargets[tile.dataset.name];
     if(!route){notify('Для цього розділу ще не налаштовано перехід.');return;}
     activate(route.page);
     const targetId=route.target||route.fallback;
     const target=targetId?document.getElementById(targetId):null;
     if(target)setTimeout(()=>target.scrollIntoView({behavior:'smooth',block:'start'}),60);
   });
 });

 document.querySelectorAll('.cw-bottom [data-tab]').forEach(btn=>btn.addEventListener('click',()=>activate(btn.dataset.tab)));
 // Map is opened from the map control on overview; preserve the original map feature.
 const oldMapBtn=document.getElementById('mapBtn');
 if(oldMapBtn)oldMapBtn.addEventListener('click',()=>activate('map'));
 const searchBtn=document.getElementById('headerSearchBtn');
 if(searchBtn)searchBtn.addEventListener('click',()=>{
   const query=prompt('Що знайти у Chemis World?');
   if(query&&query.trim()){
     const text=query.trim().toLowerCase();
     const found=[...main.querySelectorAll('h2,h3,b,strong')].find(el=>el.textContent.toLowerCase().includes(text));
     if(found){const parent=found.closest('.cw-page');if(parent)activate(parent.dataset.page);found.scrollIntoView({behavior:'smooth',block:'center'});}
     else if(window.notify)notify('Нічого не знайдено за цим запитом.');
   }
 });
 const menuBtn=document.getElementById('headerMenuBtn');
 const quickMenu=document.createElement('div');quickMenu.className='cw-quick-menu';quickMenu.hidden=true;quickMenu.innerHTML='<button type="button" data-quick="map">🗺️ Перейти на мапу</button><button type="button" data-quick="inventory">🎒 Перейти в інвентар</button><button type="button" data-quick="auction">⚔️ Відкрити аукціон мечів</button>';document.body.appendChild(quickMenu);
 if(menuBtn)menuBtn.setAttribute('aria-expanded','false');
 if(menuBtn)menuBtn.addEventListener('click',()=>{quickMenu.hidden=!quickMenu.hidden;menuBtn.setAttribute('aria-expanded',String(!quickMenu.hidden));});
 document.addEventListener('click',e=>{if(!quickMenu.contains(e.target)&&e.target!==menuBtn){quickMenu.hidden=true;menuBtn?.setAttribute('aria-expanded','false');}});
 quickMenu.addEventListener('click',e=>{const b=e.target.closest('[data-quick]');if(!b)return;const dest=b.dataset.quick;quickMenu.hidden=true;menuBtn?.setAttribute('aria-expanded','false');activate(dest==='map'?'map':'inventory');if(dest==='auction')setTimeout(()=>document.getElementById('cwAuctionPanel')?.scrollIntoView({behavior:'smooth',block:'start'}),80);});
 const helpBtn=document.getElementById('headerHelpBtn');
 if(helpBtn)helpBtn.addEventListener('click',()=>alert('ДОВІДКА CHEMIS WORLD\\n\\nОгляд — головна сторінка та швидкий доступ.\\nСтатті — публікації спільноти.\\nРобота — шахта, ресурси та розвиток регіону.\\nВійни — міжнародна ситуація та ігрові події.\\nПрофіль — акаунт і персональні дані.\\nКарти — вибір території.\\n\\nЯкщо дія недоступна, перевір вхід в акаунт і вибір регіону.'));
 const openMap=document.getElementById('cwOpenMap');
 if(openMap)openMap.addEventListener('click',()=>activate('map'));
 const zoomIn=document.getElementById('cwZoomIn');
 const zoomOut=document.getElementById('cwZoomOut');
 if(zoomIn)zoomIn.addEventListener('click',()=>{if(typeof map!=='undefined'&&map)map.zoomIn();});
 if(zoomOut)zoomOut.addEventListener('click',()=>{if(typeof map!=='undefined'&&map)map.zoomOut();});
 const goAccount=document.getElementById('cwGoAccount');
 if(goAccount)goAccount.addEventListener('click',()=>{activate('profile');document.getElementById('onlineAccountCard')?.scrollIntoView({behavior:'smooth'});});
 const training=document.getElementById('cwPeacefulTraining');
 if(training)training.addEventListener('click',()=>notify('Навчальний модуль буде доступний у наступному оновленні.'));
 const language=document.getElementById('cwLanguage');
 if(language)language.addEventListener('click',()=>notify('Фільтр мов буде підключено до системи статей.'));
 document.querySelectorAll('#cwArticleTabs button').forEach(btn=>btn.addEventListener('click',()=>{
   document.querySelectorAll('#cwArticleTabs button').forEach(b=>b.classList.toggle('active',b===btn));
   document.querySelectorAll('#cwArticleList [data-kind]').forEach(article=>{
     article.style.display=(btn.dataset.filter==='all'||btn.dataset.filter==='subs'||article.dataset.kind===btn.dataset.filter)?'block':'none';
   });
 }));
 const createArticle=document.getElementById('cwCreateArticle');
 if(createArticle)createArticle.addEventListener('click',()=>{
   document.getElementById('cwArticleTitle').scrollIntoView({behavior:'smooth',block:'center'});
   document.getElementById('cwArticleTitle').focus();
 });
 // Online inventory, sword auction and public profiles.
 async function refreshAuction(){const target=document.getElementById('cwAuctionListings');if(!target)return;try{const d=await cwApi('/api/game/auction');target.replaceChildren();if(!d.listings.length){target.textContent='Поки що мечів на продаж немає.';return;}d.listings.forEach(x=>{const row=document.createElement('div');row.className='cw-list-item';const label=document.createElement('b');label.textContent='⚔️ '+x.seller+' · '+x.price+' золота';const buy=document.createElement('button');buy.className='secondary';buy.textContent='Купити';buy.addEventListener('click',async()=>{const r=window.cwSelectedRegion;if(!r){notify('Спочатку обери регіон на мапі.');return;}try{await cwApi('/api/game/auction/'+encodeURIComponent(x.id)+'/buy',{method:'POST',body:JSON.stringify({regionKey:r.key,regionName:r.name})});notify('Меч придбано.');await refreshInventory();}catch(e){notify(e.message);}});row.append(label,buy);target.append(row);});}catch(e){target.textContent='Помилка аукціону: '+e.message;}}
 async function refreshInventory(){const r=window.cwSelectedRegion;try{const q=r?'?regionKey='+encodeURIComponent(r.key)+'&regionName='+encodeURIComponent(r.name):'';const d=await cwApi('/api/game/inventory'+q);document.getElementById('cwRamCount').textContent=d.inventory.batteringRams;document.getElementById('cwInventoryGold').textContent=d.wallet?d.wallet.gold:'Оберіть регіон';document.getElementById('cwInventoryEnergy').textContent=(d.energy??0)+'/500';const own=await cwApi('/api/game/swords/mine');const target=document.getElementById('cwMySwords');target.replaceChildren();const summary=document.createElement('p');summary.className='cw-muted';summary.textContent='Мечів у власності: '+d.inventory.swords+' · на аукціоні: '+d.inventory.listedSwords;target.append(summary);own.swords.forEach(sw=>{const row=document.createElement('div');row.className='cw-list-item';const label=document.createElement('b');label.textContent='⚔️ Меч · '+(sw.status==='listed'?'на аукціоні':'у власності');row.append(label);if(sw.status==='listed'&&sw.listing_id){const cancel=document.createElement('button');cancel.className='secondary';cancel.textContent='Зняти з аукціону';cancel.addEventListener('click',async()=>{try{await cwApi('/api/game/auction/'+encodeURIComponent(sw.listing_id)+'/cancel',{method:'POST',body:JSON.stringify({})});notify('Меч знято з аукціону.');await refreshInventory();}catch(e){notify(e.message);}});row.append(cancel);}if(sw.status==='owned'){const price=document.createElement('input');price.type='number';price.min='5';price.max='20';price.value='10';price.className='economy-select';const list=document.createElement('button');list.className='secondary';list.textContent='Виставити';list.addEventListener('click',async()=>{try{await cwApi('/api/game/auction/list',{method:'POST',body:JSON.stringify({swordId:sw.id,price:Number(price.value)})});notify('Меч виставлено.');await refreshInventory();}catch(e){notify(e.message);}});row.append(price,list);}target.append(row);});await refreshAuction();}catch(e){notify('Інвентар: '+e.message);}}
 document.querySelector('[data-tab="inventory"]')?.addEventListener('click',refreshInventory);
 document.getElementById('cwRamBuy')?.addEventListener('click',async()=>{const r=window.cwSelectedRegion;if(!r){notify('Спочатку обери регіон на мапі.');return;}try{const count=Number(document.getElementById('cwRamBuyAmount').value);const d=await cwApi('/api/game/inventory/ram/buy',{method:'POST',body:JSON.stringify({count,regionKey:r.key,regionName:r.name})});notify('Придбано таранів: '+d.bought);await refreshInventory();}catch(e){notify(e.message);}});

 document.getElementById('cwSwordCreate')?.addEventListener('click',async()=>{const r=window.cwSelectedRegion;if(!r){notify('Спочатку обери регіон на мапі.');return;}try{await cwApi('/api/game/swords/create',{method:'POST',body:JSON.stringify({regionKey:r.key,regionName:r.name})});notify('Меч створено за 25 золота.');await refreshInventory();}catch(e){notify(e.message);}});
 window.cwOpenPublicProfile=async function(playerId){try{const d=await cwApi('/api/account/players/'+encodeURIComponent(playerId));const p=d.profile,box=document.getElementById('cwPublicProfile');box.hidden=false;box.replaceChildren();const h=document.createElement('h2');h.textContent=(p.avatar||'👤')+' '+p.nickname;const info=document.createElement('p');info.textContent='Рівень '+d.game.level+' · місце #'+d.game.rank+' · XP '+d.game.xp+' · мечів '+d.swords+' · партія: '+(d.party?.name||'безпартійний');const bio=document.createElement('p');bio.textContent=p.bio||'Опису немає.';box.append(h,info,bio);if(!d.isSelf){const friend=document.createElement('button');friend.className='secondary';friend.textContent='Додати в друзі';friend.addEventListener('click',async()=>{try{await cwApi('/api/friends/request',{method:'POST',body:JSON.stringify({nickname:p.nickname})});notify('Запит у друзі надіслано.');}catch(e){notify(e.message);}});const invite=document.createElement('button');invite.className='secondary';invite.textContent='Запросити в партію';invite.addEventListener('click',async()=>{try{const mine=await cwApi('/api/game/my-parties');const manageable=mine.parties.filter(x=>['leader','admin'].includes(x.role));if(!manageable.length){notify('Ти не керуєш жодною партією.');return;}let party=manageable[0];if(manageable.length>1){const choice=prompt('Обери партію за номером:\n'+manageable.map((x,i)=>(i+1)+' — '+x.name).join('\n'));const idx=Number(choice)-1;if(!Number.isInteger(idx)||!manageable[idx])return;party=manageable[idx];}await cwApi('/api/game/party/'+encodeURIComponent(party.id)+'/invite',{method:'POST',body:JSON.stringify({nickname:p.nickname})});notify('Запрошення надіслано.');}catch(e){notify(e.message);}});box.append(friend,invite);}const close=document.createElement('button');close.className='secondary';close.textContent='Закрити';close.addEventListener('click',()=>box.hidden=true);box.append(close);activate('profile');box.scrollIntoView({behavior:'smooth',block:'start'});}catch(e){notify(e.message);}};
 const publicBox=document.createElement('section');publicBox.id='cwPublicProfile';publicBox.className='cw-card cw-public-profile';publicBox.hidden=true;pages.profile.prepend(publicBox);
 const swordProfile=document.createElement('section');swordProfile.className='cw-card';swordProfile.id='cwSwordProfile';swordProfile.innerHTML='<h3>Колекція мечів</h3><p id="cwProfileSwordCount">Завантаження…</p><button type="button" class="secondary" id="cwProfileOpenInventory">Відкрити інвентар</button>';pages.profile.append(swordProfile);document.getElementById('cwProfileOpenInventory').addEventListener('click',()=>{activate('inventory');refreshInventory();});document.querySelector('[data-tab="profile"]')?.addEventListener('click',async()=>{try{const d=await cwApi('/api/game/inventory');document.getElementById('cwProfileSwordCount').textContent='Мечів у власності: '+d.inventory.swords+' · виставлено на аукціоні: '+d.inventory.listedSwords;}catch(e){document.getElementById('cwProfileSwordCount').textContent='Статистика мечів недоступна.';}});
 // Start at the overview tab.
 activate('overview');
})();
