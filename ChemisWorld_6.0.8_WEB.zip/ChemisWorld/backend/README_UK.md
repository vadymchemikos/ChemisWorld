# ChemisWorld Backend 6.0.8

## Запуск
- Node.js 20 або новіший.
- `npm install` у папці `backend`.
- Скопіюй `.env.example` у `.env` і заповни обов’язкові значення.
- `npm start`.

## Обов’язкові змінні
- `JWT_SECRET` — випадковий секрет щонайменше 32 символи.
- `DB_PATH` — шлях до SQLite; на Render має вказувати на Persistent Disk.
- `FIREBASE_API_KEY`, `FIREBASE_AUTH_DOMAIN`, `FIREBASE_PROJECT_ID`, `FIREBASE_APP_ID` — публічна конфігурація Firebase Web App.
- `FIREBASE_MESSAGING_SENDER_ID` — необов’язкове поле.

## Firebase Google Authentication
1. Створи Firebase-проєкт у https://console.firebase.google.com/.
2. Authentication → Sign-in method → увімкни Google.
3. Project settings → General → Your apps → додай Web app та скопіюй конфігурацію.
4. Authentication → Settings → Authorized domains → додай домен сайту.
5. Перенеси конфігураційні поля у змінні середовища Render.

Сервер перевіряє Firebase ID tokens через Firebase Secure Token public JWKS та перевіряє `aud`, `iss`, Google provider і `email_verified`. Сервісний приватний ключ Firebase Admin не використовується.

## Дані та безпека
- Google subject має унікальне обмеження в `google_identities`: один Google-акаунт — один ігровий профіль.
- Гостьові та парольні маршрути вимкнені (HTTP 410).
- Старі профілі можуть бути прив’язані через чинний legacy session token під час Google входу.
- Не видаляй Persistent Disk, не змінюй `DB_PATH` або `JWT_SECRET` під час оновлення.
