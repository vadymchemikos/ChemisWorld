# Розгортання ChemisWorld 6.0.8 WEB

1. Завантаж вміст архіву до того самого GitHub-репозиторію.
2. У Render збережи чинні Root Directory, Build Command, Start Command та Persistent Disk.
3. Додай Firebase Web config у Environment: `FIREBASE_API_KEY`, `FIREBASE_AUTH_DOMAIN`, `FIREBASE_PROJECT_ID`, `FIREBASE_APP_ID` (і за наявності `FIREBASE_MESSAGING_SENDER_ID`).
4. У Firebase Console увімкни Google provider та додай домен Render у Authorized domains.
5. Не змінюй `JWT_SECRET` і `DB_PATH`.
6. Deploy latest commit.
7. Перевір вхід через Google, завантаження сторінки «Моя партія», завантаження емблеми та синхронізацію профілю.

Цей реліз зберігає web layout 6.0.5 і party-management API 6.0.4; Google-only auth 6.0.6 переведено на Firebase Authentication. APK не оновлюється.
