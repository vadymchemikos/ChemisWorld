const toast=document.getElementById('toast');
let toastTimer;
function notify(message){
  toast.textContent=message;toast.classList.add('show');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2600);
}
document.querySelectorAll('[data-name]').forEach(el=>el.addEventListener('click',()=>notify(el.dataset.name+': модуль буде реалізовано наступним етапом.')));

const mapButton=document.getElementById('mapBtn');
mapButton.addEventListener('click',()=>{
  document.getElementById('worldMap').scrollIntoView({behavior:'smooth',block:'center'});
  notify('Обирай країну на карті, щоб перейти до областей.');
});

const mapStatus=document.getElementById('mapStatus');
let map, countryLayer, admin1Layer, admin2Layer;
let currentCountry=null, currentAdmin1=null, currentLevel='countries';
let countryFeatures=[];
let selectedMapTerritory=null;

function setStatus(text){if(mapStatus)mapStatus.textContent=text;}
function safeText(value){
  return String(value??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
}
function featureName(feature){
  const p=feature.properties||{};
  return p.shapeName||p.shapeName_en||p.NAME_2||p.NAME_1||p.NAME||p.ADMIN||p.name||p.admin||p.name_en||p.SOVEREIGNT||'Невідома територія';
}
function featureCode(feature){
  const p=feature.properties||{};
  return p.shapeISO||p.shapeID||p.ISO_A3||p.iso_a3||p.ADM1_CODE||p.GID_1||p.GID_2||p.id||'';
}
function clearAdminLayers(){
  if(admin1Layer){map.removeLayer(admin1Layer);admin1Layer=null;}
  if(admin2Layer){map.removeLayer(admin2Layer);admin2Layer=null;}
}
const mapPalette=['#f0ed00','#3478df','#b00000','#00a56a','#777d80','#00c99a','#5a6398','#8a0050','#202020','#6d2600','#007c9b'];
function mapColor(feature){
  const key=featureCode(feature)||featureName(feature);
  let hash=0;for(let i=0;i<key.length;i++)hash=(hash*31+key.charCodeAt(i))>>>0;
  return mapPalette[hash%mapPalette.length];
}
function layerStyle(feature){return {color:'#080808',weight:1.7,fillColor:mapColor(feature),fillOpacity:.98};}
function selectedStyle(){return {color:'#ffffff',weight:2.5,fillColor:'#d7d700',fillOpacity:1};}

async function fetchGeoBoundaries(iso,adm){
  const url=`https://www.geoboundaries.org/api/current/gbOpen/${encodeURIComponent(iso)}/${adm}/`;
  const response=await fetch(url);
  if(!response.ok) throw new Error('Не вдалося отримати адміністративні межі');
  const metadata=await response.json();
  const geoUrl=metadata.gjDownloadURL||metadata.gjDownloadURLSimplified;
  if(!geoUrl) throw new Error('Для цього рівня немає GeoJSON');
  const geoResponse=await fetch(geoUrl);
  if(!geoResponse.ok) throw new Error('Не вдалося завантажити GeoJSON');
  return await geoResponse.json();
}
function addAdminLayer(data,level){
  const target=level===1?'admin1':'admin2';
  if(target==='admin1'&&admin1Layer)map.removeLayer(admin1Layer);
  if(target==='admin2'&&admin2Layer)map.removeLayer(admin2Layer);
  const layer=L.geoJSON(data,{
    style:layerStyle,
    onEachFeature:(feature,featureLayer)=>{
      const name=featureName(feature);
      featureLayer.bindPopup(`<b>${safeText(name)}</b><br><small>${level===1?'Область / провінція':'Район'}</small><br><button class="map-popup-action" data-level="${level}" data-name="${safeText(name)}">Обрати</button>`);
      featureLayer.on('click',()=> {
        if(level===1){
          currentAdmin1={name,feature};
          setStatus(`${currentCountry.name} / ${name}`);
          showSelectedRegion(name,'Область / провінція');
        } else {
          selectedMapTerritory={name,key:(currentCountry?.iso||'')+':'+(featureCode(feature)||name),level:'Район'};
          showSelectedRegion(name,'Район');
        }
      });
    }
  }).addTo(map);
  if(target==='admin1')admin1Layer=layer;else admin2Layer=layer;
  return layer;
}
async function selectCountry(feature){
  const p=feature.properties||{};
  const name=featureName(feature);
  const iso=p.ISO_A3||p.iso_a3||p.ADM0_A3||p.shapeISO||p.SOV_A3||p.ISO3||'';
  currentCountry={name,iso,feature};
  currentAdmin1=null;currentLevel='admin1';clearAdminLayers();
  if(countryLayer)countryLayer.setStyle(layerStyle);
  setStatus(`${name} · завантаження областей…`);
  try{
    if(!iso||iso==='-99')throw new Error('Не знайдено ISO-код країни для запиту меж');
    const data=await fetchGeoBoundaries(iso,'ADM1');
    const layer=addAdminLayer(data,1);
    map.fitBounds(layer.getBounds(),{padding:[12,12],maxZoom:6});
    notify(`${name}: завантажено адміністративний рівень 1.`);
    setStatus(`${name} / області`);
  }catch(error){
    setStatus(`${name} · області недоступні`);
    notify('Не вдалося завантажити області. Спробуй іншу країну або перевір інтернет.');
  }
}
async function selectAdmin1(name){
  if(!currentCountry||!currentCountry.iso)return;
  currentLevel='admin2';setStatus(`${currentCountry.name} / ${name} · завантаження районів…`);
  try{
    const data=await fetchGeoBoundaries(currentCountry.iso,'ADM2');
    let features=data.features||[];
    // Keep only districts belonging to the chosen first-level unit when the dataset provides a parent field.
    const chosen=currentAdmin1?.feature?.properties||{};
    const parentCandidates=['shapeGroup','GID_0','ADM0_A3','ISO_A3'];
    const parentCode=parentCandidates.map(k=>chosen[k]).find(Boolean);
    if(parentCode){
      const filtered=features.filter(f=>{
        const p=f.properties||{};
        return parentCandidates.some(k=>p[k]===parentCode) ||
          (p.shapeID&&chosen.shapeID&&String(p.shapeID).startsWith(String(chosen.shapeID)));
      });
      if(filtered.length)features=filtered;
    }
    const layer=addAdminLayer({type:'FeatureCollection',features},2);
    if(layer.getLayers().length)map.fitBounds(layer.getBounds(),{padding:[12,12],maxZoom:8});
    setStatus(`${currentCountry.name} / ${name} / райони`);
    notify('Завантажено доступні межі районів країни.');
  }catch(error){
    setStatus(`${currentCountry.name} / ${name} · райони недоступні`);
    notify('Для цієї країни рівень районів може бути відсутній у відкритому наборі.');
  }
}
function startWorldMap(){
  map=L.map('worldMap',{worldCopyJump:true,minZoom:2}).setView([22,8],2);
  setStatus('Світ · обери країну');
  fetch('https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson')
    .then(r=>{if(!r.ok)throw new Error('GeoJSON unavailable');return r.json();})
    .then(data=>{
      countryFeatures=data.features||[];
      countryLayer=L.geoJSON(data,{
        style:layerStyle,
        onEachFeature:(feature,layer)=>{
          const name=featureName(feature);
          layer.bindTooltip(name,{sticky:true});
          layer.on('click',()=>selectCountry(feature));
        }
      }).addTo(map);
    })
    .catch(()=>{notify('Не вдалося завантажити межі країн.');setStatus('Карта завантажена частково');});
  setTimeout(()=>map.invalidateSize(),250);
}
if(window.L)startWorldMap();else notify('Не вдалося завантажити бібліотеку карти.');

function searchMapCountry(){
  const input=document.getElementById('mapCountrySearch');
  const query=(input?.value||'').trim().toLocaleLowerCase('uk');
  if(!query){notify('Введи назву країни.');return;}
  if(!countryFeatures.length){notify('Карта країн ще завантажується.');return;}
  const match=countryFeatures.find(feature=>featureName(feature).toLocaleLowerCase('uk')===query)
    ||countryFeatures.find(feature=>featureName(feature).toLocaleLowerCase('uk').includes(query));
  if(!match){notify('Країну не знайдено. Спробуй іншу назву.');return;}
  if(countryLayer)map.addLayer(countryLayer);
  selectCountry(match);
}
document.getElementById('mapCountrySearchBtn')?.addEventListener('click',searchMapCountry);
document.getElementById('mapCountrySearch')?.addEventListener('keydown',event=>{if(event.key==='Enter')searchMapCountry();});


document.addEventListener('click',event=>{
  const button=event.target.closest('.map-popup-action');
  if(!button)return;
  const level=Number(button.dataset.level);
  const name=button.dataset.name;
  if(level===1)selectAdmin1(name);
});


// Local-only political prototype: parties are stored on this device, not shared online.
let selectedRegionKey='';
let selectedRegionLabel='';
function localPartyKey(){return 'chemis_world_parties_v1';}
function readParties(){
  try{return JSON.parse(localStorage.getItem(localPartyKey())||'{}');}
  catch(e){return {};}
}
function writeParties(data){try{localStorage.setItem(localPartyKey(),JSON.stringify(data));}catch(e){notify('Не вдалося зберегти дані на пристрої.');}}
function showSelectedRegion(name,level){
  selectedRegionLabel=`${currentCountry?.name||'Країна'} / ${name}`;
  selectedRegionKey=selectedRegionLabel;
  const activeFeature=currentLevel==='admin2'?null:(currentAdmin1?.feature||null);
  if(activeFeature)selectedMapTerritory={name, key:(currentCountry?.iso||'')+':'+(featureCode(activeFeature)||name), level};
  const card=document.getElementById('regionCard');
  document.getElementById('regionTitle').textContent=name;
  document.getElementById('regionLevel').textContent=level;
  document.getElementById('regionDescription').textContent=selectedRegionLabel;
  document.getElementById('createPartyBtn').disabled=false;
  document.getElementById('electionBtn').disabled=false;
  renderParties();
  card.scrollIntoView({behavior:'smooth',block:'nearest'});
}
function renderParties(){
  const data=readParties();
  const parties=data[selectedRegionKey]||[];
  const list=document.getElementById('partyList');
  if(!parties.length){list.innerHTML='<p class="empty-parties">У цьому регіоні ще немає створених партій.</p>';return;}
  list.innerHTML=parties.map(p=>`<div class="party-item"><b>${safeText(p.name)}</b><small>${safeText(p.ideology)} · ${safeText(p.program||'Програму не вказано')}</small></div>`).join('');
}
const partyModal=document.getElementById('partyModal');
document.getElementById('createPartyBtn').addEventListener('click',()=>{
  if(!selectedRegionKey)return;
  partyModal.classList.add('open');partyModal.setAttribute('aria-hidden','false');
  document.getElementById('partyName').focus();
});
function closePartyModal(){partyModal.classList.remove('open');partyModal.setAttribute('aria-hidden','true');}
document.getElementById('closePartyModal').addEventListener('click',closePartyModal);
partyModal.addEventListener('click',e=>{if(e.target===partyModal)closePartyModal();});
document.getElementById('savePartyBtn').addEventListener('click',()=>{
  const name=document.getElementById('partyName').value.trim();
  const ideology=document.getElementById('partyIdeology').value;
  const program=document.getElementById('partyProgram').value.trim();
  if(name.length<3){notify('Введи назву партії (від 3 символів).');return;}
  const data=readParties();data[selectedRegionKey]=data[selectedRegionKey]||[];
  if(data[selectedRegionKey].some(p=>p.name.toLowerCase()===name.toLowerCase())){notify('Партія з такою назвою вже існує в цьому регіоні.');return;}
  data[selectedRegionKey].push({name,ideology,program,createdAt:new Date().toISOString()});
  writeParties(data);renderParties();closePartyModal();
  document.getElementById('partyName').value='';document.getElementById('partyProgram').value='';
  notify('Партію створено локально.');
});
document.getElementById('electionBtn').addEventListener('click',()=>{
  const data=readParties();const parties=data[selectedRegionKey]||[];
  if(parties.length<2){notify('Для тестових виборів потрібно щонайменше дві партії.');return;}
  // Demonstration only: equal random draw, not connected to real players or population.
  const votes=parties.map(p=>({name:p.name,votes:Math.floor(10+Math.random()*91)}));
  const total=votes.reduce((s,p)=>s+p.votes,0);
  votes.sort((a,b)=>b.votes-a.votes);
  const result=votes.map(p=>`${p.name}: ${Math.round(p.votes/total*100)}%`).join(' · ');
  document.getElementById('politicsStatus').textContent='Демонстраційний результат (умовні голоси): '+result;
  notify('Тестові вибори завершено. Це не реальне голосування.');
});


// Independent regional economy prototype. Every region has its own separate treasury.
const economyDefaults={
 'Вінницька область':{balance:1000,tax:10,infrastructure:1,turn:0},
 'Київська область':{balance:1400,tax:10,infrastructure:2,turn:0},
 'Львівська область':{balance:1150,tax:10,infrastructure:1,turn:0}
};
let economyData={};
try{economyData=JSON.parse(localStorage.getItem('cw_independent_economy_v1')||'{}')||{};}catch(e){economyData={};}
let activeEconomyRegion='Вінницька область';
function economyFor(name){
 if(!economyData[name])economyData[name]={...economyDefaults[name]||{balance:1000,tax:10,infrastructure:1,turn:0}};
 return economyData[name];
}
function saveEconomy(){try{localStorage.setItem('cw_independent_economy_v1',JSON.stringify(economyData));}catch(e){notify('Не вдалося зберегти економіку на пристрої.');}}
function money(n){return Math.round(n).toLocaleString('uk-UA');}
function incomeFor(e){return Math.round(80+e.infrastructure*40+(e.tax-10)*5);}
function renderEconomy(){
 const e=economyFor(activeEconomyRegion);
 document.getElementById('economyRegion').value=activeEconomyRegion;
 document.getElementById('economyBalance').textContent=money(e.balance);
 document.getElementById('economyIncome').textContent=`Дохід за хід: ${money(incomeFor(e))} CW₵`;
 document.getElementById('taxValue').textContent=e.tax+'%';
 document.getElementById('taxSelect').value=String(e.tax);
 document.getElementById('infraValue').textContent=e.infrastructure+' рівень';
 document.getElementById('econValue').textContent=e.infrastructure>=4?'Розвинена':e.infrastructure>=2?'Зростає':'Початкова';
 document.getElementById('investBtn').disabled=e.balance<250;
}
document.getElementById('economyRegion').addEventListener('change',e=>{
 activeEconomyRegion=e.target.value;renderEconomy();
});
document.getElementById('taxSelect').addEventListener('change',e=>{
 const state=economyFor(activeEconomyRegion);state.tax=Number(e.target.value);saveEconomy();renderEconomy();
 document.getElementById('economyLog').textContent=`Ставку податку для «${activeEconomyRegion}» змінено на ${state.tax}%. Інші регіони не зачеплено.`;
});
document.getElementById('investBtn').addEventListener('click',()=>{
 const e=economyFor(activeEconomyRegion);
 if(e.balance<250){notify('У регіональному бюджеті недостатньо коштів.');return;}
 e.balance-=250;e.infrastructure+=1;saveEconomy();renderEconomy();
 document.getElementById('economyLog').textContent=`${activeEconomyRegion}: інвестиція 250 CW₵. Інфраструктура тепер ${e.infrastructure} рівень.`;
 notify('Інвестицію проведено.');
});
document.getElementById('turnBtn').addEventListener('click',()=>{
 const e=economyFor(activeEconomyRegion);const income=incomeFor(e);
 e.balance+=income;e.turn+=1;saveEconomy();renderEconomy();
 document.getElementById('economyLog').textContent=`Хід №${e.turn}: бюджет «${activeEconomyRegion}» отримав +${money(income)} CW₵.`;
 notify('Економічний хід завершено.');
});
renderEconomy();


// Local state founding and territorial ownership prototype.
const STATE_STORE_KEY='chemis_world_states_v1';
let stateData=[];
try{stateData=JSON.parse(localStorage.getItem(STATE_STORE_KEY)||'[]');if(!Array.isArray(stateData))stateData=[];}catch(e){stateData=[];}
function saveStates(){try{localStorage.setItem(STATE_STORE_KEY,JSON.stringify(stateData));}catch(e){notify('Не вдалося зберегти держави на пристрої.');}}
function territoryKey(){return selectedRegionKey||'';}
function stateForTerritory(key){return stateData.find(s=>s.territories.includes(key));}
function renderStates(){
 const list=document.getElementById('stateList');
 if(!stateData.length)list.innerHTML='<p class="empty-parties">Поки що держав не створено.</p>';
 else list.innerHTML=stateData.map(s=>`<div class="state-item"><div class="state-flag" style="background:${safeText(s.color)}">${safeText(s.symbol)}</div><div><b>${safeText(s.name)}</b><small>Столиця: ${safeText(s.capital)} · Територій: ${s.territories.length}</small></div></div>`).join('');
 const select=document.getElementById('joinStateSelect');
 select.innerHTML=stateData.length?'<option value="">Обери державу</option>'+stateData.map(s=>`<option value="${safeText(s.id)}">${safeText(s.name)}</option>`).join(''):'<option value="">Спочатку створи державу</option>';
 const key=territoryKey(), owned=key?stateForTerritory(key):null;
 document.getElementById('createStateBtn').disabled=!key||!!owned;
 document.getElementById('joinStateBtn').disabled=!key||!!owned||!stateData.length;
 document.getElementById('stateStatus').textContent=owned?`Обрана територія вже входить до держави «${owned.name}».`:(key?'Обрана територія вільна та може стати основою нової держави або приєднатися до наявної.':'Спочатку обери область або район на карті.');
}
function openStateModal(){document.getElementById('stateModal').classList.add('open');document.getElementById('stateModal').setAttribute('aria-hidden','false');}
function closeStateModal(){document.getElementById('stateModal').classList.remove('open');document.getElementById('stateModal').setAttribute('aria-hidden','true');}
document.getElementById('createStateBtn').addEventListener('click',openStateModal);
document.getElementById('closeStateModal').addEventListener('click',closeStateModal);
document.getElementById('saveStateBtn').addEventListener('click',()=>{
 const name=document.getElementById('stateName').value.trim();
 const capital=document.getElementById('stateCapital').value.trim();
 const symbol=document.getElementById('stateSymbol').value.trim()||'★';
 if(!name||!capital){notify('Вкажи назву держави та столицю.');return;}
 if(!territoryKey()){notify('Спочатку обери територію на карті.');return;}
 if(stateForTerritory(territoryKey())){notify('Ця територія вже належить іншій державі.');return;}
 stateData.push({id:'state_'+Date.now(),name,capital,symbol,color:document.getElementById('stateFlag').value,territories:[territoryKey()],createdAt:new Date().toISOString()});
 saveStates();renderStates();closeStateModal();
 document.getElementById('stateName').value='';document.getElementById('stateCapital').value='';
 notify(`Державу «${name}» засновано в ігровому прототипі.`);
});
document.getElementById('joinStateBtn').addEventListener('click',()=>{
 const key=territoryKey(),id=document.getElementById('joinStateSelect').value;
 const target=stateData.find(s=>s.id===id);
 if(!key||!target)return;
 if(stateForTerritory(key)){notify('Територія вже має власника.');return;}
 target.territories.push(key);saveStates();renderStates();
 document.getElementById('stateStatus').textContent=`Територію додано до «${target.name}».`;
 notify('Територію приєднано до держави.');
});
const previousShowSelectedRegion=showSelectedRegion;
showSelectedRegion=function(name,level){previousShowSelectedRegion(name,level);renderStates();};
renderStates();


// Local governance prototype: one cabinet and parliament record per player-created state.
let activeGovStateId='';
function selectedGovState(){return stateData.find(s=>s.id===activeGovStateId)||null;}
function ensureGovernance(s){
 if(!s.governance)s.governance={leader:'',seats:30,ministers:{},laws:[]};
 if(!s.governance.ministers)s.governance.ministers={};
 if(!s.governance.laws)s.governance.laws=[];
 return s.governance;
}
function renderGovernment(){
 const select=document.getElementById('govStateSelect');
 const prior=activeGovStateId;
 select.innerHTML=stateData.length?'<option value="">Обери державу</option>'+stateData.map(s=>`<option value="${safeText(s.id)}">${safeText(s.name)}</option>`).join(''):'<option value="">Спочатку створи державу</option>';
 if(stateData.some(s=>s.id===prior))select.value=prior;else activeGovStateId='';
 const s=selectedGovState(),empty=document.getElementById('govEmpty'),work=document.getElementById('govWorkspace');
 empty.hidden=!!s;work.hidden=!s;
 if(!s)return;
 const g=ensureGovernance(s);
 document.getElementById('govLeaderName').textContent=g.leader||'Не призначено';
 document.getElementById('leaderInput').value=g.leader||'';
 document.getElementById('parliamentSeats').textContent=g.seats;
 document.getElementById('lawCount').textContent=g.laws.filter(l=>l.status==='Ухвалено').length;
 document.getElementById('seatsInput').value=g.seats;
 document.getElementById('ministryList').innerHTML=Object.keys(g.ministers).length?Object.entries(g.ministers).map(([m,n])=>`<div class="ministry-item"><b>Міністерство ${safeText(m)}</b><small>Міністр: ${safeText(n)}</small></div>`).join(''):'<div class="data-note">Міністрів ще не призначено.</div>';
 document.getElementById('lawList').innerHTML=g.laws.length?g.laws.map((l,i)=>`<div class="law-item"><b>${safeText(l.title)}</b><small>Статус: ${safeText(l.status)}</small><p>${safeText(l.description)}</p>${l.status==='На розгляді'?`<div class="law-actions"><button data-law-action="pass" data-law-index="${i}">Ухвалити</button><button data-law-action="reject" data-law-index="${i}">Відхилити</button></div>`:''}</div>`).join(''):'<div class="data-note">Законопроєктів поки немає.</div>';
 saveStates();
}
document.getElementById('govStateSelect').addEventListener('change',e=>{activeGovStateId=e.target.value;renderGovernment();});
document.getElementById('saveLeaderBtn').addEventListener('click',()=>{
 const s=selectedGovState();if(!s)return;const value=document.getElementById('leaderInput').value.trim();
 if(!value){notify('Вкажи ім’я глави держави.');return;}
 ensureGovernance(s).leader=value;saveStates();renderGovernment();notify('Главу держави збережено.');
});
document.getElementById('saveSeatsBtn').addEventListener('click',()=>{
 const s=selectedGovState();if(!s)return;const n=Number(document.getElementById('seatsInput').value);
 if(!Number.isInteger(n)||n<10||n>500){notify('Парламент має мати від 10 до 500 місць.');return;}
 ensureGovernance(s).seats=n;saveStates();renderGovernment();notify('Склад парламенту оновлено.');
});
document.getElementById('appointMinisterBtn').addEventListener('click',()=>{
 const s=selectedGovState();if(!s)return;const name=document.getElementById('ministerInput').value.trim();
 if(!name){notify('Вкажи ім’я міністра.');return;}
 const g=ensureGovernance(s);g.ministers[document.getElementById('ministrySelect').value]=name;
 saveStates();renderGovernment();document.getElementById('ministerInput').value='';notify('Міністра призначено.');
});
document.getElementById('proposeLawBtn').addEventListener('click',()=>{
 const s=selectedGovState();if(!s)return;
 const title=document.getElementById('lawTitleInput').value.trim(),description=document.getElementById('lawTextInput').value.trim();
 if(title.length<3||description.length<5){notify('Додай назву та короткий опис законопроєкту.');return;}
 ensureGovernance(s).laws.push({title,description,status:'На розгляді',createdAt:new Date().toISOString()});
 saveStates();renderGovernment();document.getElementById('lawTitleInput').value='';document.getElementById('lawTextInput').value='';
 notify('Законопроєкт внесено на розгляд.');
});
document.getElementById('lawList').addEventListener('click',e=>{
 const b=e.target.closest('[data-law-action]');if(!b)return;
 const s=selectedGovState();if(!s)return;
 const g=ensureGovernance(s),law=g.laws[Number(b.dataset.lawIndex)];if(!law||law.status!=='На розгляді')return;
 law.status=b.dataset.lawAction==='pass'?'Ухвалено':'Відхилено';
 saveStates();renderGovernment();notify(law.status==='Ухвалено'?'Законопроєкт ухвалено в демоверсії.':'Законопроєкт відхилено.');
});
const oldRenderStates=renderStates;
renderStates=function(){oldRenderStates();renderGovernment();};
renderGovernment();


// Local diplomacy prototype: agreements are records between two player-created states.
const DIPLOMACY_KEY='chemis_world_diplomacy_v1';
let diplomacyData={relations:[],reputation:{}};
try{const saved=JSON.parse(localStorage.getItem(DIPLOMACY_KEY)||'null');if(saved&&typeof saved==='object')diplomacyData={...diplomacyData,...saved};}catch(e){}
function saveDiplomacy(){try{localStorage.setItem(DIPLOMACY_KEY,JSON.stringify(diplomacyData));}catch(e){notify('Не вдалося зберегти дипломатичні дані.');}}
function reputationFor(id){if(diplomacyData.reputation[id]===undefined)diplomacyData.reputation[id]=50;return diplomacyData.reputation[id];}
function stateNameById(id){return stateData.find(s=>s.id===id)?.name||'Невідома держава';}
function renderDiplomacy(){
 const from=document.getElementById('diplomacyFrom'),to=document.getElementById('diplomacyTo');
 const options=stateData.map(s=>`<option value="${safeText(s.id)}">${safeText(s.name)}</option>`).join('');
 const oldFrom=from.value,oldTo=to.value;
 from.innerHTML=stateData.length?'<option value="">Обери державу</option>'+options:'<option value="">Створи держави</option>';
 to.innerHTML=stateData.length>1?'<option value="">Обери іншу державу</option>'+options:'<option value="">Потрібні дві держави</option>';
 if(stateData.some(s=>s.id===oldFrom))from.value=oldFrom;
 if(stateData.some(s=>s.id===oldTo))to.value=oldTo;
 updateDiplomacyPair();
 const list=document.getElementById('diplomacyList');
 if(!diplomacyData.relations.length)list.innerHTML='<p class="empty-parties">Поки що міжнародних угод немає.</p>';
 else list.innerHTML=diplomacyData.relations.slice().reverse().map((r,i)=>{
  const realIndex=diplomacyData.relations.length-1-i;
  const status=r.status==='Пропозиція'?'Очікує відповіді':r.status;
  const controls=r.status==='Пропозиція'?`<button data-dip-action="accept" data-dip-index="${realIndex}">Прийняти</button><button data-dip-action="decline" data-dip-index="${realIndex}">Відхилити</button>`:'';
  return `<div class="diplomacy-item"><b>${safeText(r.label)}</b><small>${safeText(stateNameById(r.from))} → ${safeText(stateNameById(r.to))} · ${safeText(status)}</small><p>${safeText(r.description)}</p>${controls}</div>`;
 }).join('');
 saveDiplomacy();
}
function updateDiplomacyPair(){
 const a=document.getElementById('diplomacyFrom').value,b=document.getElementById('diplomacyTo').value;
 document.getElementById('repFromName').textContent=a?stateNameById(a):'Держава 1';
 document.getElementById('repToName').textContent=b?stateNameById(b):'Держава 2';
 document.getElementById('repFromValue').textContent=a?`${reputationFor(a)} / 100`:'—';
 document.getElementById('repToValue').textContent=b?`${reputationFor(b)} / 100`:'—';
 document.querySelectorAll('[data-diplomacy]').forEach(btn=>btn.disabled=!a||!b||a===b);
}
document.getElementById('diplomacyFrom').addEventListener('change',updateDiplomacyPair);
document.getElementById('diplomacyTo').addEventListener('change',updateDiplomacyPair);
const diplomacyTypes={
 relations:{label:'Дипломатичні відносини',description:'Сторони започаткували офіційний дипломатичний діалог.'},
 trade:{label:'Торговельна угода',description:'Пропозиція про взаємну торгівлю та економічну співпрацю. Угода не об’єднує регіональні бюджети.'},
 alliance:{label:'Міждержавний союз',description:'Пропозиція про довгострокову політичну співпрацю та консультації.'},
 recognition:{label:'Визнання держави',description:'Держава-ініціатор визнає незалежність і державний статус партнера.'}
};
document.querySelectorAll('[data-diplomacy]').forEach(btn=>btn.addEventListener('click',()=>{
 const from=document.getElementById('diplomacyFrom').value,to=document.getElementById('diplomacyTo').value;
 if(!from||!to||from===to){notify('Обери дві різні держави.');return;}
 const type=btn.dataset.diplomacy,meta=diplomacyTypes[type];
 if(type==='relations'&&diplomacyData.relations.some(r=>r.type===type&&((r.from===from&&r.to===to)||(r.from===to&&r.to===from))&&r.status==='Діють')){
  notify('Дипломатичні відносини вже встановлені.');return;
 }
 diplomacyData.relations.push({id:'dip_'+Date.now(),type,from,to,label:meta.label,description:meta.description,status:'Пропозиція',createdAt:new Date().toISOString()});
 saveDiplomacy();renderDiplomacy();notify('Дипломатичну пропозицію створено.');
}));
document.getElementById('diplomacyList').addEventListener('click',e=>{
 const btn=e.target.closest('[data-dip-action]');if(!btn)return;
 const r=diplomacyData.relations[Number(btn.dataset.dipIndex)];if(!r||r.status!=='Пропозиція')return;
 if(btn.dataset.dipAction==='accept'){
  r.status='Діють';
  if(r.type==='recognition')diplomacyData.reputation[r.to]=Math.min(100,reputationFor(r.to)+5);
  if(r.type==='trade') {diplomacyData.reputation[r.from]=Math.min(100,reputationFor(r.from)+2);diplomacyData.reputation[r.to]=Math.min(100,reputationFor(r.to)+2);}
  if(r.type==='alliance'){diplomacyData.reputation[r.from]=Math.min(100,reputationFor(r.from)+3);diplomacyData.reputation[r.to]=Math.min(100,reputationFor(r.to)+3);}
  notify('Пропозицію прийнято.');
 }else{r.status='Відхилено';notify('Пропозицію відхилено.');}
 saveDiplomacy();renderDiplomacy();
});
const oldRenderStatesForDip=renderStates;
renderStates=function(){oldRenderStatesForDip();renderDiplomacy();};
renderDiplomacy();
// v0.9.0 local player profile foundation. No server accounts or real online directory yet.
const PLAYER_KEY='chemis_world_player_profile_v1';
function makePlayerCode(){return 'CW-'+Math.random().toString(36).slice(2,8).toUpperCase();}
let playerProfile={nick:'',bio:'',region:'',code:makePlayerCode(),createdAt:new Date().toISOString()};
try{const p=JSON.parse(localStorage.getItem(PLAYER_KEY)||'null');if(p&&typeof p==='object')playerProfile={...playerProfile,...p};}catch(e){}
function renderPlayerProfile(){
 document.getElementById('accountNick').value=playerProfile.nick||'';
 document.getElementById('accountBio').value=playerProfile.bio||'';
 document.getElementById('accountRegion').value=playerProfile.region||'';
 document.getElementById('accountNickView').textContent=playerProfile.nick||'Новий гравець';
 document.getElementById('accountCodeView').textContent='Код: '+playerProfile.code;
 document.getElementById('accountBioView').textContent=playerProfile.bio||'Профіль ще не налаштовано';
 document.getElementById('accountAvatar').textContent=(playerProfile.nick||'?').trim().charAt(0).toUpperCase()||'?';
 document.getElementById('playerCode').textContent=playerProfile.code;
}
document.getElementById('saveAccountBtn').addEventListener('click',()=>{
 const nick=document.getElementById('accountNick').value.trim();
 if(nick.length<3){notify('Нікнейм має містити щонайменше 3 символи.');return;}
 playerProfile.nick=nick;playerProfile.bio=document.getElementById('accountBio').value.trim();
 playerProfile.region=document.getElementById('accountRegion').value.trim();
 try{localStorage.setItem(PLAYER_KEY,JSON.stringify(playerProfile));renderPlayerProfile();notify('Локальний профіль збережено.');}
 catch(e){notify('Не вдалося зберегти профіль на пристрої.');}
});
document.getElementById('copyPlayerCode').addEventListener('click',()=>{
 const code=playerProfile.code;
 if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(code).then(()=>notify('Код скопійовано.')).catch(()=>notify('Код гравця: '+code));
 else notify('Код гравця: '+code);
});
document.querySelectorAll('[data-name="Профіль"]').forEach(el=>el.addEventListener('click',()=>document.getElementById('accountCard').scrollIntoView({behavior:'smooth',block:'center'})));
document.querySelectorAll('[data-name="Гравці"]').forEach(el=>el.addEventListener('click',()=>document.getElementById('accountCard').scrollIntoView({behavior:'smooth',block:'center'})));
renderPlayerProfile();

// v1.0.0 online API client. Requires a deployed HTTPS backend; no secrets are embedded here.
const CW_API_URL_KEY='cw_api_base_url_v1';
const CW_SESSION_TOKEN_KEY='cw_online_session_token_v1';
const cwApiInput=document.getElementById('apiBaseUrl');
const cwOnlineStatus=document.getElementById('onlineStatus');
const cwOnlinePanel=document.getElementById('onlinePlayerPanel');
cwApiInput.value=localStorage.getItem(CW_API_URL_KEY)||'';
function cwApiBase(){
 const value=cwApiInput.value.trim().replace(/\/+$/,'');
 if(!/^https:\/\/[a-z0-9.-]+(?::\d+)?$/i.test(value))throw new Error('Вкажи коректну HTTPS-адресу сервера.');
 localStorage.setItem(CW_API_URL_KEY,value);return value;
}
function cwSetOnlineStatus(message){cwOnlineStatus.textContent=message;}
async function cwApi(path,options={}){
 const token=sessionStorage.getItem(CW_SESSION_TOKEN_KEY);
 const headers={'Content-Type':'application/json',...(options.headers||{})};
 if(token)headers.Authorization='Bearer '+token;
 const response=await fetch(cwApiBase()+path,{...options,headers});
 const data=await response.json().catch(()=>({}));
 if(!response.ok)throw new Error(data.error||'Помилка сервера ('+response.status+').');
 return data;
}
async function cwOnlineAuth(mode){
 const nickname=document.getElementById('onlineNick').value.trim();
 const password=document.getElementById('onlinePassword').value;
 if(!nickname||!password){cwSetOnlineStatus('Вкажи нікнейм і пароль.');return;}
 try{
  cwSetOnlineStatus('З’єднання із сервером…');
  const data=await cwApi('/api/auth/'+mode,{method:'POST',body:JSON.stringify({nickname,password})});
  sessionStorage.setItem(CW_SESSION_TOKEN_KEY,data.token);
  document.getElementById('onlinePassword').value='';
  cwOnlinePanel.hidden=false;
  cwSetOnlineStatus('Успішний вхід: '+data.player.nickname+'. Онлайн-профіль підключено.');
 }catch(e){cwSetOnlineStatus(e.message);}
}
document.getElementById('onlineRegisterBtn').addEventListener('click',()=>cwOnlineAuth('register'));
document.getElementById('onlineLoginBtn').addEventListener('click',()=>cwOnlineAuth('login'));
document.getElementById('onlineLogoutBtn').addEventListener('click',()=>{
 sessionStorage.removeItem(CW_SESSION_TOKEN_KEY);cwOnlinePanel.hidden=true;cwSetOnlineStatus('Ти вийшов із онлайн-сесії.');
});
document.getElementById('playerSearchBtn').addEventListener('click',async()=>{
 try{
  const q=encodeURIComponent(document.getElementById('playerSearchInput').value.trim());
  const data=await cwApi('/api/players?q='+q);
  const list=document.getElementById('onlinePlayersList');
  list.replaceChildren();
  if(!data.players.length){list.textContent='Гравців не знайдено.';return;}
  data.players.forEach(player=>{
   const item=document.createElement('div');item.className='online-player';
   const name=document.createElement('b');name.textContent=player.nickname;
   const meta=document.createElement('small');meta.textContent=player.home_region||'Регіон не вказано';
   const bio=document.createElement('small');bio.textContent=player.bio||'';
   item.append(name,meta,bio);list.append(item);
  });
 }catch(e){cwSetOnlineStatus(e.message);}
});
if(sessionStorage.getItem(CW_SESSION_TOKEN_KEY)){cwOnlinePanel.hidden=false;cwSetOnlineStatus('Знайдено активну онлайн-сесію в цьому сеансі.');}

async function cwRefreshOnlineStates(){
 const data=await cwApi('/api/states');
 const list=document.getElementById('onlineStatesList');list.replaceChildren();
 if(!data.states.length){list.textContent='У спільному реєстрі поки немає держав.';return;}
 data.states.forEach(state=>{
  const item=document.createElement('div');item.className='online-player';
  const title=document.createElement('b');title.textContent=(state.symbol||'★')+' '+state.name;
  const meta=document.createElement('small');meta.textContent='Столиця: '+state.capital+' · Власник: '+state.owner_nickname;
  const count=document.createElement('small');count.textContent='Територій: '+state.territories.length;
  item.append(title,meta,count);list.append(item);
 });
}
document.getElementById('refreshStatesBtn').addEventListener('click',async()=>{
 try{await cwRefreshOnlineStates();cwSetOnlineStatus('Спільний реєстр держав оновлено.');}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('syncStatesBtn').addEventListener('click',async()=>{
 try{
  const [existing,me]=await Promise.all([cwApi('/api/states'),cwApi('/api/me')]);
  const mine=new Set(existing.states.filter(s=>s.owner_id===me.player.id).map(s=>s.name.toLocaleLowerCase()));
  const local=JSON.parse(localStorage.getItem('chemis_world_states_v1')||'[]');
  let published=0,skipped=0;
  for(const s of local){
   if(mine.has(String(s.name).toLocaleLowerCase())){skipped++;continue;}
   await cwApi('/api/states',{method:'POST',body:JSON.stringify({
    name:s.name,capital:s.capital,color:s.color,symbol:s.symbol,territories:s.territories
   })});
   published++;
  }
  await cwRefreshOnlineStates();
  cwSetOnlineStatus(`Публікацію завершено: ${published} держав опубліковано, ${skipped} уже були у твоєму списку.`);
 }catch(e){cwSetOnlineStatus(e.message);}
});

async function cwLoadOnlineStatesIntoPolitics(){
 const data=await cwApi('/api/states');
 const select=document.getElementById('politicsStateSelect'),prior=select.value;
 select.replaceChildren();
 const empty=document.createElement('option');empty.value='';empty.textContent='Обери державу';select.append(empty);
 data.states.forEach(s=>{const o=document.createElement('option');o.value=s.id;o.textContent=s.name+' — '+s.owner_nickname;select.append(o);});
 if(data.states.some(s=>s.id===prior))select.value=prior;
}
async function cwRenderOnlinePolitics(){
 const stateId=document.getElementById('politicsStateSelect').value;
 const list=document.getElementById('onlinePoliticsList');list.replaceChildren();
 if(!stateId){list.textContent='Обери державу для перегляду політичного життя.';return;}
 const data=await cwApi('/api/states/'+encodeURIComponent(stateId)+'/politics');
 const heading=document.createElement('b');heading.textContent='Партії';list.append(heading);
 if(!data.parties.length){const p=document.createElement('p');p.textContent='Партій поки немає.';list.append(p);}
 data.parties.forEach(p=>{
  const item=document.createElement('div');item.className='online-player';
  const name=document.createElement('b');name.textContent=p.name;
  const meta=document.createElement('small');meta.textContent=(p.ideology||'Без зазначеної ідеології')+' · автор: '+p.creator;
  const desc=document.createElement('small');desc.textContent=p.platform||'Програму не додано';
  item.append(name,meta,desc);list.append(item);
 });
 data.elections.forEach(e=>{
  const block=document.createElement('div');block.className='online-player';
  const title=document.createElement('b');title.textContent='Вибори · '+(e.status==='open'?'голосування відкрите':'завершено');block.append(title);
  e.results.forEach(r=>{
   const line=document.createElement('div');line.style.display='flex';line.style.gap='8px';line.style.alignItems='center';
   const label=document.createElement('small');label.textContent=r.party_name+' — '+r.votes+' голосів'+(e.status==='closed'?' · '+(r.seats||0)+' місць':'');line.append(label);
   if(e.status==='open'){
    const btn=document.createElement('button');btn.className='secondary';btn.textContent='Голосувати';
    btn.addEventListener('click',async()=>{try{await cwApi('/api/elections/'+e.id+'/vote',{method:'POST',body:JSON.stringify({partyId:r.party_id})});cwSetOnlineStatus('Голос зараховано.');await cwRenderOnlinePolitics();}catch(err){cwSetOnlineStatus(err.message);}});
    line.append(btn);
   }
   block.append(line);
  });
  if(e.status==='open'){
   const closeBtn=document.createElement('button');closeBtn.className='secondary';closeBtn.textContent='Завершити вибори (власник)';
   closeBtn.addEventListener('click',async()=>{try{await cwApi('/api/elections/'+e.id+'/close',{method:'POST',body:'{}'});cwSetOnlineStatus('Вибори завершено.');await cwRenderOnlinePolitics();}catch(err){cwSetOnlineStatus(err.message);}});
   block.append(closeBtn);
  }
  list.append(block);
 });
 if(data.parliament){
  const ph=document.createElement('b');ph.textContent='Парламент · розподіл 100 місць';list.append(ph);
  data.parliament.seats.forEach(s=>{const line=document.createElement('small');line.textContent=s.party_name+' — '+s.seats+' місць';list.append(line);});
 }else{const p=document.createElement('small');p.textContent='Парламент ще не сформовано: заверши вибори.';list.append(p);}
 if(data.government){
  const gh=document.createElement('b');gh.textContent='Уряд · прем’єр-міністр: '+data.government.prime_minister;list.append(gh);
  data.ministers.forEach(m=>{const line=document.createElement('small');line.textContent=m.portfolio+': '+m.minister_name;list.append(line);});
 }
 const lawsHead=document.createElement('b');lawsHead.textContent='Законопроєкти';list.append(lawsHead);
 data.laws.forEach(l=>{
  const item=document.createElement('div');item.className='online-player';
  const title=document.createElement('b');title.textContent=l.title;
  const desc=document.createElement('small');desc.textContent=l.description+' · '+(l.status==='proposed'?'на розгляді':l.status==='adopted'?'ухвалено':'відхилено');
  item.append(title,desc);
  if(l.status==='proposed'){
   const tally=document.createElement('small');const yes=l.tally.find(x=>x.decision==='yes')?.votes||0,no=l.tally.find(x=>x.decision==='no')?.votes||0;tally.textContent='Голоси парламенту: за — '+yes+', проти — '+no;item.append(tally);
   for(const [decision,label] of [['yes','Голосувати за'],['no','Голосувати проти']]){
    const btn=document.createElement('button');btn.className='secondary';btn.textContent=label;
    btn.addEventListener('click',async()=>{try{await cwApi('/api/laws/'+l.id+'/vote',{method:'POST',body:JSON.stringify({decision})});cwSetOnlineStatus('Голос враховано.');await cwRenderOnlinePolitics();}catch(err){cwSetOnlineStatus(err.message);}});
    item.append(btn);
   }
   const finalBtn=document.createElement('button');finalBtn.className='secondary';finalBtn.textContent='Підтвердити результат (власник)';
   finalBtn.addEventListener('click',async()=>{try{await cwApi('/api/laws/'+l.id+'/finalize',{method:'POST',body:'{}'});await cwRenderOnlinePolitics();}catch(err){cwSetOnlineStatus(err.message);}});
   item.append(finalBtn);
  }
  list.append(item);
 });
}
document.getElementById('refreshStatesBtn').addEventListener('click',async()=>{
 try{await cwRefreshOnlineStates();await cwLoadOnlineStatesIntoPolitics();await cwRenderOnlinePolitics();await cwRenderRegionalManagement();cwSetOnlineStatus('Спільний реєстр держав оновлено.');}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('politicsStateSelect').addEventListener('change',()=>Promise.all([cwRenderOnlinePolitics(),cwRenderRegionalManagement()]).catch(e=>cwSetOnlineStatus(e.message)));
document.getElementById('createOnlinePartyBtn').addEventListener('click',async()=>{
 try{
  const id=document.getElementById('politicsStateSelect').value;
  await cwApi('/api/states/'+encodeURIComponent(id)+'/parties',{method:'POST',body:JSON.stringify({
   name:document.getElementById('onlinePartyName').value,
   ideology:document.getElementById('onlinePartyIdeology').value,
   platform:document.getElementById('onlinePartyPlatform').value
  })});
  cwSetOnlineStatus('Партію зареєстровано на сервері.');await cwRenderOnlinePolitics();
 }catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('createOnlineElectionBtn').addEventListener('click',async()=>{
 try{const id=document.getElementById('politicsStateSelect').value;await cwApi('/api/states/'+encodeURIComponent(id)+'/elections',{method:'POST',body:'{}'});cwSetOnlineStatus('Вибори оголошено.');await cwRenderOnlinePolitics();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('submitOnlineLawBtn').addEventListener('click',async()=>{
 try{
  const id=document.getElementById('politicsStateSelect').value;
  await cwApi('/api/states/'+encodeURIComponent(id)+'/laws',{method:'POST',body:JSON.stringify({title:document.getElementById('onlineLawTitle').value,description:document.getElementById('onlineLawDescription').value})});
  cwSetOnlineStatus('Законопроєкт подано.');await cwRenderOnlinePolitics();
 }catch(e){cwSetOnlineStatus(e.message);}
});

document.getElementById('formOnlineGovernmentBtn').addEventListener('click',async()=>{
 try{
  const id=document.getElementById('politicsStateSelect').value;
  const raw=document.getElementById('onlineMinisters').value.split('\n').map(x=>x.trim()).filter(Boolean);
  const ministers=raw.map(line=>{const parts=line.split(':');return {portfolio:(parts.shift()||'').trim(),name:parts.join(':').trim()};});
  await cwApi('/api/states/'+encodeURIComponent(id)+'/government',{method:'POST',body:JSON.stringify({primeMinister:document.getElementById('onlinePrimeMinister').value,ministers})});
  cwSetOnlineStatus('Уряд сформовано на сервері.');await cwRenderOnlinePolitics();
 }catch(e){cwSetOnlineStatus(e.message);}
});

async function cwRenderRegionalManagement(){
 const stateId=document.getElementById('politicsStateSelect').value;
 const list=document.getElementById('onlineRegionalList');list.replaceChildren();
 if(!stateId){list.textContent='Обери державу.';return;}
 const data=await cwApi('/api/states/'+encodeURIComponent(stateId)+'/regions');
 const heading=document.createElement('b');heading.textContent='Території та керівники';list.append(heading);
 data.regions.forEach(r=>{
  const line=document.createElement('div');line.className='online-player';
  const name=document.createElement('b');name.textContent=r.territory_key;
  const governor=document.createElement('small');governor.textContent='Керівник: '+(r.governor||'не призначений');
  line.append(name,governor);list.append(line);
 });
 const eh=document.createElement('b');eh.textContent='Місцеві вибори';list.append(eh);
 for(const e of data.elections){
  const block=document.createElement('div');block.className='online-player';
  const title=document.createElement('b');title.textContent=e.territory_key+' · '+(e.status==='open'?'голосування відкрите':'завершено')+' · явка '+e.turnout;block.append(title);
  const ballot=await cwApi('/api/regions/elections/'+encodeURIComponent(e.id));
  ballot.candidates.forEach(candidate=>{
   const row=document.createElement('div');row.style.display='flex';row.style.gap='8px';row.style.alignItems='center';
   const label=document.createElement('small');label.textContent=candidate.candidate_name+' — '+candidate.votes+' голосів'+(e.status==='closed'?' · '+candidate.seats+' місць':'');row.append(label);
   if(e.status==='open'){
    const vote=document.createElement('button');vote.className='secondary';vote.textContent='Голосувати';
    vote.addEventListener('click',async()=>{try{await cwApi('/api/regions/elections/'+e.id+'/vote',{method:'POST',body:JSON.stringify({candidateName:candidate.candidate_name})});cwSetOnlineStatus('Голос зараховано.');await cwRenderRegionalManagement();}catch(err){cwSetOnlineStatus(err.message);}});
    row.append(vote);
   }
   block.append(row);
  });
  if(e.status==='open'){
   const close=document.createElement('button');close.className='secondary';close.textContent='Завершити місцеві вибори (власник)';
   close.addEventListener('click',async()=>{try{await cwApi('/api/regions/elections/'+e.id+'/close',{method:'POST',body:'{}'});cwSetOnlineStatus('Місцеві вибори завершено.');await cwRenderRegionalManagement();}catch(err){cwSetOnlineStatus(err.message);}});
   block.append(close);
  }
  list.append(block);
 }
 const ch=document.createElement('b');ch.textContent='Склад місцевих рад';list.append(ch);
 data.councils.forEach(s=>{const row=document.createElement('small');row.textContent=s.territory_key+' · '+s.candidate_name+': '+s.seats+' місць ('+s.votes+' голосів)';list.append(row);});
}
document.getElementById('appointRegionalGovernorBtn').addEventListener('click',async()=>{
 try{
  const id=document.getElementById('politicsStateSelect').value;
  await cwApi('/api/states/'+encodeURIComponent(id)+'/regions/governor',{method:'POST',body:JSON.stringify({
   territoryKey:document.getElementById('regionalTerritoryKey').value,
   nickname:document.getElementById('regionalGovernorNick').value
  })});
  cwSetOnlineStatus('Керівника регіону призначено.');await cwRenderRegionalManagement();
 }catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('createRegionalElectionBtn').addEventListener('click',async()=>{
 try{
  const id=document.getElementById('politicsStateSelect').value;
  const candidates=document.getElementById('regionalCandidates').value.split('\n').map(x=>x.trim()).filter(Boolean);
  await cwApi('/api/states/'+encodeURIComponent(id)+'/regions/elections',{method:'POST',body:JSON.stringify({territoryKey:document.getElementById('regionalTerritoryKey').value,candidates})});
  cwSetOnlineStatus('Місцеві вибори оголошено.');await cwRenderRegionalManagement();
 }catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('refreshRegionalBtn').addEventListener('click',()=>cwRenderRegionalManagement().catch(e=>cwSetOnlineStatus(e.message)));

async function cwRenderRegionalEconomy(){
 const stateId=document.getElementById('politicsStateSelect').value;
 const key=document.getElementById('regionalEconomyKey').value.trim();
 const panel=document.getElementById('regionalEconomyPanel');panel.replaceChildren();
 if(!stateId||!key){panel.textContent='Обери державу та введи точний ключ її території.';return;}
 const data=await cwApi('/api/states/'+encodeURIComponent(stateId)+'/regions/'+encodeURIComponent(key)+'/economy');
 const e=data.economy;
 const summary=document.createElement('div');summary.className='online-player';
 const text=document.createElement('b');text.textContent='Бюджет: '+e.treasury+' CW₵';
 const meta=document.createElement('small');meta.textContent='Податок: '+e.tax_rate+'% · рівень інфраструктури: '+e.infrastructure_level+' · економічний цикл: '+e.turn_number;
 const mayor=document.createElement('small');mayor.textContent='Мер: '+(data.mayor||'не обраний');
 summary.append(text,meta,mayor);panel.append(summary);
 const bh=document.createElement('b');bh.textContent='Об’єкти інфраструктури';panel.append(bh);
 data.buildings.forEach(b=>{const line=document.createElement('small');line.textContent=b.building_type+' · рівень '+b.level;panel.append(line);});
 const lh=document.createElement('b');lh.textContent='Місцеві законопроєкти';panel.append(lh);
 data.laws.forEach(l=>{
  const item=document.createElement('div');item.className='online-player';
  const title=document.createElement('b');title.textContent=l.title;
  const desc=document.createElement('small');desc.textContent=l.description+' · '+l.status+' · за: '+l.yes+' · проти: '+l.no;item.append(title,desc);
  if(l.status==='proposed'){
   for(const [decision,label] of [['yes','За'],['no','Проти']]){
    const btn=document.createElement('button');btn.className='secondary';btn.textContent=label;
    btn.addEventListener('click',async()=>{try{await cwApi('/api/regions/local-laws/'+l.id+'/vote',{method:'POST',body:JSON.stringify({decision})});await cwRenderRegionalEconomy();}catch(err){cwSetOnlineStatus(err.message);}});
    item.append(btn);
   }
   const final=document.createElement('button');final.className='secondary';final.textContent='Підтвердити результат (керівник)';
   final.addEventListener('click',async()=>{try{await cwApi('/api/regions/local-laws/'+l.id+'/finalize',{method:'POST',body:'{}'});await cwRenderRegionalEconomy();}catch(err){cwSetOnlineStatus(err.message);}});
   item.append(final);
  }
  panel.append(item);
 });
 const mh=document.createElement('b');mh.textContent='Вибори мера';panel.append(mh);
 for(const election of data.elections){
  const block=document.createElement('div');block.className='online-player';
  const title=document.createElement('b');title.textContent='Вибори мера · '+(election.status==='open'?'відкриті':'завершені')+(election.winner?' · переможець: '+election.winner:'');block.append(title);
  const ballot=await cwApi('/api/mayor-elections/'+election.id);
  ballot.candidates.forEach(candidate=>{
   const row=document.createElement('div');row.style.display='flex';row.style.gap='8px';
   const label=document.createElement('small');label.textContent=candidate.candidate_name+' — '+candidate.votes+' голосів';row.append(label);
   if(election.status==='open'){
    const vote=document.createElement('button');vote.className='secondary';vote.textContent='Голосувати';
    vote.addEventListener('click',async()=>{try{await cwApi('/api/mayor-elections/'+election.id+'/vote',{method:'POST',body:JSON.stringify({candidateName:candidate.candidate_name})});await cwRenderRegionalEconomy();}catch(err){cwSetOnlineStatus(err.message);}});
    row.append(vote);
   }
   block.append(row);
  });
  if(election.status==='open'){
   const close=document.createElement('button');close.className='secondary';close.textContent='Завершити вибори мера (власник)';
   close.addEventListener('click',async()=>{try{await cwApi('/api/mayor-elections/'+election.id+'/close',{method:'POST',body:'{}'});await cwRenderRegionalEconomy();}catch(err){cwSetOnlineStatus(err.message);}});
   block.append(close);
  }
  panel.append(block);
 }
}
document.getElementById('saveRegionalTaxBtn').addEventListener('click',async()=>{
 try{const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('regionalEconomyKey').value.trim(),taxRate=Number(document.getElementById('regionalTaxRate').value);
 await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/economy/tax',{method:'POST',body:JSON.stringify({taxRate})});cwSetOnlineStatus('Місцевий податок оновлено.');await cwRenderRegionalEconomy();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('collectRegionalIncomeBtn').addEventListener('click',async()=>{
 try{const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('regionalEconomyKey').value.trim();
 const result=await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/economy/collect',{method:'POST',body:'{}'});cwSetOnlineStatus('Дохід регіону: +'+result.income+' CW₵.');await cwRenderRegionalEconomy();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('buildRegionalBtn').addEventListener('click',async()=>{
 try{const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('regionalEconomyKey').value.trim(),buildingType=document.getElementById('regionalBuildingType').value;
 await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/buildings',{method:'POST',body:JSON.stringify({buildingType})});cwSetOnlineStatus('Об’єкт збудовано.');await cwRenderRegionalEconomy();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('createMayorElectionBtn').addEventListener('click',async()=>{
 try{const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('regionalEconomyKey').value.trim(),candidates=document.getElementById('mayorCandidates').value.split('\n').map(x=>x.trim()).filter(Boolean);
 await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/mayor-elections',{method:'POST',body:JSON.stringify({candidates})});cwSetOnlineStatus('Вибори мера оголошено.');await cwRenderRegionalEconomy();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('createRegionalLawBtn').addEventListener('click',async()=>{
 try{const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('regionalEconomyKey').value.trim();
 await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/laws',{method:'POST',body:JSON.stringify({title:document.getElementById('regionalLawTitle').value,description:document.getElementById('regionalLawDescription').value})});cwSetOnlineStatus('Місцевий законопроєкт подано.');await cwRenderRegionalEconomy();}
 catch(e){cwSetOnlineStatus(e.message);}
});
document.getElementById('refreshRegionalEconomyBtn').addEventListener('click',()=>cwRenderRegionalEconomy().catch(e=>cwSetOnlineStatus(e.message)));

// v1.6.0: map navigation, boundary selection and publishing a selected territory.
document.getElementById('mapWorldBtn').addEventListener('click',()=>{
 if(!map)return;clearAdminLayers();currentCountry=null;currentAdmin1=null;currentLevel='countries';
 if(countryLayer){map.addLayer(countryLayer);map.fitWorld();}
 setStatus('Світ · обери країну');
});
document.getElementById('mapCountryBtn').addEventListener('click',()=>{
 if(!map||!currentCountry)return;
 clearAdminLayers();currentAdmin1=null;currentLevel='admin1';
 const bounds=L.geoJSON(currentCountry.feature).getBounds();map.fitBounds(bounds,{padding:[12,12]});
 setStatus(currentCountry.name+' · межі країни');
});
document.getElementById('mapDistrictBtn').addEventListener('click',()=>{
 if(!currentCountry||!currentAdmin1){notify('Спочатку обери країну та область/провінцію.');return;}
 selectAdmin1(currentAdmin1.name);
});
document.getElementById('mapAddTerritoryBtn').addEventListener('click',async()=>{
 try{
  if(!selectedMapTerritory)throw new Error('Спочатку обери область або район на карті.');
  const stateId=document.getElementById('politicsStateSelect').value;
  if(!stateId)throw new Error('Обери свою онлайн-державу в розділі політики.');
  const key=selectedMapTerritory.key;
  await cwApi('/api/states/'+encodeURIComponent(stateId)+'/territories',{method:'POST',body:JSON.stringify({territoryKey:key})});
  notify('Територію додано до держави: '+selectedMapTerritory.name);
 }catch(e){notify(e.message);}
});

// v1.7.0 city registry and municipal development.
async function cwRenderCities(){
 const state=document.getElementById('politicsStateSelect').value;
 const key=document.getElementById('cityRegionKey').value.trim();
 const panel=document.getElementById('citiesPanel');panel.replaceChildren();
 if(!state||!key){panel.textContent='Обери онлайн-державу та введи точний ключ її регіону.';return;}
 const data=await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/cities');
 if(!data.cities.length){panel.textContent='У цьому регіоні ще немає зареєстрованих міст.';return;}
 for(const city of data.cities){
  const card=document.createElement('div');card.className='online-player';
  const title=document.createElement('b');title.textContent=city.name;
  const details=document.createElement('small');details.textContent='Населення: '+city.population.toLocaleString('uk-UA')+' · рівень міста: '+city.urban_level+' · міський голова: '+(city.mayor||'не призначений');
  card.append(title,details);
  const projects=data.projects.filter(p=>p.city_id===city.id);
  projects.forEach(p=>{const line=document.createElement('small');line.textContent=p.project_type+' · рівень '+p.level;card.append(line);});
  const develop=document.createElement('button');develop.className='secondary';develop.textContent='Розвинути місто: побудувати проєкт';
  develop.addEventListener('click',async()=>{
   try{const projectType=document.getElementById('cityProjectType').value;
    await cwApi('/api/cities/'+city.id+'/projects',{method:'POST',body:JSON.stringify({projectType})});
    notify('Міський проєкт реалізовано.');await cwRenderCities();
   }catch(e){notify(e.message);}
  });
  const mayor=document.createElement('button');mayor.className='secondary';mayor.textContent='Призначити міського голову';
  mayor.addEventListener('click',async()=>{
   try{const nickname=document.getElementById('cityMayorNick').value.trim();
    await cwApi('/api/cities/'+city.id+'/mayor',{method:'POST',body:JSON.stringify({nickname})});
    notify('Міського голову призначено.');await cwRenderCities();
   }catch(e){notify(e.message);}
  });
  const growth=document.createElement('button');growth.className='secondary';growth.textContent='Розрахувати приріст населення';
  growth.addEventListener('click',async()=>{
   try{const result=await cwApi('/api/cities/'+city.id+'/growth',{method:'POST',body:'{}'});
    notify('Приріст населення: +'+result.growth+'.');await cwRenderCities();
   }catch(e){notify(e.message);}
  });
  const manage=document.createElement('button');manage.className='secondary';manage.textContent='Відкрити міське управління';
  manage.addEventListener('click',async()=>{cwSelectedCityId=city.id;try{await cwRenderCityGovernance(city.id);}catch(err){notify(err.message);}});
  card.append(develop,mayor,growth,manage);panel.append(card);
 }
}
document.getElementById('createCityBtn').addEventListener('click',async()=>{
 try{
  const state=document.getElementById('politicsStateSelect').value,key=document.getElementById('cityRegionKey').value.trim();
  const name=document.getElementById('cityName').value.trim(),population=Number(document.getElementById('cityPopulation').value);
  await cwApi('/api/states/'+encodeURIComponent(state)+'/regions/'+encodeURIComponent(key)+'/cities',{method:'POST',body:JSON.stringify({name,population})});
  notify('Місто засновано.');await cwRenderCities();
 }catch(e){notify(e.message);}
});
document.getElementById('refreshCitiesBtn').addEventListener('click',()=>cwRenderCities().catch(e=>notify(e.message)));

// v1.8.0: municipal elections, council, budget and proposals.
async function cwRenderCityGovernance(cityId){
 const panel=document.getElementById('cityGovernancePanel');panel.replaceChildren();
 if(!cityId){panel.textContent='Спочатку онови список міст і обери місто.';return;}
 const data=await cwApi('/api/cities/'+cityId+'/governance');
 const e=data.economy,c=data.city;
 const head=document.createElement('div');head.className='online-player';
 const title=document.createElement('b');title.textContent=c.name+' · міський бюджет: '+e.treasury+' CW₵';
 const meta=document.createElement('small');meta.textContent='Міський податок: '+e.tax_rate+'% · цикл: '+e.turn_number+' · міський голова: '+(c.mayor||'не обраний');
 head.append(title,meta);panel.append(head);
 const councilTitle=document.createElement('b');councilTitle.textContent='Міська рада · 15 місць';panel.append(councilTitle);
 data.council.forEach(x=>{const line=document.createElement('small');line.textContent=x.nickname+' — '+x.seats+' місць ('+x.votes+' голосів)';panel.append(line);});
 const electionTitle=document.createElement('b');electionTitle.textContent='Міські вибори';panel.append(electionTitle);
 for(const election of data.elections){
  const block=document.createElement('div');block.className='online-player';
  const label=document.createElement('b');label.textContent=(election.election_type==='mayor'?'Вибори мера':'Вибори міської ради')+' · '+election.status+(election.winner_nickname?' · переможець: '+election.winner_nickname:'');block.append(label);
  const ballot=await cwApi('/api/city-elections/'+election.id);
  ballot.candidates.forEach(candidate=>{
   const row=document.createElement('div');row.style.display='flex';row.style.gap='8px';
   const text=document.createElement('small');text.textContent=candidate.nickname+' — '+candidate.votes;row.append(text);
   if(election.status==='open'){
    const vote=document.createElement('button');vote.className='secondary';vote.textContent='Голосувати';
    vote.addEventListener('click',async()=>{try{await cwApi('/api/city-elections/'+election.id+'/vote',{method:'POST',body:JSON.stringify({candidateId:candidate.player_id})});await cwRenderCityGovernance(cityId);}catch(err){notify(err.message);}});
    row.append(vote);
   }block.append(row);
  });
  if(election.status==='open'){
   const close=document.createElement('button');close.className='secondary';close.textContent='Підбити підсумки (мер/керівник)';
   close.addEventListener('click',async()=>{try{await cwApi('/api/city-elections/'+election.id+'/close',{method:'POST',body:'{}'});await cwRenderCityGovernance(cityId);}catch(err){notify(err.message);}});
   block.append(close);
  }panel.append(block);
 }
 const proposals=document.createElement('b');proposals.textContent='Міські ініціативи';panel.append(proposals);
 data.proposals.forEach(p=>{
  const item=document.createElement('div');item.className='online-player';
  const t=document.createElement('b');t.textContent=p.title;
  const d=document.createElement('small');d.textContent=p.description+' · '+p.status+' · за '+p.yes+' · проти '+p.no;item.append(t,d);
  if(p.status==='proposed'){
   for(const [decision,label] of [['yes','За'],['no','Проти']]){
    const btn=document.createElement('button');btn.className='secondary';btn.textContent=label;
    btn.addEventListener('click',async()=>{try{await cwApi('/api/city-proposals/'+p.id+'/vote',{method:'POST',body:JSON.stringify({decision})});await cwRenderCityGovernance(cityId);}catch(err){notify(err.message);}});
    item.append(btn);
   }
   const finish=document.createElement('button');finish.className='secondary';finish.textContent='Підтвердити результат';
   finish.addEventListener('click',async()=>{try{await cwApi('/api/city-proposals/'+p.id+'/finalize',{method:'POST',body:'{}'});await cwRenderCityGovernance(cityId);}catch(err){notify(err.message);}});
   item.append(finish);
  }panel.append(item);
 });
}
let cwSelectedCityId=null;

document.getElementById('createCityElectionBtn').addEventListener('click',async()=>{
 try{if(!cwSelectedCityId)throw new Error('Спочатку обери місто.');
 const electionType=document.getElementById('cityElectionType').value;
 const candidates=document.getElementById('cityElectionCandidates').value.split('\n').map(x=>x.trim()).filter(Boolean);
 await cwApi('/api/cities/'+cwSelectedCityId+'/elections',{method:'POST',body:JSON.stringify({electionType,candidates})});
 notify('Міські вибори оголошено.');await cwRenderCityGovernance(cwSelectedCityId);
 }catch(e){notify(e.message);}
});
document.getElementById('saveMunicipalTaxBtn').addEventListener('click',async()=>{
 try{if(!cwSelectedCityId)throw new Error('Спочатку обери місто.');
 const taxRate=Number(document.getElementById('municipalTaxRate').value);
 await cwApi('/api/cities/'+cwSelectedCityId+'/municipal-tax',{method:'POST',body:JSON.stringify({taxRate})});
 notify('Міський податок оновлено.');await cwRenderCityGovernance(cwSelectedCityId);
 }catch(e){notify(e.message);}
});
document.getElementById('collectMunicipalIncomeBtn').addEventListener('click',async()=>{
 try{if(!cwSelectedCityId)throw new Error('Спочатку обери місто.');
 const r=await cwApi('/api/cities/'+cwSelectedCityId+'/municipal-income',{method:'POST',body:'{}'});
 notify('Міський бюджет отримав +'+r.income+' CW₵.');await cwRenderCityGovernance(cwSelectedCityId);
 }catch(e){notify(e.message);}
});
document.getElementById('buildMunicipalProjectBtn').addEventListener('click',async()=>{
 try{if(!cwSelectedCityId)throw new Error('Спочатку обери місто.');
 const projectType=document.getElementById('municipalProjectType').value;
 await cwApi('/api/cities/'+cwSelectedCityId+'/municipal-projects',{method:'POST',body:JSON.stringify({projectType})});
 notify('Муніципальний проєкт оплачено.');await cwRenderCityGovernance(cwSelectedCityId);
 }catch(e){notify(e.message);}
});
document.getElementById('createMunicipalProposalBtn').addEventListener('click',async()=>{
 try{if(!cwSelectedCityId)throw new Error('Спочатку обери місто.');
 const title=document.getElementById('municipalProposalTitle').value,description=document.getElementById('municipalProposalDescription').value;
 await cwApi('/api/cities/'+cwSelectedCityId+'/proposals',{method:'POST',body:JSON.stringify({title,description})});
 notify('Міську ініціативу подано.');await cwRenderCityGovernance(cwSelectedCityId);
 }catch(e){notify(e.message);}
});
document.getElementById('refreshCityGovernanceBtn').addEventListener('click',()=>cwSelectedCityId?cwRenderCityGovernance(cwSelectedCityId).catch(e=>notify(e.message)):notify('Спочатку обери місто.'));


/* Reference-style six-screen navigation. Existing feature sections are moved,
   not recreated, so their original IDs and event handlers remain intact. */
(function(){
 const main=document.querySelector('main');
 if(!main)return;
 const pages={};
 const labels={overview:'Огляд',articles:'Статті',work:'Робота',wars:'Війни',profile:'Профіль',map:'Карти'};
 Object.keys(labels).forEach(key=>{
   const page=document.createElement('div');
   page.className='cw-page'+(key==='overview'?' active':'');
   page.id='page-'+key;
   page.dataset.page=key;
   main.appendChild(page);pages[key]=page;
 });
 const move=(selector,key)=>{
   document.querySelectorAll(selector).forEach(el=>pages[key].appendChild(el));
 };
 move('.welcome,.stats,.region-card,.state-card,.diplomacy-card,.gov-card,.quick','overview');
 move('.map-panel','map');
 move('.economy-card','work');
 const workResources=document.createElement('section');
 workResources.className='cw-card';
 workResources.innerHTML='<h2>Ресурси регіону</h2><div class="cw-grid3">'+
  '<div class="cw-stat"><small>Золото</small><b>—</b></div>'+
  '<div class="cw-stat"><small>Нафта</small><b>—</b></div>'+
  '<div class="cw-stat"><small>Руда</small><b>—</b></div>'+
  '<div class="cw-stat"><small>Уран</small><b>—</b></div>'+
  '<div class="cw-stat"><small>Алмази</small><b>—</b></div>'+
  '<div class="cw-stat"><small>Енергія</small><b>—</b></div></div>'+
  '<p class="cw-muted">Виробничі ресурси будуть підключені до окремих регіональних запасів. Значення поки не задані.</p>';
 pages.work.insertBefore(workResources,pages.work.firstChild);

 move('#accountCard,#onlineAccountCard','profile');
 const chatPanel=document.createElement('section');
 chatPanel.className='cw-card';
 chatPanel.innerHTML='<div class="cw-row"><h2>Світовий чат</h2><span class="cw-muted">ДЕМО</span></div>'+
  '<div id="cwChatMessages"><div class="cw-list-item"><div class="cw-avatar">🌐</div><div class="cw-item-main"><b>Система Chemis World</b><small>Вітаємо у світі гри! Чат поки працює локально.</small></div></div></div>'+
  '<div class="cw-row"><input id="cwChatInput" class="economy-select" maxlength="180" placeholder="Написати повідомлення" style="flex:1;min-width:0"><button class="primary" id="cwChatSend" style="width:auto;margin:0">Надіслати</button></div>';
 pages.overview.appendChild(chatPanel);


 // Add a compact map shortcut to the overview dashboard.
 const overviewMapShortcut=document.createElement('section');
 overviewMapShortcut.className='cw-card';
 overviewMapShortcut.innerHTML='<div class="cw-row"><div><h2>Світова карта</h2><small class="cw-muted">Країни та адміністративні території</small></div><span class="cw-avatar">🌍</span></div><button class="secondary" id="cwOpenMap">Відкрити карту</button>';
 pages.overview.insertBefore(overviewMapShortcut,pages.overview.children[2]||null);

 const wars=document.createElement('div');
 wars.innerHTML=`
  <section class="cw-card">
   <h2>Війни</h2>
   <div class="cw-list-item"><div class="cw-avatar">🕊</div><div class="cw-item-main"><b>Стан міжнародної ситуації</b><small>Немає активних конфліктів у твоїй державі</small></div></div>
  </section>
  <section class="cw-card">
   <div class="cw-list-item"><div class="cw-avatar">✊</div><div class="cw-item-main"><b>Повстання</b><small>Ігрова подія для зміни регіонального управління</small></div></div>
   <div class="cw-list-item"><div class="cw-avatar">♨</div><div class="cw-item-main"><b>Політична криза</b><small>Переговори, голосування та мирне врегулювання</small></div></div>
   <button class="primary" id="cwPeacefulTraining">Навчання та підготовка служб</button>
  </section>
  <section class="cw-card">
   <h2>Світові події</h2>
   <p class="cw-muted">Тут відображатимуться міжнародні події, дипломатичні суперечки та результати ігрових змагань.</p>
   <div class="cw-list-item"><div class="cw-avatar">🌐</div><div class="cw-item-main"><b>Міжнародна взаємодія</b><small>Угоди, визнання держав і спільні проєкти</small></div></div>
  </section>`;
 pages.wars.appendChild(wars);

 const articles=document.createElement('div');
 articles.innerHTML=`
  <section class="cw-card">
   <div class="cw-tabs" id="cwArticleTabs">
    <button class="active" data-filter="all">Всі</button><button data-filter="best">Найкращі</button>
    <button data-filter="guides">Гайди</button><button data-filter="subs">Підписки</button>
   </div>
   <button class="secondary" id="cwLanguage">Всі: всіма мовами</button>
  </section>
  <section class="cw-card" id="cwArticleList">
   <article class="cw-article" data-kind="best"><time>Сьогодні</time><div class="cw-list-item"><div class="cw-avatar">🌍</div><div class="cw-item-main"><strong>Розвиток регіонів у Chemis World</strong><small>[CW] Команда Chemis World</small></div><span class="cw-positive">+128</span></div></article>
   <article class="cw-article" data-kind="guides"><time>Вчора</time><div class="cw-list-item"><div class="cw-avatar">📘</div><div class="cw-item-main"><strong>Як заснувати власну державу</strong><small>[CW] Посібник гравця</small></div><span class="cw-positive">+76</span></div></article>
   <article class="cw-article" data-kind="all"><time>26 жовтня</time><div class="cw-list-item"><div class="cw-avatar">🏛</div><div class="cw-item-main"><strong>Парламент і регіональне управління</strong><small>[CW] Ігрова спільнота</small></div><span class="cw-positive">+42</span></div></article>
  </section>
  <button class="cw-fab" id="cwCreateArticle" aria-label="Створити статтю">+</button>`;
 pages.articles.appendChild(articles);

 const profileExtra=document.createElement('section');
 profileExtra.className='cw-card';
 profileExtra.innerHTML=`
  <h2>Профіль гравця</h2>
  <div class="cw-list-item"><div class="cw-avatar">👤</div><div class="cw-item-main"><b id="cwProfileNickname">Гравець Chemis World</b><small>Місце у рейтингу: —</small><div class="cw-progress"><i></i></div></div></div>
  <div class="cw-row"><b>Рівень: 1</b><b class="cw-yellow">0 CW₵</b></div>
  <button class="primary" id="cwGoAccount">Налаштувати онлайн-профіль</button>
  <div class="cw-list-item"><div class="cw-avatar">🏛</div><div class="cw-item-main"><b>Держави та регіони</b><small>Твої політичні й територіальні проєкти</small></div></div>
  <div class="cw-list-item"><div class="cw-avatar">📊</div><div class="cw-item-main"><b>Економіка</b><small>Регіональні та міські бюджети незалежні</small></div></div>`;
 pages.profile.insertBefore(profileExtra,pages.profile.firstChild);

 // Place the online account controls after the profile overview card.
 const pageTitle=document.getElementById('pageTitle');
 function activate(key){
   if(!pages[key])return;
   Object.entries(pages).forEach(([name,node])=>node.classList.toggle('active',name===key));
   document.querySelectorAll('.cw-bottom [data-tab]').forEach(btn=>btn.classList.toggle('selected',btn.dataset.tab===key || (key==='map'&&btn.dataset.tab==='overview')));
   pageTitle.textContent=labels[key];
   window.scrollTo({top:0,behavior:'instant'});
   if(key==='map'&&typeof map!=='undefined'&&map&&typeof map.invalidateSize==='function'){
     setTimeout(()=>map.invalidateSize(true),80);
   }
   if(key==='profile'){
     const nick=document.getElementById('profileNickname')||document.getElementById('playerNickname');
     const target=document.getElementById('cwProfileNickname');
     if(nick&&target&&nick.value)target.textContent=nick.value;
   }
 }
 document.querySelectorAll('.cw-bottom [data-tab]').forEach(btn=>btn.addEventListener('click',()=>activate(btn.dataset.tab)));
 // Map is opened from the map control on overview; preserve the original map feature.
 const oldMapBtn=document.getElementById('mapBtn');
 if(oldMapBtn)oldMapBtn.addEventListener('click',()=>activate('map'));
 const searchBtn=document.getElementById('headerSearchBtn');
 if(searchBtn)searchBtn.addEventListener('click',()=>{
   const query=prompt('Що знайти у Chemis World?');
   if(query&&query.trim()){
     const text=query.trim().toLowerCase();
     const found=[...main.querySelectorAll('h2,h3,b,strong')].find(el=>el.textContent.toLowerCase().includes(text));
     if(found){const parent=found.closest('.cw-page');if(parent)activate(parent.dataset.page);found.scrollIntoView({behavior:'smooth',block:'center'});}
     else if(window.notify)notify('Нічого не знайдено за цим запитом.');
   }
 });
 const menuBtn=document.getElementById('headerMenuBtn');
 if(menuBtn)menuBtn.addEventListener('click',()=>notify('Меню Chemis World · Налаштування будуть додані окремо.'));
 const helpBtn=document.getElementById('headerHelpBtn');
 if(helpBtn)helpBtn.addEventListener('click',()=>notify('Chemis World: обери розділ у нижньому меню.'));
 const openMap=document.getElementById('cwOpenMap');
 if(openMap)openMap.addEventListener('click',()=>activate('map'));
 const zoomIn=document.getElementById('cwZoomIn');
 const zoomOut=document.getElementById('cwZoomOut');
 if(zoomIn)zoomIn.addEventListener('click',()=>{if(typeof map!=='undefined'&&map)map.zoomIn();});
 if(zoomOut)zoomOut.addEventListener('click',()=>{if(typeof map!=='undefined'&&map)map.zoomOut();});
 const goAccount=document.getElementById('cwGoAccount');
 if(goAccount)goAccount.addEventListener('click',()=>{activate('profile');document.getElementById('onlineAccountCard')?.scrollIntoView({behavior:'smooth'});});
 const chatSend=document.getElementById('cwChatSend');
 if(chatSend)chatSend.addEventListener('click',()=>{
   const input=document.getElementById('cwChatInput');
   const value=input?.value.trim();if(!value)return;
   const row=document.createElement('div');row.className='cw-list-item';
   const avatar=document.createElement('div');avatar.className='cw-avatar';avatar.textContent='👤';
   const body=document.createElement('div');body.className='cw-item-main';
   const name=document.createElement('b');name.textContent=document.getElementById('accountNick')?.value.trim()||'Гравець';
   const message=document.createElement('small');message.textContent=value;
   body.append(name,message);row.append(avatar,body);document.getElementById('cwChatMessages').append(row);
   input.value='';
   notify('Повідомлення додано лише до локального демо-чату.');
 });
 const training=document.getElementById('cwPeacefulTraining');
 if(training)training.addEventListener('click',()=>notify('Навчальний модуль буде доступний у наступному оновленні.'));
 const language=document.getElementById('cwLanguage');
 if(language)language.addEventListener('click',()=>notify('Фільтр мов буде підключено до системи статей.'));
 document.querySelectorAll('#cwArticleTabs button').forEach(btn=>btn.addEventListener('click',()=>{
   document.querySelectorAll('#cwArticleTabs button').forEach(b=>b.classList.toggle('active',b===btn));
   document.querySelectorAll('#cwArticleList [data-kind]').forEach(article=>{
     article.style.display=(btn.dataset.filter==='all'||btn.dataset.filter==='subs'||article.dataset.kind===btn.dataset.filter)?'block':'none';
   });
 }));
 const createArticle=document.getElementById('cwCreateArticle');
 if(createArticle)createArticle.addEventListener('click',()=>{
   const title=prompt('Назва статті');
   if(!title||!title.trim())return;
   const body=prompt('Короткий текст статті');
   if(body===null)return;
   const article=document.createElement('article');article.className='cw-article';article.dataset.kind='all';
   const safe=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
   article.innerHTML='<time>Щойно</time><div class="cw-list-item"><div class="cw-avatar">✍</div><div class="cw-item-main"><strong>'+safe(title.trim())+'</strong><small>'+safe(body.trim())+'</small></div><span class="cw-positive">+0</span></div>';
   document.getElementById('cwArticleList').prepend(article);
   notify('Статтю додано до локального демонстраційного списку.');
 });
 // Start at the overview tab.
 activate('overview');
})();
