package com.chemisworld.game

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView

    inner class ChemisBridge {
        @JavascriptInterface
        fun openExternal(url: String) {
            runOnUiThread {
                val uri = Uri.parse(url)
                if (uri.scheme == "https" && uri.host == "chemisworld.onrender.com") {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                }
            }
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = web.settings.userAgentString + " ChemisWorld/2.3.2"
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                handleGoogleCallback(intent)
            }
        }
        web.addJavascriptInterface(ChemisBridge(), "ChemisAndroid")
        web.loadUrl("file:///android_asset/www/index.html")
        setContentView(web)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleGoogleCallback(intent)
    }

    private fun handleGoogleCallback(source: Intent?) {
        val uri = source?.data ?: return
        if (uri.scheme != "chemisworld" || uri.host != "auth") return
        val token = uri.getQueryParameter("token") ?: return
        val escaped = org.json.JSONObject.quote(token)
        if (::web.isInitialized) {
            web.post { web.evaluateJavascript("window.cwGoogleLoginComplete && window.cwGoogleLoginComplete($escaped);", null) }
        }
        source.data = null
    }
}
